	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM privacy_response_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 5: // STATE 1
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 6: // STATE 2
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 7: // STATE 3
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 8: // STATE 4
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 9: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Handler */

	case 10: // STATE 9
		;
		now.route = trpt->bup.ovals[2];
		now.required_route = trpt->bup.ovals[1];
		reason = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 11: // STATE 9
		;
		now.route = trpt->bup.ovals[2];
		now.required_route = trpt->bup.ovals[1];
		reason = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 12: // STATE 9
		;
		now.route = trpt->bup.ovals[2];
		now.required_route = trpt->bup.ovals[1];
		reason = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 13: // STATE 9
		;
		now.route = trpt->bup.oval;
		;
		goto R999;
;
		
	case 14: // STATE 10
		goto R999;
;
		;
		;
		;
		
	case 17: // STATE 29
		;
		restarted = trpt->bup.ovals[1];
		now.crash = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 18: // STATE 32
		;
		terminal = trpt->bup.ovals[1];
		now.intent_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 19: // STATE 34
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 21: // STATE 36
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 22: // STATE 37
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 23: // STATE 40
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 24: // STATE 41
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 25: // STATE 52
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 26: // STATE 52
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 27: // STATE 52
		;
		now.pc = trpt->bup.ovals[4];
		terminal = trpt->bup.ovals[3];
		now.replayed = trpt->bup.ovals[2];
		now.sealed_notification_calls = trpt->bup.ovals[1];
		now.sealed_intent_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 5);
		goto R999;

	case 28: // STATE 58
		;
		terminal = trpt->bup.ovals[1];
		now.notification_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 29: // STATE 60
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 31: // STATE 62
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 32: // STATE 63
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 33: // STATE 66
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 34: // STATE 67
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 35: // STATE 78
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 36: // STATE 78
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 37: // STATE 78
		;
		now.pc = trpt->bup.ovals[4];
		terminal = trpt->bup.ovals[3];
		now.replayed = trpt->bup.ovals[2];
		now.sealed_notification_calls = trpt->bup.ovals[1];
		now.sealed_intent_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 5);
		goto R999;

	case 38: // STATE 84
		;
		now.finished = trpt->bup.ovals[1];
		terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 39: // STATE 87
		;
		crashed_between_effects = trpt->bup.oval;
		;
		goto R999;

	case 40: // STATE 93
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 41: // STATE 95
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 43: // STATE 102
		;
		now.admission_check = trpt->bup.oval;
		;
		goto R999;

	case 44: // STATE 105
		;
		now.finished = trpt->bup.ovals[1];
		terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 46: // STATE 108
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 47: // STATE 110
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 48: // STATE 121
		;
		now.pc = trpt->bup.ovals[4];
		now.intent_state = trpt->bup.ovals[3];
		now.frozen_destination = trpt->bup.ovals[2];
		now.frozen_route = trpt->bup.ovals[1];
		now.frozen_event = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 5);
		goto R999;

	case 49: // STATE 124
		;
		now.pc = trpt->bup.ovals[1];
		now.intent_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 50: // STATE 127
		;
		now.intent_receipt = trpt->bup.ovals[1];
		now.intent_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 51: // STATE 132
		;
		now.pc = trpt->bup.ovals[1];
		now.intent_exposed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 52: // STATE 132
		;
		now.pc = trpt->bup.ovals[1];
		now.intent_exposed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 53: // STATE 132
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 55: // STATE 135
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 56: // STATE 137
		;
		terminal = trpt->bup.oval;
		;
		goto R999;

	case 57: // STATE 139
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 59: // STATE 141
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 60: // STATE 142
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 61: // STATE 145
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 62: // STATE 146
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 63: // STATE 157
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 64: // STATE 157
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 65: // STATE 157
		;
		now.pc = trpt->bup.ovals[4];
		terminal = trpt->bup.ovals[3];
		now.replayed = trpt->bup.ovals[2];
		now.sealed_notification_calls = trpt->bup.ovals[1];
		now.sealed_intent_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 5);
		goto R999;

	case 66: // STATE 164
		;
		now.admission_check = trpt->bup.oval;
		;
		goto R999;

	case 67: // STATE 167
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 68: // STATE 171
		;
		now.finished = trpt->bup.ovals[2];
		terminal = trpt->bup.ovals[1];
		revoked_before_notification = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;
;
		
	case 69: // STATE 174
		goto R999;

	case 70: // STATE 178
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 71: // STATE 181
		;
		now.pc = trpt->bup.ovals[1];
		now.notification_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 72: // STATE 185
		;
		now.notification_calls = trpt->bup.oval;
		;
		goto R999;

	case 73: // STATE 187
		;
		now.pc = trpt->bup.oval;
		_m = unsend(now.submissions);
		;
		goto R999;
;
		;
		
	case 75: // STATE 190
		;
		now.pc = trpt->bup.ovals[1];
		XX = 1;
		unrecv(now.replies, XX-1, 0, now.observed_outcome, 1);
		now.observed_outcome = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 77: // STATE 194
		;
		terminal = trpt->bup.ovals[1];
		now.notification_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 78: // STATE 196
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 80: // STATE 198
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 81: // STATE 199
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 82: // STATE 202
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 83: // STATE 203
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 84: // STATE 214
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 85: // STATE 214
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 86: // STATE 214
		;
		now.pc = trpt->bup.ovals[4];
		terminal = trpt->bup.ovals[3];
		now.replayed = trpt->bup.ovals[2];
		now.sealed_notification_calls = trpt->bup.ovals[1];
		now.sealed_intent_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 5);
		goto R999;

	case 87: // STATE 222
		;
		now.notification_receipt = trpt->bup.ovals[3];
		now.notification_state = trpt->bup.ovals[2];
		now.sealed_outcome = trpt->bup.ovals[1];
		now.provider_outcome = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 88: // STATE 227
		;
		now.pc = trpt->bup.ovals[1];
		payload_withheld = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 89: // STATE 227
		;
		now.pc = trpt->bup.ovals[1];
		payload_withheld = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 90: // STATE 227
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 91: // STATE 232
		;
		terminal = trpt->bup.oval;
		;
		goto R999;

	case 92: // STATE 234
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 94: // STATE 236
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 95: // STATE 237
		;
		now.attempt_event = trpt->bup.oval;
		;
		goto R999;

	case 96: // STATE 240
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 97: // STATE 241
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 98: // STATE 252
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 99: // STATE 252
		;
		now.pc = trpt->bup.ovals[5];
		terminal = trpt->bup.ovals[4];
		now.replayed = trpt->bup.ovals[3];
		now.sealed_notification_calls = trpt->bup.ovals[2];
		now.sealed_intent_calls = trpt->bup.ovals[1];
		now.attempt_destination = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 100: // STATE 252
		;
		now.pc = trpt->bup.ovals[4];
		terminal = trpt->bup.ovals[3];
		now.replayed = trpt->bup.ovals[2];
		now.sealed_notification_calls = trpt->bup.ovals[1];
		now.sealed_intent_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 5);
		goto R999;
;
		;
		
	case 102: // STATE 260
		;
		now.finished = trpt->bup.ovals[2];
		terminal = trpt->bup.ovals[1];
		foreign_rejected = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;
;
		;
		
	case 104: // STATE 265
		;
		now.finished = trpt->bup.ovals[2];
		terminal = trpt->bup.ovals[1];
		conflict_rejected = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 105: // STATE 267
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 107: // STATE 276
		;
		now.finished = trpt->bup.ovals[2];
		terminal = trpt->bup.ovals[1];
		now.destination_conflict = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;
;
		;
		
	case 109: // STATE 282
		;
		now.finished = trpt->bup.ovals[2];
		terminal = trpt->bup.ovals[1];
		unknown_retry_blocked = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 110: // STATE 284
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		
	case 111: // STATE 293
		goto R999;
;
		;
		
	case 113: // STATE 311
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Endpoint */

	case 114: // STATE 1
		;
	/* 0 */	((P2 *)_this)->action_id = trpt->bup.ovals[1];
		XX = 1;
		unrecv(now.submissions, XX-1, 0, ((int)((P2 *)_this)->action_id), 1);
		((P2 *)_this)->action_id = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 115: // STATE 2
		;
		_m = unsend(now.replies);
		;
		goto R999;

	case 116: // STATE 3
		;
		_m = unsend(now.replies);
		;
		goto R999;

	case 117: // STATE 4
		;
		_m = unsend(now.replies);
		;
		goto R999;

	case 118: // STATE 5
		;
		_m = unsend(now.replies);
		;
		goto R999;

	case 119: // STATE 6
		;
		_m = unsend(now.replies);
		;
		goto R999;
;
		;
		
	case 121: // STATE 14
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Crash */

	case 122: // STATE 4
		;
		crashed_once = trpt->bup.ovals[1];
		now.crash = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 123: // STATE 8
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Revoke */

	case 124: // STATE 3
		;
		now.rights = trpt->bup.oval;
		;
		goto R999;

	case 125: // STATE 7
		;
		p_restor(II);
		;
		;
		goto R999;
	}

