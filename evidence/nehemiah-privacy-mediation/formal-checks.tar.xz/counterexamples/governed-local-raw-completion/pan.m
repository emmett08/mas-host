#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM governed_local_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(finished))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[5][1] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[5][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - governed-local.pml:519 - [(run Host())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][1] = 1;
		if (!(addproc(II, 1, 3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - governed-local.pml:519 - [(run External())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][2] = 1;
		if (!(addproc(II, 1, 2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 3 - governed-local.pml:519 - [(run Authority())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][3] = 1;
		if (!(addproc(II, 1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 4 - governed-local.pml:519 - [(run Crash())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][4] = 1;
		if (!(addproc(II, 1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 6 - governed-local.pml:520 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[4][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Host */
	case 10: // STATE 1 - governed-local.pml:209 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][1] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 2 - governed-local.pml:210 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][2] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 3 - governed-local.pml:212 - [(finished)] (0:0:0 - 1)
		IfNotBlocked
		reached[3][3] = 1;
		if (!(((int)now.finished)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 5 - governed-local.pml:213 - [(!(finished))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][5] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 6 - governed-local.pml:215 - [(crash)] (93:0:2 - 1)
		IfNotBlocked
		reached[3][6] = 1;
		if (!(((int)now.crash)))
			continue;
		/* merge: crash = 0(93, 7, 93) */
		reached[3][7] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.crash);
		now.crash = 0;
#ifdef VAR_RANGES
		logval("crash", ((int)now.crash));
#endif
		;
		/* merge: restarted = 1(93, 8, 93) */
		reached[3][8] = 1;
		(trpt+1)->bup.ovals[1] = ((int)restarted);
		restarted = 1;
#ifdef VAR_RANGES
		logval("restarted", ((int)restarted));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 15: // STATE 9 - governed-local.pml:218 - [((effect_state==Executing))] (35:0:3 - 1)
		IfNotBlocked
		reached[3][9] = 1;
		if (!((now.effect_state==12)))
			continue;
		/* merge: effect_state = Unknown(35, 10, 35) */
		reached[3][10] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 10;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: unknown_seen = 1(35, 11, 35) */
		reached[3][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: terminal = Blocked(35, 12, 35) */
		reached[3][12] = 1;
		(trpt+1)->bup.ovals[2] = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 16: // STATE 13 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][13] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 14 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][14] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 15 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][15] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 18 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][18] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 19 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][19] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 22 - governed-local.pml:158 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][22] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 32, 550) */
		reached[3][32] = 1;
		;
		/* merge: sealed_calls = calls(550, 33, 550) */
		reached[3][33] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 34, 550) */
		reached[3][34] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 22: // STATE 23 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:29:2 - 1)
		IfNotBlocked
		reached[3][23] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(29, 24, 29) */
		reached[3][24] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 23: // STATE 25 - governed-local.pml:160 - [((grant_epoch==2))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][25] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(550, 26, 550) */
		reached[3][26] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)epoch_refreshed);
		epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)epoch_refreshed));
#endif
		;
		/* merge: .(goto)(550, 30, 550) */
		reached[3][30] = 1;
		;
		/* merge: .(goto)(550, 32, 550) */
		reached[3][32] = 1;
		;
		/* merge: sealed_calls = calls(550, 33, 550) */
		reached[3][33] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 34, 550) */
		reached[3][34] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 24: // STATE 28 - governed-local.pml:160 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][28] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 30, 550) */
		reached[3][30] = 1;
		;
		/* merge: .(goto)(550, 32, 550) */
		reached[3][32] = 1;
		;
		/* merge: sealed_calls = calls(550, 33, 550) */
		reached[3][33] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 34, 550) */
		reached[3][34] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 25: // STATE 33 - governed-local.pml:162 - [sealed_calls = calls] (0:550:2 - 5)
		IfNotBlocked
		reached[3][33] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 34, 550) */
		reached[3][34] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 26: // STATE 36 - governed-local.pml:221 - [((effect_state==Completed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][36] = 1;
		if (!((now.effect_state==11)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 27: // STATE 37 - governed-local.pml:222 - [(!(protocol_completed))] (65:0:1 - 1)
		IfNotBlocked
		reached[3][37] = 1;
		if (!( !(((int)now.protocol_completed))))
			continue;
		/* merge: completion_gap_crash = 1(0, 38, 65) */
		reached[3][38] = 1;
		(trpt+1)->bup.oval = ((int)completion_gap_crash);
		completion_gap_crash = 1;
#ifdef VAR_RANGES
		logval("completion_gap_crash", ((int)completion_gap_crash));
#endif
		;
		/* merge: .(goto)(0, 42, 65) */
		reached[3][42] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 28: // STATE 43 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][43] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 29: // STATE 44 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][44] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 30: // STATE 45 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][45] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 48 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][48] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 49 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][49] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 52 - governed-local.pml:158 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][52] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 62, 550) */
		reached[3][62] = 1;
		;
		/* merge: sealed_calls = calls(550, 63, 550) */
		reached[3][63] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 64, 550) */
		reached[3][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 34: // STATE 53 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:59:2 - 1)
		IfNotBlocked
		reached[3][53] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(59, 54, 59) */
		reached[3][54] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 35: // STATE 55 - governed-local.pml:160 - [((grant_epoch==2))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][55] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(550, 56, 550) */
		reached[3][56] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)epoch_refreshed);
		epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)epoch_refreshed));
#endif
		;
		/* merge: .(goto)(550, 60, 550) */
		reached[3][60] = 1;
		;
		/* merge: .(goto)(550, 62, 550) */
		reached[3][62] = 1;
		;
		/* merge: sealed_calls = calls(550, 63, 550) */
		reached[3][63] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 64, 550) */
		reached[3][64] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 36: // STATE 58 - governed-local.pml:160 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][58] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 60, 550) */
		reached[3][60] = 1;
		;
		/* merge: .(goto)(550, 62, 550) */
		reached[3][62] = 1;
		;
		/* merge: sealed_calls = calls(550, 63, 550) */
		reached[3][63] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 64, 550) */
		reached[3][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 37: // STATE 63 - governed-local.pml:162 - [sealed_calls = calls] (0:550:2 - 5)
		IfNotBlocked
		reached[3][63] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 64, 550) */
		reached[3][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 38: // STATE 66 - governed-local.pml:224 - [((effect_state==Unknown))] (90:0:1 - 1)
		IfNotBlocked
		reached[3][66] = 1;
		if (!((now.effect_state==10)))
			continue;
		/* merge: terminal = Blocked(0, 67, 90) */
		reached[3][67] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 39: // STATE 68 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][68] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 69 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][69] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 41: // STATE 70 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][70] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 42: // STATE 73 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][73] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 43: // STATE 74 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][74] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 44: // STATE 77 - governed-local.pml:158 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][77] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 87, 550) */
		reached[3][87] = 1;
		;
		/* merge: sealed_calls = calls(550, 88, 550) */
		reached[3][88] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 89, 550) */
		reached[3][89] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 45: // STATE 78 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:84:2 - 1)
		IfNotBlocked
		reached[3][78] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(84, 79, 84) */
		reached[3][79] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 46: // STATE 80 - governed-local.pml:160 - [((grant_epoch==2))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][80] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(550, 81, 550) */
		reached[3][81] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)epoch_refreshed);
		epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)epoch_refreshed));
#endif
		;
		/* merge: .(goto)(550, 85, 550) */
		reached[3][85] = 1;
		;
		/* merge: .(goto)(550, 87, 550) */
		reached[3][87] = 1;
		;
		/* merge: sealed_calls = calls(550, 88, 550) */
		reached[3][88] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 89, 550) */
		reached[3][89] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 47: // STATE 83 - governed-local.pml:160 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][83] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 85, 550) */
		reached[3][85] = 1;
		;
		/* merge: .(goto)(550, 87, 550) */
		reached[3][87] = 1;
		;
		/* merge: sealed_calls = calls(550, 88, 550) */
		reached[3][88] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 89, 550) */
		reached[3][89] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 48: // STATE 88 - governed-local.pml:162 - [sealed_calls = calls] (0:550:2 - 5)
		IfNotBlocked
		reached[3][88] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 89, 550) */
		reached[3][89] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 550) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 49: // STATE 92 - governed-local.pml:225 - [pc = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[3][92] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 50: // STATE 95 - governed-local.pml:227 - [(!(crash))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][95] = 1;
		if (!( !(((int)now.crash))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 51: // STATE 96 - governed-local.pml:229 - [((pc==0))] (103:0:1 - 1)
		IfNotBlocked
		reached[3][96] = 1;
		if (!((((int)now.pc)==0)))
			continue;
		/* merge: request_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 97, 103) */
		reached[3][97] = 1;
		(trpt+1)->bup.oval = ((int)now.request_check);
		now.request_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("request_check", ((int)now.request_check));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 52: // STATE 98 - governed-local.pml:232 - [(request_check)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][98] = 1;
		if (!(((int)now.request_check)))
			continue;
		/* merge: pc = 30(0, 99, 550) */
		reached[3][99] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 30;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 104, 550) */
		reached[3][104] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 53: // STATE 100 - governed-local.pml:233 - [(!(request_check))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][100] = 1;
		if (!( !(((int)now.request_check))))
			continue;
		/* merge: terminal = Denied(550, 101, 550) */
		reached[3][101] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 102, 550) */
		reached[3][102] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 104, 550) */
		reached[3][104] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 54: // STATE 105 - governed-local.pml:235 - [((pc==1))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][105] = 1;
		if (!((((int)now.pc)==1)))
			continue;
		/* merge: assert(request_check)(550, 106, 550) */
		reached[3][106] = 1;
		spin_assert(((int)now.request_check), "request_check", II, tt, t);
		/* merge: assert(input_inspected)(550, 107, 550) */
		reached[3][107] = 1;
		spin_assert(((int)now.input_inspected), "input_inspected", II, tt, t);
		/* merge: bound_original = 1(550, 108, 550) */
		reached[3][108] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.bound_original);
		now.bound_original = 1;
#ifdef VAR_RANGES
		logval("bound_original", ((int)now.bound_original));
#endif
		;
		/* merge: journal_input = Safe(550, 109, 550) */
		reached[3][109] = 1;
		(trpt+1)->bup.ovals[1] = now.journal_input;
		now.journal_input = 8;
#ifdef VAR_RANGES
		logval("journal_input", now.journal_input);
#endif
		;
		/* merge: pc = 2(550, 110, 550) */
		reached[3][110] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 2;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 55: // STATE 111 - governed-local.pml:245 - [((pc==2))] (118:0:1 - 1)
		IfNotBlocked
		reached[3][111] = 1;
		if (!((((int)now.pc)==2)))
			continue;
		/* merge: protocol_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 112, 118) */
		reached[3][112] = 1;
		(trpt+1)->bup.oval = ((int)now.protocol_check);
		now.protocol_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("protocol_check", ((int)now.protocol_check));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 56: // STATE 113 - governed-local.pml:248 - [(protocol_check)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][113] = 1;
		if (!(((int)now.protocol_check)))
			continue;
		/* merge: pc = 23(0, 114, 550) */
		reached[3][114] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 23;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 119, 550) */
		reached[3][119] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 57: // STATE 115 - governed-local.pml:249 - [(!(protocol_check))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][115] = 1;
		if (!( !(((int)now.protocol_check))))
			continue;
		/* merge: terminal = Denied(550, 116, 550) */
		reached[3][116] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 117, 550) */
		reached[3][117] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 119, 550) */
		reached[3][119] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 58: // STATE 120 - governed-local.pml:251 - [((pc==23))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][120] = 1;
		if (!((((int)now.pc)==23)))
			continue;
		/* merge: assert(protocol_check)(550, 121, 550) */
		reached[3][121] = 1;
		spin_assert(((int)now.protocol_check), "protocol_check", II, tt, t);
		/* merge: protocol_input = journal_input(550, 122, 550) */
		reached[3][122] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.protocol_input;
		now.protocol_input = now.journal_input;
#ifdef VAR_RANGES
		logval("protocol_input", now.protocol_input);
#endif
		;
		/* merge: pc = 3(550, 123, 550) */
		reached[3][123] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 59: // STATE 124 - governed-local.pml:253 - [((pc==3))] (132:0:1 - 1)
		IfNotBlocked
		reached[3][124] = 1;
		if (!((((int)now.pc)==3)))
			continue;
		/* merge: effect_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(132, 125, 132) */
		reached[3][125] = 1;
		(trpt+1)->bup.oval = ((int)now.effect_check);
		now.effect_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("effect_check", ((int)now.effect_check));
#endif
		;
		/* merge: assert((!(effect_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(132, 126, 132) */
		reached[3][126] = 1;
		spin_assert(( !(((int)now.effect_check))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(effect_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 60: // STATE 127 - governed-local.pml:260 - [(effect_check)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][127] = 1;
		if (!(((int)now.effect_check)))
			continue;
		/* merge: pc = 40(0, 128, 550) */
		reached[3][128] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 40;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 133, 550) */
		reached[3][133] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 61: // STATE 129 - governed-local.pml:266 - [(!(effect_check))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][129] = 1;
		if (!( !(((int)now.effect_check))))
			continue;
		/* merge: terminal = Denied(550, 130, 550) */
		reached[3][130] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 131, 550) */
		reached[3][131] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 133, 550) */
		reached[3][133] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 62: // STATE 134 - governed-local.pml:268 - [((pc==4))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][134] = 1;
		if (!((((int)now.pc)==4)))
			continue;
		/* merge: assert(outbound_inspected)(550, 135, 550) */
		reached[3][135] = 1;
		spin_assert(((int)now.outbound_inspected), "outbound_inspected", II, tt, t);
		/* merge: effect_state = Prepared(550, 136, 550) */
		reached[3][136] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 13;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: reservation = 1(550, 137, 550) */
		reached[3][137] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.reservation);
		now.reservation = 1;
#ifdef VAR_RANGES
		logval("reservation", ((int)now.reservation));
#endif
		;
		/* merge: pc = 5(550, 138, 550) */
		reached[3][138] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 5;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 63: // STATE 139 - governed-local.pml:271 - [((pc==5))] (146:0:1 - 1)
		IfNotBlocked
		reached[3][139] = 1;
		if (!((((int)now.pc)==5)))
			continue;
		/* merge: effect_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 140, 146) */
		reached[3][140] = 1;
		(trpt+1)->bup.oval = ((int)now.effect_check);
		now.effect_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("effect_check", ((int)now.effect_check));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 64: // STATE 141 - governed-local.pml:274 - [(effect_check)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][141] = 1;
		if (!(((int)now.effect_check)))
			continue;
		/* merge: pc = 6(0, 142, 550) */
		reached[3][142] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 6;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 147, 550) */
		reached[3][147] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 65: // STATE 143 - governed-local.pml:275 - [(!(effect_check))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][143] = 1;
		if (!( !(((int)now.effect_check))))
			continue;
		/* merge: terminal = Denied(550, 144, 550) */
		reached[3][144] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 145, 550) */
		reached[3][145] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 147, 550) */
		reached[3][147] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 66: // STATE 148 - governed-local.pml:277 - [((pc==6))] (154:0:0 - 1)
		IfNotBlocked
		reached[3][148] = 1;
		if (!((((int)now.pc)==6)))
			continue;
		/* merge: assert((effect_check&&reservation))(0, 149, 154) */
		reached[3][149] = 1;
		spin_assert((((int)now.effect_check)&&((int)now.reservation)), "(effect_check&&reservation)", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 67: // STATE 150 - governed-local.pml:279 - [(!((((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][150] = 1;
		if (!( !((((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch))))))
			continue;
		/* merge: check_action_race = 1(550, 151, 550) */
		reached[3][151] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)check_action_race);
		check_action_race = 1;
#ifdef VAR_RANGES
		logval("check_action_race", ((int)check_action_race));
#endif
		;
		/* merge: .(goto)(550, 155, 550) */
		reached[3][155] = 1;
		;
		/* merge: effect_state = Executing(550, 156, 550) */
		reached[3][156] = 1;
		(trpt+1)->bup.ovals[1] = now.effect_state;
		now.effect_state = 12;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: pc = 7(550, 157, 550) */
		reached[3][157] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 7;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 68: // STATE 153 - governed-local.pml:279 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][153] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 155, 550) */
		reached[3][155] = 1;
		;
		/* merge: effect_state = Executing(550, 156, 550) */
		reached[3][156] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 12;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: pc = 7(550, 157, 550) */
		reached[3][157] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 7;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 69: // STATE 156 - governed-local.pml:280 - [effect_state = Executing] (0:550:2 - 3)
		IfNotBlocked
		reached[3][156] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 12;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: pc = 7(550, 157, 550) */
		reached[3][157] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 7;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 70: // STATE 158 - governed-local.pml:281 - [((pc==7))] (160:0:1 - 1)
		IfNotBlocked
		reached[3][158] = 1;
		if (!((((int)now.pc)==7)))
			continue;
		/* merge: calls = (calls+1)(0, 159, 160) */
		reached[3][159] = 1;
		(trpt+1)->bup.oval = ((int)now.calls);
		now.calls = (((int)now.calls)+1);
#ifdef VAR_RANGES
		logval("calls", ((int)now.calls));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 71: // STATE 160 - governed-local.pml:282 - [requests!1] (550:0:1 - 1)
		IfNotBlocked
		reached[3][160] = 1;
		if (q_full(now.requests))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.requests);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.requests, 0, 1, 0, 1);
		/* merge: pc = 8(0, 161, 550) */
		reached[3][161] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 8;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 2; goto P999; /* 3 */
	case 72: // STATE 162 - governed-local.pml:283 - [((pc==8))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][162] = 1;
		if (!((((int)now.pc)==8)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 73: // STATE 163 - governed-local.pml:290 - [results?observed,observed_certainty] (550:0:3 - 1)
		reached[3][163] = 1;
		if (q_len(now.results) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.observed;
		(trpt+1)->bup.ovals[1] = ((int)now.observed_certainty);
		;
		now.observed = qrecv(now.results, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("observed", now.observed);
#endif
		;
		now.observed_certainty = qrecv(now.results, XX-1, 1, 1);
#ifdef VAR_RANGES
		logval("observed_certainty", ((int)now.observed_certainty));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.results);
			sprintf(simtmp, "%d", now.observed); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((int)now.observed_certainty)); strcat(simvals, simtmp);
		}
#endif
		;
		/* merge: pc = 9(0, 164, 550) */
		reached[3][164] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 9;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 4; goto P999; /* 3 */
	case 74: // STATE 165 - governed-local.pml:292 - [((pc==9))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][165] = 1;
		if (!((((int)now.pc)==9)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 75: // STATE 166 - governed-local.pml:294 - [((observed==TransportLost))] (192:0:3 - 1)
		IfNotBlocked
		reached[3][166] = 1;
		if (!((now.observed==5)))
			continue;
		/* merge: effect_state = Unknown(192, 167, 192) */
		reached[3][167] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 10;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: unknown_seen = 1(192, 168, 192) */
		reached[3][168] = 1;
		(trpt+1)->bup.ovals[1] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: terminal = Blocked(192, 169, 192) */
		reached[3][169] = 1;
		(trpt+1)->bup.ovals[2] = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 76: // STATE 170 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][170] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 77: // STATE 171 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][171] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 78: // STATE 172 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][172] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 79: // STATE 175 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][175] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 80: // STATE 176 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][176] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 81: // STATE 179 - governed-local.pml:158 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][179] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 189, 550) */
		reached[3][189] = 1;
		;
		/* merge: sealed_calls = calls(550, 190, 550) */
		reached[3][190] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 191, 550) */
		reached[3][191] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 550) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 82: // STATE 180 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:186:2 - 1)
		IfNotBlocked
		reached[3][180] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(186, 181, 186) */
		reached[3][181] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 83: // STATE 182 - governed-local.pml:160 - [((grant_epoch==2))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][182] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(550, 183, 550) */
		reached[3][183] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)epoch_refreshed);
		epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)epoch_refreshed));
#endif
		;
		/* merge: .(goto)(550, 187, 550) */
		reached[3][187] = 1;
		;
		/* merge: .(goto)(550, 189, 550) */
		reached[3][189] = 1;
		;
		/* merge: sealed_calls = calls(550, 190, 550) */
		reached[3][190] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 191, 550) */
		reached[3][191] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 550) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 84: // STATE 185 - governed-local.pml:160 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][185] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 187, 550) */
		reached[3][187] = 1;
		;
		/* merge: .(goto)(550, 189, 550) */
		reached[3][189] = 1;
		;
		/* merge: sealed_calls = calls(550, 190, 550) */
		reached[3][190] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 191, 550) */
		reached[3][191] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 550) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 85: // STATE 190 - governed-local.pml:162 - [sealed_calls = calls] (0:550:2 - 5)
		IfNotBlocked
		reached[3][190] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 191, 550) */
		reached[3][191] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 550) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 86: // STATE 193 - governed-local.pml:297 - [((observed!=TransportLost))] (550:0:1 - 1)
		IfNotBlocked
		reached[3][193] = 1;
		if (!((now.observed!=5)))
			continue;
		/* merge: pc = 33(0, 194, 550) */
		reached[3][194] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 33;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 550) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 87: // STATE 197 - governed-local.pml:299 - [((pc==33))] (205:0:1 - 1)
		IfNotBlocked
		reached[3][197] = 1;
		if (!((((int)now.pc)==33)))
			continue;
		/* merge: inspection_precheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 198, 205) */
		reached[3][198] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_precheck);
		now.inspection_precheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_precheck", ((int)now.inspection_precheck));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 88: // STATE 199 - governed-local.pml:302 - [(inspection_precheck)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][199] = 1;
		if (!(((int)now.inspection_precheck)))
			continue;
		/* merge: pc = 34(0, 200, 550) */
		reached[3][200] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 34;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 206, 550) */
		reached[3][206] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 89: // STATE 201 - governed-local.pml:303 - [(!(inspection_precheck))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][201] = 1;
		if (!( !(((int)now.inspection_precheck))))
			continue;
		/* merge: local_withheld = 1(550, 202, 550) */
		reached[3][202] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.local_withheld);
		now.local_withheld = 1;
#ifdef VAR_RANGES
		logval("local_withheld", ((int)now.local_withheld));
#endif
		;
		/* merge: local_output = Withheld(550, 203, 550) */
		reached[3][203] = 1;
		(trpt+1)->bup.ovals[1] = now.local_output;
		now.local_output = 6;
#ifdef VAR_RANGES
		logval("local_output", now.local_output);
#endif
		;
		/* merge: pc = 10(550, 204, 550) */
		reached[3][204] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 206, 550) */
		reached[3][206] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 90: // STATE 207 - governed-local.pml:306 - [((pc==34))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][207] = 1;
		if (!((((int)now.pc)==34)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 91: // STATE 208 - governed-local.pml:171 - [inspection_complete = 1] (0:217:4 - 1)
		IfNotBlocked
		reached[3][208] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 1;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: inspection_exact = 1(217, 209, 217) */
		reached[3][209] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_exact);
		now.inspection_exact = 1;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: inspection_clean = 1(217, 210, 217) */
		reached[3][210] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inspection_clean);
		now.inspection_clean = 1;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: inspection_original_positive = 0(217, 211, 217) */
		reached[3][211] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 0;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 92: // STATE 212 - governed-local.pml:174 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][212] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 218, 550) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 219, 550) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 220, 550) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(550, 222, 550) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 93: // STATE 213 - governed-local.pml:175 - [inspection_original_positive = 1] (0:550:3 - 1)
		IfNotBlocked
		reached[3][213] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 1;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		/* merge: .(goto)(550, 218, 550) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 219, 550) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 220, 550) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(550, 222, 550) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 94: // STATE 214 - governed-local.pml:176 - [inspection_complete = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][214] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 0;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: .(goto)(550, 218, 550) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 219, 550) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 220, 550) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(550, 222, 550) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 95: // STATE 215 - governed-local.pml:177 - [inspection_exact = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][215] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_exact);
		now.inspection_exact = 0;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: .(goto)(550, 218, 550) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 219, 550) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 220, 550) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(550, 222, 550) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 96: // STATE 216 - governed-local.pml:178 - [inspection_clean = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][216] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_clean);
		now.inspection_clean = 0;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: .(goto)(550, 218, 550) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 219, 550) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 220, 550) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(550, 222, 550) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 97: // STATE 219 - governed-local.pml:180 - [inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)] (0:550:2 - 6)
		IfNotBlocked
		reached[3][219] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 220, 550) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(550, 222, 550) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 98: // STATE 223 - governed-local.pml:307 - [((pc==35))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][223] = 1;
		if (!((((int)now.pc)==35)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 99: // STATE 224 - governed-local.pml:194 - [inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))] (0:229:1 - 1)
		IfNotBlocked
		reached[3][224] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_postcheck);
		now.inspection_postcheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_postcheck", ((int)now.inspection_postcheck));
#endif
		;
		/* merge: assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(229, 225, 229) */
		reached[3][225] = 1;
		spin_assert(( !(((int)now.inspection_postcheck))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 100: // STATE 227 - governed-local.pml:309 - [envelope_valid = 1] (0:237:3 - 1)
		IfNotBlocked
		reached[3][227] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.envelope_valid);
		now.envelope_valid = 1;
#ifdef VAR_RANGES
		logval("envelope_valid", ((int)now.envelope_valid));
#endif
		;
		/* merge: .(goto)(237, 230, 237) */
		reached[3][230] = 1;
		;
		/* merge: result_projected = (((inspection_accepted&&inspection_postcheck)&&(observed==Safe))&&envelope_valid)(237, 231, 237) */
		reached[3][231] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.result_projected);
		now.result_projected = (((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))&&(now.observed==8))&&((int)now.envelope_valid));
#ifdef VAR_RANGES
		logval("result_projected", ((int)now.result_projected));
#endif
		;
		/* merge: local_withheld = !(result_projected)(237, 232, 237) */
		reached[3][232] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.local_withheld);
		now.local_withheld =  !(((int)now.result_projected));
#ifdef VAR_RANGES
		logval("local_withheld", ((int)now.local_withheld));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 101: // STATE 228 - governed-local.pml:309 - [envelope_valid = 0] (0:237:3 - 1)
		IfNotBlocked
		reached[3][228] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.envelope_valid);
		now.envelope_valid = 0;
#ifdef VAR_RANGES
		logval("envelope_valid", ((int)now.envelope_valid));
#endif
		;
		/* merge: .(goto)(237, 230, 237) */
		reached[3][230] = 1;
		;
		/* merge: result_projected = (((inspection_accepted&&inspection_postcheck)&&(observed==Safe))&&envelope_valid)(237, 231, 237) */
		reached[3][231] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.result_projected);
		now.result_projected = (((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))&&(now.observed==8))&&((int)now.envelope_valid));
#ifdef VAR_RANGES
		logval("result_projected", ((int)now.result_projected));
#endif
		;
		/* merge: local_withheld = !(result_projected)(237, 232, 237) */
		reached[3][232] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.local_withheld);
		now.local_withheld =  !(((int)now.result_projected));
#ifdef VAR_RANGES
		logval("local_withheld", ((int)now.local_withheld));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 102: // STATE 231 - governed-local.pml:310 - [result_projected = (((inspection_accepted&&inspection_postcheck)&&(observed==Safe))&&envelope_valid)] (0:237:2 - 3)
		IfNotBlocked
		reached[3][231] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.result_projected);
		now.result_projected = (((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))&&(now.observed==8))&&((int)now.envelope_valid));
#ifdef VAR_RANGES
		logval("result_projected", ((int)now.result_projected));
#endif
		;
		/* merge: local_withheld = !(result_projected)(237, 232, 237) */
		reached[3][232] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.local_withheld);
		now.local_withheld =  !(((int)now.result_projected));
#ifdef VAR_RANGES
		logval("local_withheld", ((int)now.local_withheld));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 103: // STATE 233 - governed-local.pml:313 - [(result_projected)] (243:0:1 - 1)
		IfNotBlocked
		reached[3][233] = 1;
		if (!(((int)now.result_projected)))
			continue;
		/* merge: local_output = Safe(0, 234, 243) */
		reached[3][234] = 1;
		(trpt+1)->bup.oval = now.local_output;
		now.local_output = 8;
#ifdef VAR_RANGES
		logval("local_output", now.local_output);
#endif
		;
		/* merge: .(goto)(0, 238, 243) */
		reached[3][238] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 104: // STATE 235 - governed-local.pml:314 - [(!(result_projected))] (243:0:1 - 1)
		IfNotBlocked
		reached[3][235] = 1;
		if (!( !(((int)now.result_projected))))
			continue;
		/* merge: local_output = Withheld(0, 236, 243) */
		reached[3][236] = 1;
		(trpt+1)->bup.oval = now.local_output;
		now.local_output = 6;
#ifdef VAR_RANGES
		logval("local_output", now.local_output);
#endif
		;
		/* merge: .(goto)(0, 238, 243) */
		reached[3][238] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 105: // STATE 239 - governed-local.pml:317 - [(!(inspection_accepted))] (249:0:1 - 1)
		IfNotBlocked
		reached[3][239] = 1;
		if (!( !(((int)now.inspection_accepted))))
			continue;
		/* merge: inspection_withheld = 1(0, 240, 249) */
		reached[3][240] = 1;
		(trpt+1)->bup.oval = ((int)inspection_withheld);
		inspection_withheld = 1;
#ifdef VAR_RANGES
		logval("inspection_withheld", ((int)inspection_withheld));
#endif
		;
		/* merge: .(goto)(0, 244, 249) */
		reached[3][244] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 106: // STATE 245 - governed-local.pml:321 - [((observed==Raw))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][245] = 1;
		if (!((now.observed==7)))
			continue;
		/* merge: local_output = Raw(550, 246, 550) */
		reached[3][246] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.local_output;
		now.local_output = 7;
#ifdef VAR_RANGES
		logval("local_output", now.local_output);
#endif
		;
		/* merge: .(goto)(550, 250, 550) */
		reached[3][250] = 1;
		;
		/* merge: pc = 10(550, 251, 550) */
		reached[3][251] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 107: // STATE 248 - governed-local.pml:321 - [(1)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][248] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 250, 550) */
		reached[3][250] = 1;
		;
		/* merge: pc = 10(550, 251, 550) */
		reached[3][251] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 108: // STATE 251 - governed-local.pml:323 - [pc = 10] (0:550:1 - 3)
		IfNotBlocked
		reached[3][251] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 109: // STATE 252 - governed-local.pml:324 - [((pc==10))] (266:0:8 - 1)
		IfNotBlocked
		reached[3][252] = 1;
		if (!((((int)now.pc)==10)))
			continue;
		/* merge: receipt = 1(266, 253, 266) */
		reached[3][253] = 1;
		(trpt+1)->bup.ovals = grab_ints(8);
		(trpt+1)->bup.ovals[0] = ((int)now.receipt);
		now.receipt = 1;
#ifdef VAR_RANGES
		logval("receipt", ((int)now.receipt));
#endif
		;
		/* merge: effect_state = Completed(266, 254, 266) */
		reached[3][254] = 1;
		(trpt+1)->bup.ovals[1] = now.effect_state;
		now.effect_state = 11;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: journal_output = local_output(266, 255, 266) */
		reached[3][255] = 1;
		(trpt+1)->bup.ovals[2] = now.journal_output;
		now.journal_output = now.local_output;
#ifdef VAR_RANGES
		logval("journal_output", now.journal_output);
#endif
		;
		/* merge: receipt_payload = local_output(266, 256, 266) */
		reached[3][256] = 1;
		(trpt+1)->bup.ovals[3] = now.receipt_payload;
		now.receipt_payload = now.local_output;
#ifdef VAR_RANGES
		logval("receipt_payload", now.receipt_payload);
#endif
		;
		/* merge: retained_withheld = local_withheld(266, 257, 266) */
		reached[3][257] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.retained_withheld);
		now.retained_withheld = ((int)now.local_withheld);
#ifdef VAR_RANGES
		logval("retained_withheld", ((int)now.retained_withheld));
#endif
		;
		/* merge: sealed_withheld = local_withheld(266, 258, 266) */
		reached[3][258] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.sealed_withheld);
		now.sealed_withheld = ((int)now.local_withheld);
#ifdef VAR_RANGES
		logval("sealed_withheld", ((int)now.sealed_withheld));
#endif
		;
		/* merge: retained_certainty = observed_certainty(266, 259, 266) */
		reached[3][259] = 1;
		(trpt+1)->bup.ovals[6] = ((int)now.retained_certainty);
		now.retained_certainty = ((int)now.observed_certainty);
#ifdef VAR_RANGES
		logval("retained_certainty", ((int)now.retained_certainty));
#endif
		;
		/* merge: sealed_certainty = observed_certainty(266, 260, 266) */
		reached[3][260] = 1;
		(trpt+1)->bup.ovals[7] = ((int)now.sealed_certainty);
		now.sealed_certainty = ((int)now.observed_certainty);
#ifdef VAR_RANGES
		logval("sealed_certainty", ((int)now.sealed_certainty));
#endif
		;
		/* merge: assert((receipt&&(effect_state==Completed)))(266, 261, 266) */
		reached[3][261] = 1;
		spin_assert((((int)now.receipt)&&(now.effect_state==11)), "(receipt&&(effect_state==11))", II, tt, t);
		_m = 3; goto P999; /* 9 */
	case 110: // STATE 262 - governed-local.pml:342 - [((!((((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))&&local_withheld))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][262] = 1;
		if (!(( !((((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch))))&&((int)now.local_withheld))))
			continue;
		/* merge: completed_while_revoked = 1(550, 263, 550) */
		reached[3][263] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)completed_while_revoked);
		completed_while_revoked = 1;
#ifdef VAR_RANGES
		logval("completed_while_revoked", ((int)completed_while_revoked));
#endif
		;
		/* merge: .(goto)(550, 267, 550) */
		reached[3][267] = 1;
		;
		/* merge: pc = 11(550, 268, 550) */
		reached[3][268] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 11;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 111: // STATE 265 - governed-local.pml:343 - [(1)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][265] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 267, 550) */
		reached[3][267] = 1;
		;
		/* merge: pc = 11(550, 268, 550) */
		reached[3][268] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 11;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 112: // STATE 268 - governed-local.pml:345 - [pc = 11] (0:550:1 - 3)
		IfNotBlocked
		reached[3][268] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 11;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 113: // STATE 269 - governed-local.pml:346 - [((pc==11))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][269] = 1;
		if (!((((int)now.pc)==11)))
			continue;
		/* merge: protocol_output = journal_output(550, 270, 550) */
		reached[3][270] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.protocol_output;
		now.protocol_output = now.journal_output;
#ifdef VAR_RANGES
		logval("protocol_output", now.protocol_output);
#endif
		;
		/* merge: protocol_completed = 1(550, 271, 550) */
		reached[3][271] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.protocol_completed);
		now.protocol_completed = 1;
#ifdef VAR_RANGES
		logval("protocol_completed", ((int)now.protocol_completed));
#endif
		;
		/* merge: pc = 12(550, 272, 550) */
		reached[3][272] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 12;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 114: // STATE 273 - governed-local.pml:354 - [((pc==12))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][273] = 1;
		if (!((((int)now.pc)==12)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 115: // STATE 274 - governed-local.pml:357 - [forwarded_parent = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][274] = 1;
		(trpt+1)->bup.oval = ((int)now.forwarded_parent);
		now.forwarded_parent = 1;
#ifdef VAR_RANGES
		logval("forwarded_parent", ((int)now.forwarded_parent));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 116: // STATE 275 - governed-local.pml:357 - [forwarded_parent = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][275] = 1;
		(trpt+1)->bup.oval = ((int)now.forwarded_parent);
		now.forwarded_parent = 2;
#ifdef VAR_RANGES
		logval("forwarded_parent", ((int)now.forwarded_parent));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 117: // STATE 278 - governed-local.pml:358 - [forwarded_actor = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][278] = 1;
		(trpt+1)->bup.oval = ((int)now.forwarded_actor);
		now.forwarded_actor = 1;
#ifdef VAR_RANGES
		logval("forwarded_actor", ((int)now.forwarded_actor));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 118: // STATE 279 - governed-local.pml:358 - [forwarded_actor = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][279] = 1;
		(trpt+1)->bup.oval = ((int)now.forwarded_actor);
		now.forwarded_actor = 2;
#ifdef VAR_RANGES
		logval("forwarded_actor", ((int)now.forwarded_actor));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 119: // STATE 282 - governed-local.pml:360 - [((local_withheld&&((forwarded_parent!=1)||(forwarded_actor!=1))))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][282] = 1;
		if (!((((int)now.local_withheld)&&((((int)now.forwarded_parent)!=1)||(((int)now.forwarded_actor)!=1)))))
			continue;
		/* merge: forwarded_certainty = 0(550, 283, 550) */
		reached[3][283] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.forwarded_certainty);
		now.forwarded_certainty = 0;
#ifdef VAR_RANGES
		logval("forwarded_certainty", ((int)now.forwarded_certainty));
#endif
		;
		/* merge: .(goto)(550, 287, 550) */
		reached[3][287] = 1;
		;
		/* merge: assert(((!(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0)))(550, 288, 550) */
		reached[3][288] = 1;
		spin_assert((( !(((int)now.local_withheld))||((((int)now.forwarded_parent)==1)&&(((int)now.forwarded_actor)==1)))||(((int)now.forwarded_certainty)==0)), "(( !(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0))", II, tt, t);
		/* merge: pc = 13(550, 289, 550) */
		reached[3][289] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 120: // STATE 285 - governed-local.pml:366 - [forwarded_certainty = retained_certainty] (0:550:2 - 1)
		IfNotBlocked
		reached[3][285] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.forwarded_certainty);
		now.forwarded_certainty = ((int)now.retained_certainty);
#ifdef VAR_RANGES
		logval("forwarded_certainty", ((int)now.forwarded_certainty));
#endif
		;
		/* merge: .(goto)(550, 287, 550) */
		reached[3][287] = 1;
		;
		/* merge: assert(((!(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0)))(550, 288, 550) */
		reached[3][288] = 1;
		spin_assert((( !(((int)now.local_withheld))||((((int)now.forwarded_parent)==1)&&(((int)now.forwarded_actor)==1)))||(((int)now.forwarded_certainty)==0)), "(( !(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0))", II, tt, t);
		/* merge: pc = 13(550, 289, 550) */
		reached[3][289] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 121: // STATE 288 - governed-local.pml:368 - [assert(((!(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0)))] (0:550:1 - 3)
		IfNotBlocked
		reached[3][288] = 1;
		spin_assert((( !(((int)now.local_withheld))||((((int)now.forwarded_parent)==1)&&(((int)now.forwarded_actor)==1)))||(((int)now.forwarded_certainty)==0)), "(( !(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0))", II, tt, t);
		/* merge: pc = 13(550, 289, 550) */
		reached[3][289] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 122: // STATE 290 - governed-local.pml:370 - [((pc==13))] (332:0:1 - 1)
		IfNotBlocked
		reached[3][290] = 1;
		if (!((((int)now.pc)==13)))
			continue;
		/* merge: delivery_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(332, 291, 332) */
		reached[3][291] = 1;
		(trpt+1)->bup.oval = ((int)now.delivery_check);
		now.delivery_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("delivery_check", ((int)now.delivery_check));
#endif
		;
		/* merge: assert((!(delivery_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(332, 292, 332) */
		reached[3][292] = 1;
		spin_assert(( !(((int)now.delivery_check))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(delivery_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 123: // STATE 293 - governed-local.pml:377 - [(delivery_check)] (0:0:0 - 1)
		IfNotBlocked
		reached[3][293] = 1;
		if (!(((int)now.delivery_check)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 124: // STATE 294 - governed-local.pml:379 - [(retained_withheld)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][294] = 1;
		if (!(((int)now.retained_withheld)))
			continue;
		/* merge: pc = 14(0, 295, 550) */
		reached[3][295] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 14;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 300, 550) */
		reached[3][300] = 1;
		;
		/* merge: .(goto)(0, 333, 550) */
		reached[3][333] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 125: // STATE 296 - governed-local.pml:380 - [(!(retained_withheld))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][296] = 1;
		if (!( !(((int)now.retained_withheld))))
			continue;
		/* merge: inspection_precheck = delivery_check(550, 297, 550) */
		reached[3][297] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_precheck);
		now.inspection_precheck = ((int)now.delivery_check);
#ifdef VAR_RANGES
		logval("inspection_precheck", ((int)now.inspection_precheck));
#endif
		;
		/* merge: pc = 36(550, 298, 550) */
		reached[3][298] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 36;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 300, 550) */
		reached[3][300] = 1;
		;
		/* merge: .(goto)(0, 333, 550) */
		reached[3][333] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 126: // STATE 301 - governed-local.pml:382 - [(!(delivery_check))] (331:0:1 - 1)
		IfNotBlocked
		reached[3][301] = 1;
		if (!( !(((int)now.delivery_check))))
			continue;
		/* merge: terminal = Denied(0, 302, 331) */
		reached[3][302] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 127: // STATE 303 - governed-local.pml:203 - [(replayed)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][303] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 304, 550) */
		reached[3][304] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 330, 550) */
		reached[3][330] = 1;
		;
		/* merge: .(goto)(0, 333, 550) */
		reached[3][333] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 128: // STATE 305 - governed-local.pml:204 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][305] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 129: // STATE 306 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][306] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 130: // STATE 307 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][307] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 131: // STATE 308 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][308] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 132: // STATE 311 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][311] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 133: // STATE 312 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][312] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 134: // STATE 315 - governed-local.pml:158 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][315] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 325, 550) */
		reached[3][325] = 1;
		;
		/* merge: sealed_calls = calls(550, 326, 550) */
		reached[3][326] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 327, 550) */
		reached[3][327] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 330, 550) */
		reached[3][330] = 1;
		;
		/* merge: .(goto)(0, 333, 550) */
		reached[3][333] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 135: // STATE 316 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:322:2 - 1)
		IfNotBlocked
		reached[3][316] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(322, 317, 322) */
		reached[3][317] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 136: // STATE 318 - governed-local.pml:160 - [((grant_epoch==2))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][318] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(550, 319, 550) */
		reached[3][319] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)epoch_refreshed);
		epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)epoch_refreshed));
#endif
		;
		/* merge: .(goto)(550, 323, 550) */
		reached[3][323] = 1;
		;
		/* merge: .(goto)(550, 325, 550) */
		reached[3][325] = 1;
		;
		/* merge: sealed_calls = calls(550, 326, 550) */
		reached[3][326] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 327, 550) */
		reached[3][327] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 330, 550) */
		reached[3][330] = 1;
		;
		/* merge: .(goto)(0, 333, 550) */
		reached[3][333] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 137: // STATE 321 - governed-local.pml:160 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][321] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 323, 550) */
		reached[3][323] = 1;
		;
		/* merge: .(goto)(550, 325, 550) */
		reached[3][325] = 1;
		;
		/* merge: sealed_calls = calls(550, 326, 550) */
		reached[3][326] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 327, 550) */
		reached[3][327] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 330, 550) */
		reached[3][330] = 1;
		;
		/* merge: .(goto)(0, 333, 550) */
		reached[3][333] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 138: // STATE 326 - governed-local.pml:162 - [sealed_calls = calls] (0:550:2 - 5)
		IfNotBlocked
		reached[3][326] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 327, 550) */
		reached[3][327] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 330, 550) */
		reached[3][330] = 1;
		;
		/* merge: .(goto)(0, 333, 550) */
		reached[3][333] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 139: // STATE 334 - governed-local.pml:384 - [((pc==36))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][334] = 1;
		if (!((((int)now.pc)==36)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 140: // STATE 335 - governed-local.pml:171 - [inspection_complete = 1] (0:344:4 - 1)
		IfNotBlocked
		reached[3][335] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 1;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: inspection_exact = 1(344, 336, 344) */
		reached[3][336] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_exact);
		now.inspection_exact = 1;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: inspection_clean = 1(344, 337, 344) */
		reached[3][337] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inspection_clean);
		now.inspection_clean = 1;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: inspection_original_positive = 0(344, 338, 344) */
		reached[3][338] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 0;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 141: // STATE 339 - governed-local.pml:174 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][339] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 345, 550) */
		reached[3][345] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 346, 550) */
		reached[3][346] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 347, 550) */
		reached[3][347] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(550, 349, 550) */
		reached[3][349] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 142: // STATE 340 - governed-local.pml:175 - [inspection_original_positive = 1] (0:550:3 - 1)
		IfNotBlocked
		reached[3][340] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 1;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		/* merge: .(goto)(550, 345, 550) */
		reached[3][345] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 346, 550) */
		reached[3][346] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 347, 550) */
		reached[3][347] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(550, 349, 550) */
		reached[3][349] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 143: // STATE 341 - governed-local.pml:176 - [inspection_complete = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][341] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 0;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: .(goto)(550, 345, 550) */
		reached[3][345] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 346, 550) */
		reached[3][346] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 347, 550) */
		reached[3][347] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(550, 349, 550) */
		reached[3][349] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 144: // STATE 342 - governed-local.pml:177 - [inspection_exact = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][342] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_exact);
		now.inspection_exact = 0;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: .(goto)(550, 345, 550) */
		reached[3][345] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 346, 550) */
		reached[3][346] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 347, 550) */
		reached[3][347] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(550, 349, 550) */
		reached[3][349] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 145: // STATE 343 - governed-local.pml:178 - [inspection_clean = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][343] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_clean);
		now.inspection_clean = 0;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: .(goto)(550, 345, 550) */
		reached[3][345] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 346, 550) */
		reached[3][346] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 347, 550) */
		reached[3][347] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(550, 349, 550) */
		reached[3][349] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 146: // STATE 346 - governed-local.pml:180 - [inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)] (0:550:2 - 6)
		IfNotBlocked
		reached[3][346] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 347, 550) */
		reached[3][347] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(550, 349, 550) */
		reached[3][349] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 147: // STATE 350 - governed-local.pml:385 - [((pc==37))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][350] = 1;
		if (!((((int)now.pc)==37)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 148: // STATE 351 - governed-local.pml:194 - [inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))] (0:388:2 - 1)
		IfNotBlocked
		reached[3][351] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_postcheck);
		now.inspection_postcheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_postcheck", ((int)now.inspection_postcheck));
#endif
		;
		/* merge: assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(388, 352, 388) */
		reached[3][352] = 1;
		spin_assert(( !(((int)now.inspection_postcheck))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		/* merge: delivery_check = (inspection_accepted&&inspection_postcheck)(388, 354, 388) */
		reached[3][354] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.delivery_check);
		now.delivery_check = (((int)now.inspection_accepted)&&((int)now.inspection_postcheck));
#ifdef VAR_RANGES
		logval("delivery_check", ((int)now.delivery_check));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 149: // STATE 355 - governed-local.pml:389 - [(delivery_check)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][355] = 1;
		if (!(((int)now.delivery_check)))
			continue;
		/* merge: pc = 14(0, 356, 550) */
		reached[3][356] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 14;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 389, 550) */
		reached[3][389] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 150: // STATE 357 - governed-local.pml:390 - [(!(delivery_check))] (387:0:1 - 1)
		IfNotBlocked
		reached[3][357] = 1;
		if (!( !(((int)now.delivery_check))))
			continue;
		/* merge: terminal = Denied(0, 358, 387) */
		reached[3][358] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 151: // STATE 359 - governed-local.pml:203 - [(replayed)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][359] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 360, 550) */
		reached[3][360] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 386, 550) */
		reached[3][386] = 1;
		;
		/* merge: .(goto)(0, 389, 550) */
		reached[3][389] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 152: // STATE 361 - governed-local.pml:204 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][361] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 153: // STATE 362 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][362] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 154: // STATE 363 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][363] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 155: // STATE 364 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][364] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 156: // STATE 367 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][367] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 157: // STATE 368 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][368] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 158: // STATE 371 - governed-local.pml:158 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][371] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 381, 550) */
		reached[3][381] = 1;
		;
		/* merge: sealed_calls = calls(550, 382, 550) */
		reached[3][382] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 383, 550) */
		reached[3][383] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 386, 550) */
		reached[3][386] = 1;
		;
		/* merge: .(goto)(0, 389, 550) */
		reached[3][389] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 159: // STATE 372 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:378:2 - 1)
		IfNotBlocked
		reached[3][372] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(378, 373, 378) */
		reached[3][373] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 160: // STATE 374 - governed-local.pml:160 - [((grant_epoch==2))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][374] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(550, 375, 550) */
		reached[3][375] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)epoch_refreshed);
		epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)epoch_refreshed));
#endif
		;
		/* merge: .(goto)(550, 379, 550) */
		reached[3][379] = 1;
		;
		/* merge: .(goto)(550, 381, 550) */
		reached[3][381] = 1;
		;
		/* merge: sealed_calls = calls(550, 382, 550) */
		reached[3][382] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 383, 550) */
		reached[3][383] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 386, 550) */
		reached[3][386] = 1;
		;
		/* merge: .(goto)(0, 389, 550) */
		reached[3][389] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 161: // STATE 377 - governed-local.pml:160 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][377] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 379, 550) */
		reached[3][379] = 1;
		;
		/* merge: .(goto)(550, 381, 550) */
		reached[3][381] = 1;
		;
		/* merge: sealed_calls = calls(550, 382, 550) */
		reached[3][382] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 383, 550) */
		reached[3][383] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 386, 550) */
		reached[3][386] = 1;
		;
		/* merge: .(goto)(0, 389, 550) */
		reached[3][389] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 162: // STATE 382 - governed-local.pml:162 - [sealed_calls = calls] (0:550:2 - 5)
		IfNotBlocked
		reached[3][382] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 383, 550) */
		reached[3][383] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 386, 550) */
		reached[3][386] = 1;
		;
		/* merge: .(goto)(0, 389, 550) */
		reached[3][389] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 163: // STATE 390 - governed-local.pml:392 - [((pc==14))] (422:0:2 - 1)
		IfNotBlocked
		reached[3][390] = 1;
		if (!((((int)now.pc)==14)))
			continue;
		/* merge: assert((delivery_check&&(attempt_tenant==1)))(422, 391, 422) */
		reached[3][391] = 1;
		spin_assert((((int)now.delivery_check)&&(((int)now.attempt_tenant)==1)), "(delivery_check&&(attempt_tenant==1))", II, tt, t);
		/* merge: delivered_once = 1(422, 392, 422) */
		reached[3][392] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)delivered_once);
		delivered_once = 1;
#ifdef VAR_RANGES
		logval("delivered_once", ((int)delivered_once));
#endif
		;
		/* merge: terminal = Delivered(422, 393, 422) */
		reached[3][393] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 3;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 164: // STATE 394 - governed-local.pml:203 - [(replayed)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][394] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 395, 550) */
		reached[3][395] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 421, 550) */
		reached[3][421] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 165: // STATE 396 - governed-local.pml:204 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][396] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 166: // STATE 397 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][397] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 167: // STATE 398 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][398] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 168: // STATE 399 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][399] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 169: // STATE 402 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][402] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 170: // STATE 403 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][403] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 171: // STATE 406 - governed-local.pml:158 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][406] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 416, 550) */
		reached[3][416] = 1;
		;
		/* merge: sealed_calls = calls(550, 417, 550) */
		reached[3][417] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 418, 550) */
		reached[3][418] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 421, 550) */
		reached[3][421] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 172: // STATE 407 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:413:2 - 1)
		IfNotBlocked
		reached[3][407] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(413, 408, 413) */
		reached[3][408] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 173: // STATE 409 - governed-local.pml:160 - [((grant_epoch==2))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][409] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(550, 410, 550) */
		reached[3][410] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)epoch_refreshed);
		epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)epoch_refreshed));
#endif
		;
		/* merge: .(goto)(550, 414, 550) */
		reached[3][414] = 1;
		;
		/* merge: .(goto)(550, 416, 550) */
		reached[3][416] = 1;
		;
		/* merge: sealed_calls = calls(550, 417, 550) */
		reached[3][417] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 418, 550) */
		reached[3][418] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 421, 550) */
		reached[3][421] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 174: // STATE 412 - governed-local.pml:160 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][412] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 414, 550) */
		reached[3][414] = 1;
		;
		/* merge: .(goto)(550, 416, 550) */
		reached[3][416] = 1;
		;
		/* merge: sealed_calls = calls(550, 417, 550) */
		reached[3][417] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 418, 550) */
		reached[3][418] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 421, 550) */
		reached[3][421] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 175: // STATE 417 - governed-local.pml:162 - [sealed_calls = calls] (0:550:2 - 5)
		IfNotBlocked
		reached[3][417] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(550, 418, 550) */
		reached[3][418] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 421, 550) */
		reached[3][421] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 176: // STATE 423 - governed-local.pml:395 - [((pc==30))] (430:0:1 - 1)
		IfNotBlocked
		reached[3][423] = 1;
		if (!((((int)now.pc)==30)))
			continue;
		/* merge: inspection_precheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 424, 430) */
		reached[3][424] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_precheck);
		now.inspection_precheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_precheck", ((int)now.inspection_precheck));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 177: // STATE 425 - governed-local.pml:398 - [(inspection_precheck)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][425] = 1;
		if (!(((int)now.inspection_precheck)))
			continue;
		/* merge: pc = 31(0, 426, 550) */
		reached[3][426] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 31;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 431, 550) */
		reached[3][431] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 178: // STATE 427 - governed-local.pml:399 - [(!(inspection_precheck))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][427] = 1;
		if (!( !(((int)now.inspection_precheck))))
			continue;
		/* merge: terminal = Denied(550, 428, 550) */
		reached[3][428] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 429, 550) */
		reached[3][429] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 431, 550) */
		reached[3][431] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 179: // STATE 432 - governed-local.pml:401 - [((pc==31))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][432] = 1;
		if (!((((int)now.pc)==31)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 180: // STATE 433 - governed-local.pml:171 - [inspection_complete = 1] (0:442:4 - 1)
		IfNotBlocked
		reached[3][433] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 1;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: inspection_exact = 1(442, 434, 442) */
		reached[3][434] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_exact);
		now.inspection_exact = 1;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: inspection_clean = 1(442, 435, 442) */
		reached[3][435] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inspection_clean);
		now.inspection_clean = 1;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: inspection_original_positive = 0(442, 436, 442) */
		reached[3][436] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 0;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 181: // STATE 437 - governed-local.pml:174 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][437] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 443, 550) */
		reached[3][443] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 444, 550) */
		reached[3][444] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 445, 550) */
		reached[3][445] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(550, 447, 550) */
		reached[3][447] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 182: // STATE 438 - governed-local.pml:175 - [inspection_original_positive = 1] (0:550:3 - 1)
		IfNotBlocked
		reached[3][438] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 1;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		/* merge: .(goto)(550, 443, 550) */
		reached[3][443] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 444, 550) */
		reached[3][444] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 445, 550) */
		reached[3][445] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(550, 447, 550) */
		reached[3][447] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 183: // STATE 439 - governed-local.pml:176 - [inspection_complete = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][439] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 0;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: .(goto)(550, 443, 550) */
		reached[3][443] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 444, 550) */
		reached[3][444] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 445, 550) */
		reached[3][445] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(550, 447, 550) */
		reached[3][447] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 184: // STATE 440 - governed-local.pml:177 - [inspection_exact = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][440] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_exact);
		now.inspection_exact = 0;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: .(goto)(550, 443, 550) */
		reached[3][443] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 444, 550) */
		reached[3][444] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 445, 550) */
		reached[3][445] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(550, 447, 550) */
		reached[3][447] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 185: // STATE 441 - governed-local.pml:178 - [inspection_clean = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][441] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_clean);
		now.inspection_clean = 0;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: .(goto)(550, 443, 550) */
		reached[3][443] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 444, 550) */
		reached[3][444] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 445, 550) */
		reached[3][445] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(550, 447, 550) */
		reached[3][447] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 186: // STATE 444 - governed-local.pml:180 - [inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)] (0:550:2 - 6)
		IfNotBlocked
		reached[3][444] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 445, 550) */
		reached[3][445] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(550, 447, 550) */
		reached[3][447] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 187: // STATE 448 - governed-local.pml:402 - [((pc==32))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][448] = 1;
		if (!((((int)now.pc)==32)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 188: // STATE 449 - governed-local.pml:194 - [inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))] (0:465:1 - 1)
		IfNotBlocked
		reached[3][449] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_postcheck);
		now.inspection_postcheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_postcheck", ((int)now.inspection_postcheck));
#endif
		;
		/* merge: assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(465, 450, 465) */
		reached[3][450] = 1;
		spin_assert(( !(((int)now.inspection_postcheck))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 189: // STATE 452 - governed-local.pml:405 - [((inspection_accepted&&inspection_postcheck))] (458:0:1 - 1)
		IfNotBlocked
		reached[3][452] = 1;
		if (!((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))))
			continue;
		/* merge: input_inspected = 1(0, 453, 458) */
		reached[3][453] = 1;
		(trpt+1)->bup.oval = ((int)now.input_inspected);
		now.input_inspected = 1;
#ifdef VAR_RANGES
		logval("input_inspected", ((int)now.input_inspected));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 190: // STATE 454 - governed-local.pml:408 - [(inspection_original_positive)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][454] = 1;
		if (!(((int)now.inspection_original_positive)))
			continue;
		/* merge: positive_original_projected = 1(550, 455, 550) */
		reached[3][455] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)positive_original_projected);
		positive_original_projected = 1;
#ifdef VAR_RANGES
		logval("positive_original_projected", ((int)positive_original_projected));
#endif
		;
		/* merge: .(goto)(550, 459, 550) */
		reached[3][459] = 1;
		;
		/* merge: pc = 1(550, 460, 550) */
		reached[3][460] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 466, 550) */
		reached[3][466] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 191: // STATE 457 - governed-local.pml:409 - [(1)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][457] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 459, 550) */
		reached[3][459] = 1;
		;
		/* merge: pc = 1(550, 460, 550) */
		reached[3][460] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 466, 550) */
		reached[3][466] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 192: // STATE 460 - governed-local.pml:411 - [pc = 1] (0:550:1 - 3)
		IfNotBlocked
		reached[3][460] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 466, 550) */
		reached[3][466] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 193: // STATE 461 - governed-local.pml:412 - [((!(inspection_accepted)||!(inspection_postcheck)))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][461] = 1;
		if (!(( !(((int)now.inspection_accepted))|| !(((int)now.inspection_postcheck)))))
			continue;
		/* merge: inspection_denied = 1(550, 462, 550) */
		reached[3][462] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)inspection_denied);
		inspection_denied = 1;
#ifdef VAR_RANGES
		logval("inspection_denied", ((int)inspection_denied));
#endif
		;
		/* merge: terminal = Denied(550, 463, 550) */
		reached[3][463] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 464, 550) */
		reached[3][464] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 466, 550) */
		reached[3][466] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 194: // STATE 467 - governed-local.pml:415 - [((pc==40))] (474:0:1 - 1)
		IfNotBlocked
		reached[3][467] = 1;
		if (!((((int)now.pc)==40)))
			continue;
		/* merge: inspection_precheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 468, 474) */
		reached[3][468] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_precheck);
		now.inspection_precheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_precheck", ((int)now.inspection_precheck));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 195: // STATE 469 - governed-local.pml:418 - [(inspection_precheck)] (550:0:1 - 1)
		IfNotBlocked
		reached[3][469] = 1;
		if (!(((int)now.inspection_precheck)))
			continue;
		/* merge: pc = 41(0, 470, 550) */
		reached[3][470] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 41;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 475, 550) */
		reached[3][475] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 196: // STATE 471 - governed-local.pml:419 - [(!(inspection_precheck))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][471] = 1;
		if (!( !(((int)now.inspection_precheck))))
			continue;
		/* merge: terminal = Denied(550, 472, 550) */
		reached[3][472] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 473, 550) */
		reached[3][473] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 475, 550) */
		reached[3][475] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 197: // STATE 476 - governed-local.pml:421 - [((pc==41))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][476] = 1;
		if (!((((int)now.pc)==41)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 198: // STATE 477 - governed-local.pml:171 - [inspection_complete = 1] (0:486:4 - 1)
		IfNotBlocked
		reached[3][477] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 1;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: inspection_exact = 1(486, 478, 486) */
		reached[3][478] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_exact);
		now.inspection_exact = 1;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: inspection_clean = 1(486, 479, 486) */
		reached[3][479] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inspection_clean);
		now.inspection_clean = 1;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: inspection_original_positive = 0(486, 480, 486) */
		reached[3][480] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 0;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 199: // STATE 481 - governed-local.pml:174 - [(1)] (550:0:2 - 1)
		IfNotBlocked
		reached[3][481] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(550, 487, 550) */
		reached[3][487] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 488, 550) */
		reached[3][488] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 489, 550) */
		reached[3][489] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(550, 491, 550) */
		reached[3][491] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 200: // STATE 482 - governed-local.pml:175 - [inspection_original_positive = 1] (0:550:3 - 1)
		IfNotBlocked
		reached[3][482] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 1;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		/* merge: .(goto)(550, 487, 550) */
		reached[3][487] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 488, 550) */
		reached[3][488] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 489, 550) */
		reached[3][489] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(550, 491, 550) */
		reached[3][491] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 201: // STATE 483 - governed-local.pml:176 - [inspection_complete = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][483] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 0;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: .(goto)(550, 487, 550) */
		reached[3][487] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 488, 550) */
		reached[3][488] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 489, 550) */
		reached[3][489] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(550, 491, 550) */
		reached[3][491] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 202: // STATE 484 - governed-local.pml:177 - [inspection_exact = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][484] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_exact);
		now.inspection_exact = 0;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: .(goto)(550, 487, 550) */
		reached[3][487] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 488, 550) */
		reached[3][488] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 489, 550) */
		reached[3][489] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(550, 491, 550) */
		reached[3][491] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 203: // STATE 485 - governed-local.pml:178 - [inspection_clean = 0] (0:550:3 - 1)
		IfNotBlocked
		reached[3][485] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_clean);
		now.inspection_clean = 0;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: .(goto)(550, 487, 550) */
		reached[3][487] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(550, 488, 550) */
		reached[3][488] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 489, 550) */
		reached[3][489] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(550, 491, 550) */
		reached[3][491] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 204: // STATE 488 - governed-local.pml:180 - [inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)] (0:550:2 - 6)
		IfNotBlocked
		reached[3][488] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(550, 489, 550) */
		reached[3][489] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(550, 491, 550) */
		reached[3][491] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 205: // STATE 492 - governed-local.pml:422 - [((pc==42))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][492] = 1;
		if (!((((int)now.pc)==42)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 206: // STATE 493 - governed-local.pml:194 - [inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))] (0:503:1 - 1)
		IfNotBlocked
		reached[3][493] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_postcheck);
		now.inspection_postcheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_postcheck", ((int)now.inspection_postcheck));
#endif
		;
		/* merge: assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(503, 494, 503) */
		reached[3][494] = 1;
		spin_assert(( !(((int)now.inspection_postcheck))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 207: // STATE 496 - governed-local.pml:425 - [((inspection_accepted&&inspection_postcheck))] (550:0:2 - 1)
		IfNotBlocked
		reached[3][496] = 1;
		if (!((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))))
			continue;
		/* merge: outbound_inspected = 1(550, 497, 550) */
		reached[3][497] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.outbound_inspected);
		now.outbound_inspected = 1;
#ifdef VAR_RANGES
		logval("outbound_inspected", ((int)now.outbound_inspected));
#endif
		;
		/* merge: pc = 4(550, 498, 550) */
		reached[3][498] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 504, 550) */
		reached[3][504] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 208: // STATE 499 - governed-local.pml:426 - [((!(inspection_accepted)||!(inspection_postcheck)))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][499] = 1;
		if (!(( !(((int)now.inspection_accepted))|| !(((int)now.inspection_postcheck)))))
			continue;
		/* merge: inspection_denied = 1(550, 500, 550) */
		reached[3][500] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)inspection_denied);
		inspection_denied = 1;
#ifdef VAR_RANGES
		logval("inspection_denied", ((int)inspection_denied));
#endif
		;
		/* merge: terminal = Denied(550, 501, 550) */
		reached[3][501] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 502, 550) */
		reached[3][502] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 504, 550) */
		reached[3][504] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 209: // STATE 505 - governed-local.pml:429 - [((pc==20))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][505] = 1;
		if (!((((int)now.pc)==20)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 210: // STATE 506 - governed-local.pml:434 - [((attempt_tenant!=1))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][506] = 1;
		if (!((((int)now.attempt_tenant)!=1)))
			continue;
		/* merge: foreign_denied = 1(550, 507, 550) */
		reached[3][507] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)foreign_denied);
		foreign_denied = 1;
#ifdef VAR_RANGES
		logval("foreign_denied", ((int)foreign_denied));
#endif
		;
		/* merge: terminal = Denied(550, 508, 550) */
		reached[3][508] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 509, 550) */
		reached[3][509] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 520, 550) */
		reached[3][520] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 211: // STATE 510 - governed-local.pml:440 - [((attempt_tenant==1))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][510] = 1;
		if (!((((int)now.attempt_tenant)==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 212: // STATE 511 - governed-local.pml:442 - [((attempt_original!=bound_original))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][511] = 1;
		if (!((((int)now.attempt_original)!=((int)now.bound_original))))
			continue;
		/* merge: input_conflict = 1(550, 512, 550) */
		reached[3][512] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)input_conflict);
		input_conflict = 1;
#ifdef VAR_RANGES
		logval("input_conflict", ((int)input_conflict));
#endif
		;
		/* merge: terminal = Denied(550, 513, 550) */
		reached[3][513] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 514, 550) */
		reached[3][514] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 518, 550) */
		reached[3][518] = 1;
		;
		/* merge: .(goto)(0, 520, 550) */
		reached[3][520] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 213: // STATE 515 - governed-local.pml:449 - [((attempt_original==bound_original))] (550:0:1 - 1)
		IfNotBlocked
		reached[3][515] = 1;
		if (!((((int)now.attempt_original)==((int)now.bound_original))))
			continue;
		/* merge: pc = 21(0, 516, 550) */
		reached[3][516] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 21;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 518, 550) */
		reached[3][518] = 1;
		;
		/* merge: .(goto)(0, 520, 550) */
		reached[3][520] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 214: // STATE 521 - governed-local.pml:452 - [((pc==21))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][521] = 1;
		if (!((((int)now.pc)==21)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 215: // STATE 522 - governed-local.pml:454 - [((effect_state==Unknown))] (550:0:3 - 1)
		IfNotBlocked
		reached[3][522] = 1;
		if (!((now.effect_state==10)))
			continue;
		/* merge: assert((calls==sealed_calls))(550, 523, 550) */
		reached[3][523] = 1;
		spin_assert((((int)now.calls)==((int)now.sealed_calls)), "(calls==sealed_calls)", II, tt, t);
		/* merge: unknown_retry_blocked = 1(550, 524, 550) */
		reached[3][524] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)unknown_retry_blocked);
		unknown_retry_blocked = 1;
#ifdef VAR_RANGES
		logval("unknown_retry_blocked", ((int)unknown_retry_blocked));
#endif
		;
		/* merge: terminal = Blocked(550, 525, 550) */
		reached[3][525] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(550, 526, 550) */
		reached[3][526] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 534, 550) */
		reached[3][534] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 216: // STATE 527 - governed-local.pml:460 - [((effect_state==Completed))] (550:0:4 - 1)
		IfNotBlocked
		reached[3][527] = 1;
		if (!((now.effect_state==11)))
			continue;
		/* merge: assert((effect_state==Completed))(550, 528, 550) */
		reached[3][528] = 1;
		spin_assert((now.effect_state==11), "(effect_state==11)", II, tt, t);
		/* merge: replayed = 1(550, 529, 550) */
		reached[3][529] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: protocol_output = journal_output(550, 530, 550) */
		reached[3][530] = 1;
		(trpt+1)->bup.ovals[1] = now.protocol_output;
		now.protocol_output = now.journal_output;
#ifdef VAR_RANGES
		logval("protocol_output", now.protocol_output);
#endif
		;
		/* merge: protocol_completed = 1(550, 531, 550) */
		reached[3][531] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.protocol_completed);
		now.protocol_completed = 1;
#ifdef VAR_RANGES
		logval("protocol_completed", ((int)now.protocol_completed));
#endif
		;
		/* merge: pc = 13(550, 532, 550) */
		reached[3][532] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 534, 550) */
		reached[3][534] = 1;
		;
		/* merge: .(goto)(0, 536, 550) */
		reached[3][536] = 1;
		;
		/* merge: .(goto)(0, 538, 550) */
		reached[3][538] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 217: // STATE 539 - governed-local.pml:93 - [assert((calls<=1))] (0:552:0 - 1)
		IfNotBlocked
		reached[3][539] = 1;
		spin_assert((((int)now.calls)<=1), "(calls<=1)", II, tt, t);
		/* merge: assert(((journal_input!=Raw)&&(protocol_input!=Raw)))(552, 540, 552) */
		reached[3][540] = 1;
		spin_assert(((now.journal_input!=7)&&(now.protocol_input!=7)), "((journal_input!=7)&&(protocol_input!=7))", II, tt, t);
		/* merge: assert((((journal_output!=Raw)&&(protocol_output!=Raw))&&(receipt_payload!=Raw)))(552, 541, 552) */
		reached[3][541] = 1;
		spin_assert((((now.journal_output!=7)&&(now.protocol_output!=7))&&(now.receipt_payload!=7)), "(((journal_output!=7)&&(protocol_output!=7))&&(receipt_payload!=7))", II, tt, t);
		/* merge: assert(((bound_original==0)||(bound_original==1)))(552, 542, 552) */
		reached[3][542] = 1;
		spin_assert(((((int)now.bound_original)==0)||(((int)now.bound_original)==1)), "((bound_original==0)||(bound_original==1))", II, tt, t);
		/* merge: assert((receipt==(effect_state==Completed)))(552, 543, 552) */
		reached[3][543] = 1;
		spin_assert((((int)now.receipt)==(now.effect_state==11)), "(receipt==(effect_state==11))", II, tt, t);
		/* merge: assert((!(receipt)||(retained_certainty==sealed_certainty)))(552, 544, 552) */
		reached[3][544] = 1;
		spin_assert(( !(((int)now.receipt))||(((int)now.retained_certainty)==((int)now.sealed_certainty))), "( !(receipt)||(retained_certainty==sealed_certainty))", II, tt, t);
		/* merge: assert((!(receipt)||(retained_withheld==sealed_withheld)))(552, 545, 552) */
		reached[3][545] = 1;
		spin_assert(( !(((int)now.receipt))||(((int)now.retained_withheld)==((int)now.sealed_withheld))), "( !(receipt)||(retained_withheld==sealed_withheld))", II, tt, t);
		/* merge: assert((!(receipt)||(retained_certainty==observed_certainty)))(552, 546, 552) */
		reached[3][546] = 1;
		spin_assert(( !(((int)now.receipt))||(((int)now.retained_certainty)==((int)now.observed_certainty))), "( !(receipt)||(retained_certainty==observed_certainty))", II, tt, t);
		/* merge: assert((!(protocol_completed)||(receipt&&(protocol_output==journal_output))))(552, 547, 552) */
		reached[3][547] = 1;
		spin_assert(( !(((int)now.protocol_completed))||(((int)now.receipt)&&(now.protocol_output==now.journal_output))), "( !(protocol_completed)||(receipt&&(protocol_output==journal_output)))", II, tt, t);
		/* merge: assert((!(replayed)||(calls==sealed_calls)))(552, 548, 552) */
		reached[3][548] = 1;
		spin_assert(( !(((int)now.replayed))||(((int)now.calls)==((int)now.sealed_calls))), "( !(replayed)||(calls==sealed_calls))", II, tt, t);
		/* merge: assert(((terminal!=Delivered)||(delivery_check&&(attempt_tenant==1))))(552, 549, 552) */
		reached[3][549] = 1;
		spin_assert(((now.terminal!=3)||(((int)now.delivery_check)&&(((int)now.attempt_tenant)==1))), "((terminal!=3)||(delivery_check&&(attempt_tenant==1)))", II, tt, t);
		/* merge: .(goto)(0, 553, 552) */
		reached[3][553] = 1;
		;
		_m = 3; goto P999; /* 11 */
	case 218: // STATE 555 - governed-local.pml:516 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[3][555] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC External */
	case 219: // STATE 1 - governed-local.pml:139 - [requests?request_id] (0:0:2 - 1)
		reached[2][1] = 1;
		if (q_len(now.requests) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P2 *)_this)->request_id);
		;
		((P2 *)_this)->request_id = qrecv(now.requests, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("External:request_id", ((int)((P2 *)_this)->request_id));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.requests);
			sprintf(simtmp, "%d", ((int)((P2 *)_this)->request_id)); strcat(simvals, simtmp);
		}
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: request_id */  (trpt+1)->bup.ovals[1] = ((P2 *)_this)->request_id;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->request_id = 0;
		_m = 4; goto P999; /* 0 */
	case 220: // STATE 2 - governed-local.pml:143 - [output = Safe] (0:0:1 - 1)
		IfNotBlocked
		reached[2][2] = 1;
		(trpt+1)->bup.oval = ((P2 *)_this)->output;
		((P2 *)_this)->output = 8;
#ifdef VAR_RANGES
		logval("External:output", ((P2 *)_this)->output);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 221: // STATE 3 - governed-local.pml:143 - [output = Raw] (0:0:1 - 1)
		IfNotBlocked
		reached[2][3] = 1;
		(trpt+1)->bup.oval = ((P2 *)_this)->output;
		((P2 *)_this)->output = 7;
#ifdef VAR_RANGES
		logval("External:output", ((P2 *)_this)->output);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 222: // STATE 4 - governed-local.pml:143 - [output = TransportLost] (0:0:1 - 1)
		IfNotBlocked
		reached[2][4] = 1;
		(trpt+1)->bup.oval = ((P2 *)_this)->output;
		((P2 *)_this)->output = 5;
#ifdef VAR_RANGES
		logval("External:output", ((P2 *)_this)->output);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 223: // STATE 7 - governed-local.pml:144 - [certainty = 0] (0:13:1 - 1)
		IfNotBlocked
		reached[2][7] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->certainty);
		((P2 *)_this)->certainty = 0;
#ifdef VAR_RANGES
		logval("External:certainty", ((int)((P2 *)_this)->certainty));
#endif
		;
		/* merge: .(goto)(13, 12, 13) */
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 224: // STATE 12 - governed-local.pml:145 - [.(goto)] (0:13:0 - 4)
		IfNotBlocked
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 0 */
	case 225: // STATE 8 - governed-local.pml:144 - [certainty = 1] (0:13:1 - 1)
		IfNotBlocked
		reached[2][8] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->certainty);
		((P2 *)_this)->certainty = 1;
#ifdef VAR_RANGES
		logval("External:certainty", ((int)((P2 *)_this)->certainty));
#endif
		;
		/* merge: .(goto)(13, 12, 13) */
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 226: // STATE 9 - governed-local.pml:144 - [certainty = 2] (0:13:1 - 1)
		IfNotBlocked
		reached[2][9] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->certainty);
		((P2 *)_this)->certainty = 2;
#ifdef VAR_RANGES
		logval("External:certainty", ((int)((P2 *)_this)->certainty));
#endif
		;
		/* merge: .(goto)(13, 12, 13) */
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 227: // STATE 10 - governed-local.pml:144 - [certainty = 3] (0:13:1 - 1)
		IfNotBlocked
		reached[2][10] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->certainty);
		((P2 *)_this)->certainty = 3;
#ifdef VAR_RANGES
		logval("External:certainty", ((int)((P2 *)_this)->certainty));
#endif
		;
		/* merge: .(goto)(13, 12, 13) */
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 228: // STATE 13 - governed-local.pml:145 - [results!output,certainty] (0:0:0 - 1)
		IfNotBlocked
		reached[2][13] = 1;
		if (q_full(now.results))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.results);
		sprintf(simtmp, "%d", ((P2 *)_this)->output); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)_this)->certainty)); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.results, 0, ((P2 *)_this)->output, ((int)((P2 *)_this)->certainty), 2);
		_m = 2; goto P999; /* 0 */
	case 229: // STATE 15 - governed-local.pml:147 - [(finished)] (0:0:0 - 1)
		IfNotBlocked
		reached[2][15] = 1;
		if (!(((int)now.finished)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 230: // STATE 19 - governed-local.pml:149 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[2][19] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Crash */
	case 231: // STATE 2 - governed-local.pml:130 - [(!(finished))] (8:0:2 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!( !(((int)now.finished))))
			continue;
		/* merge: crash = 1(8, 3, 8) */
		reached[1][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.crash);
		now.crash = 1;
#ifdef VAR_RANGES
		logval("crash", ((int)now.crash));
#endif
		;
		/* merge: crashed_once = 1(8, 4, 8) */
		reached[1][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)crashed_once);
		crashed_once = 1;
#ifdef VAR_RANGES
		logval("crashed_once", ((int)crashed_once));
#endif
		;
		/* merge: .(goto)(0, 7, 8) */
		reached[1][7] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 232: // STATE 8 - governed-local.pml:132 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[1][8] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Authority */
	case 233: // STATE 2 - governed-local.pml:113 - [(!(finished))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 234: // STATE 3 - governed-local.pml:115 - [grant_active = 0] (0:15:2 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.grant_active);
		now.grant_active = 0;
#ifdef VAR_RANGES
		logval("grant_active", ((int)now.grant_active));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 235: // STATE 10 - governed-local.pml:122 - [.(goto)] (0:15:1 - 6)
		IfNotBlocked
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.oval = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 236: // STATE 4 - governed-local.pml:116 - [authority_available = 0] (0:15:2 - 1)
		IfNotBlocked
		reached[0][4] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.authority_available);
		now.authority_available = 0;
#ifdef VAR_RANGES
		logval("authority_available", ((int)now.authority_available));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 237: // STATE 5 - governed-local.pml:117 - [grant_epoch = 2] (0:15:2 - 1)
		IfNotBlocked
		reached[0][5] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.grant_epoch);
		now.grant_epoch = 2;
#ifdef VAR_RANGES
		logval("grant_epoch", ((int)now.grant_epoch));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 238: // STATE 6 - governed-local.pml:118 - [policy_epoch = 2] (0:15:2 - 1)
		IfNotBlocked
		reached[0][6] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.policy_epoch);
		now.policy_epoch = 2;
#ifdef VAR_RANGES
		logval("policy_epoch", ((int)now.policy_epoch));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 239: // STATE 7 - governed-local.pml:119 - [key_epoch = 2] (0:15:2 - 1)
		IfNotBlocked
		reached[0][7] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.key_epoch);
		now.key_epoch = 2;
#ifdef VAR_RANGES
		logval("key_epoch", ((int)now.key_epoch));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 240: // STATE 8 - governed-local.pml:120 - [credential_epoch = 2] (0:15:2 - 1)
		IfNotBlocked
		reached[0][8] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.credential_epoch);
		now.credential_epoch = 2;
#ifdef VAR_RANGES
		logval("credential_epoch", ((int)now.credential_epoch));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 241: // STATE 15 - governed-local.pml:125 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[0][15] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

