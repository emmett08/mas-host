#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM governed_local_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(finished))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[5][1] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[5][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - governed-local.pml:519 - [(run Host())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][1] = 1;
		if (!(addproc(II, 1, 3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - governed-local.pml:519 - [(run External())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][2] = 1;
		if (!(addproc(II, 1, 2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 3 - governed-local.pml:519 - [(run Authority())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][3] = 1;
		if (!(addproc(II, 1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 4 - governed-local.pml:519 - [(run Crash())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][4] = 1;
		if (!(addproc(II, 1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 6 - governed-local.pml:520 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[4][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Host */
	case 10: // STATE 1 - governed-local.pml:209 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][1] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 2 - governed-local.pml:210 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][2] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 3 - governed-local.pml:212 - [(finished)] (0:0:0 - 1)
		IfNotBlocked
		reached[3][3] = 1;
		if (!(((int)now.finished)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 5 - governed-local.pml:213 - [(!(finished))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][5] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 6 - governed-local.pml:215 - [(crash)] (93:0:2 - 1)
		IfNotBlocked
		reached[3][6] = 1;
		if (!(((int)now.crash)))
			continue;
		/* merge: crash = 0(93, 7, 93) */
		reached[3][7] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.crash);
		now.crash = 0;
#ifdef VAR_RANGES
		logval("crash", ((int)now.crash));
#endif
		;
		/* merge: restarted = 1(93, 8, 93) */
		reached[3][8] = 1;
		(trpt+1)->bup.ovals[1] = ((int)restarted);
		restarted = 1;
#ifdef VAR_RANGES
		logval("restarted", ((int)restarted));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 15: // STATE 9 - governed-local.pml:218 - [((effect_state==Executing))] (35:0:3 - 1)
		IfNotBlocked
		reached[3][9] = 1;
		if (!((now.effect_state==12)))
			continue;
		/* merge: effect_state = Unknown(35, 10, 35) */
		reached[3][10] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 10;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: unknown_seen = 1(35, 11, 35) */
		reached[3][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: terminal = Blocked(35, 12, 35) */
		reached[3][12] = 1;
		(trpt+1)->bup.ovals[2] = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 16: // STATE 13 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][13] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 14 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][14] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 15 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][15] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 18 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][18] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 19 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][19] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 22 - governed-local.pml:158 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][22] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 32, 544) */
		reached[3][32] = 1;
		;
		/* merge: sealed_calls = calls(544, 33, 544) */
		reached[3][33] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 34, 544) */
		reached[3][34] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 22: // STATE 23 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:29:2 - 1)
		IfNotBlocked
		reached[3][23] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(29, 24, 29) */
		reached[3][24] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 23: // STATE 25 - governed-local.pml:160 - [((grant_epoch==2))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][25] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(544, 26, 544) */
		reached[3][26] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.epoch_refreshed);
		now.epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)now.epoch_refreshed));
#endif
		;
		/* merge: .(goto)(544, 30, 544) */
		reached[3][30] = 1;
		;
		/* merge: .(goto)(544, 32, 544) */
		reached[3][32] = 1;
		;
		/* merge: sealed_calls = calls(544, 33, 544) */
		reached[3][33] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 34, 544) */
		reached[3][34] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 24: // STATE 28 - governed-local.pml:160 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][28] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 30, 544) */
		reached[3][30] = 1;
		;
		/* merge: .(goto)(544, 32, 544) */
		reached[3][32] = 1;
		;
		/* merge: sealed_calls = calls(544, 33, 544) */
		reached[3][33] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 34, 544) */
		reached[3][34] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 25: // STATE 33 - governed-local.pml:162 - [sealed_calls = calls] (0:544:2 - 5)
		IfNotBlocked
		reached[3][33] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 34, 544) */
		reached[3][34] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 26: // STATE 36 - governed-local.pml:221 - [((effect_state==Completed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][36] = 1;
		if (!((now.effect_state==11)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 27: // STATE 37 - governed-local.pml:222 - [(!(protocol_completed))] (65:0:1 - 1)
		IfNotBlocked
		reached[3][37] = 1;
		if (!( !(((int)now.protocol_completed))))
			continue;
		/* merge: completion_gap_crash = 1(0, 38, 65) */
		reached[3][38] = 1;
		(trpt+1)->bup.oval = ((int)completion_gap_crash);
		completion_gap_crash = 1;
#ifdef VAR_RANGES
		logval("completion_gap_crash", ((int)completion_gap_crash));
#endif
		;
		/* merge: .(goto)(0, 42, 65) */
		reached[3][42] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 28: // STATE 43 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][43] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 29: // STATE 44 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][44] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 30: // STATE 45 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][45] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 48 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][48] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 49 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][49] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 52 - governed-local.pml:158 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][52] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 62, 544) */
		reached[3][62] = 1;
		;
		/* merge: sealed_calls = calls(544, 63, 544) */
		reached[3][63] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 64, 544) */
		reached[3][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 34: // STATE 53 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:59:2 - 1)
		IfNotBlocked
		reached[3][53] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(59, 54, 59) */
		reached[3][54] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 35: // STATE 55 - governed-local.pml:160 - [((grant_epoch==2))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][55] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(544, 56, 544) */
		reached[3][56] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.epoch_refreshed);
		now.epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)now.epoch_refreshed));
#endif
		;
		/* merge: .(goto)(544, 60, 544) */
		reached[3][60] = 1;
		;
		/* merge: .(goto)(544, 62, 544) */
		reached[3][62] = 1;
		;
		/* merge: sealed_calls = calls(544, 63, 544) */
		reached[3][63] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 64, 544) */
		reached[3][64] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 36: // STATE 58 - governed-local.pml:160 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][58] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 60, 544) */
		reached[3][60] = 1;
		;
		/* merge: .(goto)(544, 62, 544) */
		reached[3][62] = 1;
		;
		/* merge: sealed_calls = calls(544, 63, 544) */
		reached[3][63] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 64, 544) */
		reached[3][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 37: // STATE 63 - governed-local.pml:162 - [sealed_calls = calls] (0:544:2 - 5)
		IfNotBlocked
		reached[3][63] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 64, 544) */
		reached[3][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 38: // STATE 66 - governed-local.pml:224 - [((effect_state==Unknown))] (90:0:1 - 1)
		IfNotBlocked
		reached[3][66] = 1;
		if (!((now.effect_state==10)))
			continue;
		/* merge: terminal = Blocked(0, 67, 90) */
		reached[3][67] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 39: // STATE 68 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][68] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 69 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][69] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 41: // STATE 70 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][70] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 42: // STATE 73 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][73] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 43: // STATE 74 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][74] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 44: // STATE 77 - governed-local.pml:158 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][77] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 87, 544) */
		reached[3][87] = 1;
		;
		/* merge: sealed_calls = calls(544, 88, 544) */
		reached[3][88] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 89, 544) */
		reached[3][89] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 45: // STATE 78 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:84:2 - 1)
		IfNotBlocked
		reached[3][78] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(84, 79, 84) */
		reached[3][79] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 46: // STATE 80 - governed-local.pml:160 - [((grant_epoch==2))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][80] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(544, 81, 544) */
		reached[3][81] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.epoch_refreshed);
		now.epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)now.epoch_refreshed));
#endif
		;
		/* merge: .(goto)(544, 85, 544) */
		reached[3][85] = 1;
		;
		/* merge: .(goto)(544, 87, 544) */
		reached[3][87] = 1;
		;
		/* merge: sealed_calls = calls(544, 88, 544) */
		reached[3][88] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 89, 544) */
		reached[3][89] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 47: // STATE 83 - governed-local.pml:160 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][83] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 85, 544) */
		reached[3][85] = 1;
		;
		/* merge: .(goto)(544, 87, 544) */
		reached[3][87] = 1;
		;
		/* merge: sealed_calls = calls(544, 88, 544) */
		reached[3][88] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 89, 544) */
		reached[3][89] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 48: // STATE 88 - governed-local.pml:162 - [sealed_calls = calls] (0:544:2 - 5)
		IfNotBlocked
		reached[3][88] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 89, 544) */
		reached[3][89] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 544) */
		reached[3][94] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 49: // STATE 92 - governed-local.pml:225 - [pc = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[3][92] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 50: // STATE 95 - governed-local.pml:227 - [(!(crash))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][95] = 1;
		if (!( !(((int)now.crash))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 51: // STATE 96 - governed-local.pml:229 - [((pc==0))] (103:0:1 - 1)
		IfNotBlocked
		reached[3][96] = 1;
		if (!((((int)now.pc)==0)))
			continue;
		/* merge: request_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 97, 103) */
		reached[3][97] = 1;
		(trpt+1)->bup.oval = ((int)now.request_check);
		now.request_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("request_check", ((int)now.request_check));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 52: // STATE 98 - governed-local.pml:232 - [(request_check)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][98] = 1;
		if (!(((int)now.request_check)))
			continue;
		/* merge: pc = 30(0, 99, 544) */
		reached[3][99] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 30;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 104, 544) */
		reached[3][104] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 53: // STATE 100 - governed-local.pml:233 - [(!(request_check))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][100] = 1;
		if (!( !(((int)now.request_check))))
			continue;
		/* merge: terminal = Denied(544, 101, 544) */
		reached[3][101] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 102, 544) */
		reached[3][102] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 104, 544) */
		reached[3][104] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 54: // STATE 105 - governed-local.pml:235 - [((pc==1))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][105] = 1;
		if (!((((int)now.pc)==1)))
			continue;
		/* merge: assert(request_check)(544, 106, 544) */
		reached[3][106] = 1;
		spin_assert(((int)now.request_check), "request_check", II, tt, t);
		/* merge: assert(input_inspected)(544, 107, 544) */
		reached[3][107] = 1;
		spin_assert(((int)now.input_inspected), "input_inspected", II, tt, t);
		/* merge: bound_original = 1(544, 108, 544) */
		reached[3][108] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.bound_original);
		now.bound_original = 1;
#ifdef VAR_RANGES
		logval("bound_original", ((int)now.bound_original));
#endif
		;
		/* merge: journal_input = Safe(544, 109, 544) */
		reached[3][109] = 1;
		(trpt+1)->bup.ovals[1] = now.journal_input;
		now.journal_input = 8;
#ifdef VAR_RANGES
		logval("journal_input", now.journal_input);
#endif
		;
		/* merge: pc = 2(544, 110, 544) */
		reached[3][110] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 2;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 55: // STATE 111 - governed-local.pml:245 - [((pc==2))] (118:0:1 - 1)
		IfNotBlocked
		reached[3][111] = 1;
		if (!((((int)now.pc)==2)))
			continue;
		/* merge: protocol_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 112, 118) */
		reached[3][112] = 1;
		(trpt+1)->bup.oval = ((int)now.protocol_check);
		now.protocol_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("protocol_check", ((int)now.protocol_check));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 56: // STATE 113 - governed-local.pml:248 - [(protocol_check)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][113] = 1;
		if (!(((int)now.protocol_check)))
			continue;
		/* merge: pc = 23(0, 114, 544) */
		reached[3][114] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 23;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 119, 544) */
		reached[3][119] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 57: // STATE 115 - governed-local.pml:249 - [(!(protocol_check))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][115] = 1;
		if (!( !(((int)now.protocol_check))))
			continue;
		/* merge: terminal = Denied(544, 116, 544) */
		reached[3][116] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 117, 544) */
		reached[3][117] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 119, 544) */
		reached[3][119] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 58: // STATE 120 - governed-local.pml:251 - [((pc==23))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][120] = 1;
		if (!((((int)now.pc)==23)))
			continue;
		/* merge: assert(protocol_check)(544, 121, 544) */
		reached[3][121] = 1;
		spin_assert(((int)now.protocol_check), "protocol_check", II, tt, t);
		/* merge: protocol_input = journal_input(544, 122, 544) */
		reached[3][122] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.protocol_input;
		now.protocol_input = now.journal_input;
#ifdef VAR_RANGES
		logval("protocol_input", now.protocol_input);
#endif
		;
		/* merge: pc = 3(544, 123, 544) */
		reached[3][123] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 59: // STATE 124 - governed-local.pml:253 - [((pc==3))] (132:0:1 - 1)
		IfNotBlocked
		reached[3][124] = 1;
		if (!((((int)now.pc)==3)))
			continue;
		/* merge: effect_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(132, 125, 132) */
		reached[3][125] = 1;
		(trpt+1)->bup.oval = ((int)now.effect_check);
		now.effect_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("effect_check", ((int)now.effect_check));
#endif
		;
		/* merge: assert((!(effect_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(132, 126, 132) */
		reached[3][126] = 1;
		spin_assert(( !(((int)now.effect_check))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(effect_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 60: // STATE 127 - governed-local.pml:260 - [(effect_check)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][127] = 1;
		if (!(((int)now.effect_check)))
			continue;
		/* merge: pc = 40(0, 128, 544) */
		reached[3][128] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 40;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 133, 544) */
		reached[3][133] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 61: // STATE 129 - governed-local.pml:266 - [(!(effect_check))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][129] = 1;
		if (!( !(((int)now.effect_check))))
			continue;
		/* merge: terminal = Denied(544, 130, 544) */
		reached[3][130] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 131, 544) */
		reached[3][131] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 133, 544) */
		reached[3][133] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 62: // STATE 134 - governed-local.pml:268 - [((pc==4))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][134] = 1;
		if (!((((int)now.pc)==4)))
			continue;
		/* merge: assert(outbound_inspected)(544, 135, 544) */
		reached[3][135] = 1;
		spin_assert(((int)now.outbound_inspected), "outbound_inspected", II, tt, t);
		/* merge: effect_state = Prepared(544, 136, 544) */
		reached[3][136] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 13;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: reservation = 1(544, 137, 544) */
		reached[3][137] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.reservation);
		now.reservation = 1;
#ifdef VAR_RANGES
		logval("reservation", ((int)now.reservation));
#endif
		;
		/* merge: pc = 5(544, 138, 544) */
		reached[3][138] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 5;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 63: // STATE 139 - governed-local.pml:271 - [((pc==5))] (146:0:1 - 1)
		IfNotBlocked
		reached[3][139] = 1;
		if (!((((int)now.pc)==5)))
			continue;
		/* merge: effect_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 140, 146) */
		reached[3][140] = 1;
		(trpt+1)->bup.oval = ((int)now.effect_check);
		now.effect_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("effect_check", ((int)now.effect_check));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 64: // STATE 141 - governed-local.pml:274 - [(effect_check)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][141] = 1;
		if (!(((int)now.effect_check)))
			continue;
		/* merge: pc = 6(0, 142, 544) */
		reached[3][142] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 6;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 147, 544) */
		reached[3][147] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 65: // STATE 143 - governed-local.pml:275 - [(!(effect_check))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][143] = 1;
		if (!( !(((int)now.effect_check))))
			continue;
		/* merge: terminal = Denied(544, 144, 544) */
		reached[3][144] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 145, 544) */
		reached[3][145] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 147, 544) */
		reached[3][147] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 66: // STATE 148 - governed-local.pml:277 - [((pc==6))] (154:0:0 - 1)
		IfNotBlocked
		reached[3][148] = 1;
		if (!((((int)now.pc)==6)))
			continue;
		/* merge: assert((effect_check&&reservation))(0, 149, 154) */
		reached[3][149] = 1;
		spin_assert((((int)now.effect_check)&&((int)now.reservation)), "(effect_check&&reservation)", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 67: // STATE 150 - governed-local.pml:279 - [(!((((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][150] = 1;
		if (!( !((((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch))))))
			continue;
		/* merge: check_action_race = 1(544, 151, 544) */
		reached[3][151] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)check_action_race);
		check_action_race = 1;
#ifdef VAR_RANGES
		logval("check_action_race", ((int)check_action_race));
#endif
		;
		/* merge: .(goto)(544, 155, 544) */
		reached[3][155] = 1;
		;
		/* merge: effect_state = Executing(544, 156, 544) */
		reached[3][156] = 1;
		(trpt+1)->bup.ovals[1] = now.effect_state;
		now.effect_state = 12;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: pc = 7(544, 157, 544) */
		reached[3][157] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 7;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 68: // STATE 153 - governed-local.pml:279 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][153] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 155, 544) */
		reached[3][155] = 1;
		;
		/* merge: effect_state = Executing(544, 156, 544) */
		reached[3][156] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 12;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: pc = 7(544, 157, 544) */
		reached[3][157] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 7;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 69: // STATE 156 - governed-local.pml:280 - [effect_state = Executing] (0:544:2 - 3)
		IfNotBlocked
		reached[3][156] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 12;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: pc = 7(544, 157, 544) */
		reached[3][157] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 7;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 70: // STATE 158 - governed-local.pml:281 - [((pc==7))] (160:0:1 - 1)
		IfNotBlocked
		reached[3][158] = 1;
		if (!((((int)now.pc)==7)))
			continue;
		/* merge: calls = (calls+1)(0, 159, 160) */
		reached[3][159] = 1;
		(trpt+1)->bup.oval = ((int)now.calls);
		now.calls = (((int)now.calls)+1);
#ifdef VAR_RANGES
		logval("calls", ((int)now.calls));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 71: // STATE 160 - governed-local.pml:282 - [requests!1] (544:0:1 - 1)
		IfNotBlocked
		reached[3][160] = 1;
		if (q_full(now.requests))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.requests);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.requests, 0, 1, 0, 1);
		/* merge: pc = 8(0, 161, 544) */
		reached[3][161] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 8;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 2; goto P999; /* 3 */
	case 72: // STATE 162 - governed-local.pml:283 - [((pc==8))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][162] = 1;
		if (!((((int)now.pc)==8)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 73: // STATE 163 - governed-local.pml:290 - [results?observed,observed_certainty] (544:0:3 - 1)
		reached[3][163] = 1;
		if (q_len(now.results) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.observed;
		(trpt+1)->bup.ovals[1] = ((int)now.observed_certainty);
		;
		now.observed = qrecv(now.results, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("observed", now.observed);
#endif
		;
		now.observed_certainty = qrecv(now.results, XX-1, 1, 1);
#ifdef VAR_RANGES
		logval("observed_certainty", ((int)now.observed_certainty));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.results);
			sprintf(simtmp, "%d", now.observed); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((int)now.observed_certainty)); strcat(simvals, simtmp);
		}
#endif
		;
		/* merge: pc = 9(0, 164, 544) */
		reached[3][164] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 9;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 4; goto P999; /* 3 */
	case 74: // STATE 165 - governed-local.pml:292 - [((pc==9))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][165] = 1;
		if (!((((int)now.pc)==9)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 75: // STATE 166 - governed-local.pml:294 - [((observed==TransportLost))] (192:0:3 - 1)
		IfNotBlocked
		reached[3][166] = 1;
		if (!((now.observed==5)))
			continue;
		/* merge: effect_state = Unknown(192, 167, 192) */
		reached[3][167] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.effect_state;
		now.effect_state = 10;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: unknown_seen = 1(192, 168, 192) */
		reached[3][168] = 1;
		(trpt+1)->bup.ovals[1] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: terminal = Blocked(192, 169, 192) */
		reached[3][169] = 1;
		(trpt+1)->bup.ovals[2] = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 76: // STATE 170 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][170] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 77: // STATE 171 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][171] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 78: // STATE 172 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][172] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 79: // STATE 175 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][175] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 80: // STATE 176 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][176] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 81: // STATE 179 - governed-local.pml:158 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][179] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 189, 544) */
		reached[3][189] = 1;
		;
		/* merge: sealed_calls = calls(544, 190, 544) */
		reached[3][190] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 191, 544) */
		reached[3][191] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 544) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 82: // STATE 180 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:186:2 - 1)
		IfNotBlocked
		reached[3][180] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(186, 181, 186) */
		reached[3][181] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 83: // STATE 182 - governed-local.pml:160 - [((grant_epoch==2))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][182] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(544, 183, 544) */
		reached[3][183] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.epoch_refreshed);
		now.epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)now.epoch_refreshed));
#endif
		;
		/* merge: .(goto)(544, 187, 544) */
		reached[3][187] = 1;
		;
		/* merge: .(goto)(544, 189, 544) */
		reached[3][189] = 1;
		;
		/* merge: sealed_calls = calls(544, 190, 544) */
		reached[3][190] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 191, 544) */
		reached[3][191] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 544) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 84: // STATE 185 - governed-local.pml:160 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][185] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 187, 544) */
		reached[3][187] = 1;
		;
		/* merge: .(goto)(544, 189, 544) */
		reached[3][189] = 1;
		;
		/* merge: sealed_calls = calls(544, 190, 544) */
		reached[3][190] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 191, 544) */
		reached[3][191] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 544) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 85: // STATE 190 - governed-local.pml:162 - [sealed_calls = calls] (0:544:2 - 5)
		IfNotBlocked
		reached[3][190] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 191, 544) */
		reached[3][191] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 544) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 86: // STATE 193 - governed-local.pml:297 - [((observed!=TransportLost))] (544:0:1 - 1)
		IfNotBlocked
		reached[3][193] = 1;
		if (!((now.observed!=5)))
			continue;
		/* merge: pc = 33(0, 194, 544) */
		reached[3][194] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 33;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 196, 544) */
		reached[3][196] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 87: // STATE 197 - governed-local.pml:299 - [((pc==33))] (205:0:1 - 1)
		IfNotBlocked
		reached[3][197] = 1;
		if (!((((int)now.pc)==33)))
			continue;
		/* merge: inspection_precheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 198, 205) */
		reached[3][198] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_precheck);
		now.inspection_precheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_precheck", ((int)now.inspection_precheck));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 88: // STATE 199 - governed-local.pml:302 - [(inspection_precheck)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][199] = 1;
		if (!(((int)now.inspection_precheck)))
			continue;
		/* merge: pc = 34(0, 200, 544) */
		reached[3][200] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 34;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 206, 544) */
		reached[3][206] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 89: // STATE 201 - governed-local.pml:303 - [(!(inspection_precheck))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][201] = 1;
		if (!( !(((int)now.inspection_precheck))))
			continue;
		/* merge: local_withheld = 1(544, 202, 544) */
		reached[3][202] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.local_withheld);
		now.local_withheld = 1;
#ifdef VAR_RANGES
		logval("local_withheld", ((int)now.local_withheld));
#endif
		;
		/* merge: local_output = Withheld(544, 203, 544) */
		reached[3][203] = 1;
		(trpt+1)->bup.ovals[1] = now.local_output;
		now.local_output = 6;
#ifdef VAR_RANGES
		logval("local_output", now.local_output);
#endif
		;
		/* merge: pc = 10(544, 204, 544) */
		reached[3][204] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 206, 544) */
		reached[3][206] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 90: // STATE 207 - governed-local.pml:306 - [((pc==34))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][207] = 1;
		if (!((((int)now.pc)==34)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 91: // STATE 208 - governed-local.pml:171 - [inspection_complete = 1] (0:217:4 - 1)
		IfNotBlocked
		reached[3][208] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 1;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: inspection_exact = 1(217, 209, 217) */
		reached[3][209] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_exact);
		now.inspection_exact = 1;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: inspection_clean = 1(217, 210, 217) */
		reached[3][210] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inspection_clean);
		now.inspection_clean = 1;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: inspection_original_positive = 0(217, 211, 217) */
		reached[3][211] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 0;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 92: // STATE 212 - governed-local.pml:174 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][212] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 218, 544) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 219, 544) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 220, 544) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(544, 222, 544) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 93: // STATE 213 - governed-local.pml:175 - [inspection_original_positive = 1] (0:544:3 - 1)
		IfNotBlocked
		reached[3][213] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 1;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		/* merge: .(goto)(544, 218, 544) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 219, 544) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 220, 544) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(544, 222, 544) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 94: // STATE 214 - governed-local.pml:176 - [inspection_complete = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][214] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 0;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: .(goto)(544, 218, 544) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 219, 544) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 220, 544) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(544, 222, 544) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 95: // STATE 215 - governed-local.pml:177 - [inspection_exact = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][215] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_exact);
		now.inspection_exact = 0;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: .(goto)(544, 218, 544) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 219, 544) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 220, 544) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(544, 222, 544) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 96: // STATE 216 - governed-local.pml:178 - [inspection_clean = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][216] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_clean);
		now.inspection_clean = 0;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: .(goto)(544, 218, 544) */
		reached[3][218] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 219, 544) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 220, 544) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(544, 222, 544) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 97: // STATE 219 - governed-local.pml:180 - [inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)] (0:544:2 - 6)
		IfNotBlocked
		reached[3][219] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 220, 544) */
		reached[3][220] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 35(544, 222, 544) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 35;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 98: // STATE 223 - governed-local.pml:307 - [((pc==35))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][223] = 1;
		if (!((((int)now.pc)==35)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 99: // STATE 224 - governed-local.pml:194 - [inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))] (0:229:1 - 1)
		IfNotBlocked
		reached[3][224] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_postcheck);
		now.inspection_postcheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_postcheck", ((int)now.inspection_postcheck));
#endif
		;
		/* merge: assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(229, 225, 229) */
		reached[3][225] = 1;
		spin_assert(( !(((int)now.inspection_postcheck))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 100: // STATE 227 - governed-local.pml:309 - [envelope_valid = 1] (0:237:3 - 1)
		IfNotBlocked
		reached[3][227] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.envelope_valid);
		now.envelope_valid = 1;
#ifdef VAR_RANGES
		logval("envelope_valid", ((int)now.envelope_valid));
#endif
		;
		/* merge: .(goto)(237, 230, 237) */
		reached[3][230] = 1;
		;
		/* merge: result_projected = (((inspection_accepted&&inspection_postcheck)&&(observed==Safe))&&envelope_valid)(237, 231, 237) */
		reached[3][231] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.result_projected);
		now.result_projected = (((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))&&(now.observed==8))&&((int)now.envelope_valid));
#ifdef VAR_RANGES
		logval("result_projected", ((int)now.result_projected));
#endif
		;
		/* merge: local_withheld = !(result_projected)(237, 232, 237) */
		reached[3][232] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.local_withheld);
		now.local_withheld =  !(((int)now.result_projected));
#ifdef VAR_RANGES
		logval("local_withheld", ((int)now.local_withheld));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 101: // STATE 228 - governed-local.pml:309 - [envelope_valid = 0] (0:237:3 - 1)
		IfNotBlocked
		reached[3][228] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.envelope_valid);
		now.envelope_valid = 0;
#ifdef VAR_RANGES
		logval("envelope_valid", ((int)now.envelope_valid));
#endif
		;
		/* merge: .(goto)(237, 230, 237) */
		reached[3][230] = 1;
		;
		/* merge: result_projected = (((inspection_accepted&&inspection_postcheck)&&(observed==Safe))&&envelope_valid)(237, 231, 237) */
		reached[3][231] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.result_projected);
		now.result_projected = (((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))&&(now.observed==8))&&((int)now.envelope_valid));
#ifdef VAR_RANGES
		logval("result_projected", ((int)now.result_projected));
#endif
		;
		/* merge: local_withheld = !(result_projected)(237, 232, 237) */
		reached[3][232] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.local_withheld);
		now.local_withheld =  !(((int)now.result_projected));
#ifdef VAR_RANGES
		logval("local_withheld", ((int)now.local_withheld));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 102: // STATE 231 - governed-local.pml:310 - [result_projected = (((inspection_accepted&&inspection_postcheck)&&(observed==Safe))&&envelope_valid)] (0:237:2 - 3)
		IfNotBlocked
		reached[3][231] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.result_projected);
		now.result_projected = (((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))&&(now.observed==8))&&((int)now.envelope_valid));
#ifdef VAR_RANGES
		logval("result_projected", ((int)now.result_projected));
#endif
		;
		/* merge: local_withheld = !(result_projected)(237, 232, 237) */
		reached[3][232] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.local_withheld);
		now.local_withheld =  !(((int)now.result_projected));
#ifdef VAR_RANGES
		logval("local_withheld", ((int)now.local_withheld));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 103: // STATE 233 - governed-local.pml:313 - [(result_projected)] (243:0:1 - 1)
		IfNotBlocked
		reached[3][233] = 1;
		if (!(((int)now.result_projected)))
			continue;
		/* merge: local_output = Safe(0, 234, 243) */
		reached[3][234] = 1;
		(trpt+1)->bup.oval = now.local_output;
		now.local_output = 8;
#ifdef VAR_RANGES
		logval("local_output", now.local_output);
#endif
		;
		/* merge: .(goto)(0, 238, 243) */
		reached[3][238] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 104: // STATE 235 - governed-local.pml:314 - [(!(result_projected))] (243:0:1 - 1)
		IfNotBlocked
		reached[3][235] = 1;
		if (!( !(((int)now.result_projected))))
			continue;
		/* merge: local_output = Withheld(0, 236, 243) */
		reached[3][236] = 1;
		(trpt+1)->bup.oval = now.local_output;
		now.local_output = 6;
#ifdef VAR_RANGES
		logval("local_output", now.local_output);
#endif
		;
		/* merge: .(goto)(0, 238, 243) */
		reached[3][238] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 105: // STATE 239 - governed-local.pml:317 - [(!(inspection_accepted))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][239] = 1;
		if (!( !(((int)now.inspection_accepted))))
			continue;
		/* merge: inspection_withheld = 1(544, 240, 544) */
		reached[3][240] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)inspection_withheld);
		inspection_withheld = 1;
#ifdef VAR_RANGES
		logval("inspection_withheld", ((int)inspection_withheld));
#endif
		;
		/* merge: .(goto)(544, 244, 544) */
		reached[3][244] = 1;
		;
		/* merge: pc = 10(544, 245, 544) */
		reached[3][245] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 106: // STATE 242 - governed-local.pml:318 - [(1)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][242] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 244, 544) */
		reached[3][244] = 1;
		;
		/* merge: pc = 10(544, 245, 544) */
		reached[3][245] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 107: // STATE 245 - governed-local.pml:323 - [pc = 10] (0:544:1 - 3)
		IfNotBlocked
		reached[3][245] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 108: // STATE 246 - governed-local.pml:324 - [((pc==10))] (260:0:8 - 1)
		IfNotBlocked
		reached[3][246] = 1;
		if (!((((int)now.pc)==10)))
			continue;
		/* merge: receipt = 1(260, 247, 260) */
		reached[3][247] = 1;
		(trpt+1)->bup.ovals = grab_ints(8);
		(trpt+1)->bup.ovals[0] = ((int)now.receipt);
		now.receipt = 1;
#ifdef VAR_RANGES
		logval("receipt", ((int)now.receipt));
#endif
		;
		/* merge: effect_state = Completed(260, 248, 260) */
		reached[3][248] = 1;
		(trpt+1)->bup.ovals[1] = now.effect_state;
		now.effect_state = 11;
#ifdef VAR_RANGES
		logval("effect_state", now.effect_state);
#endif
		;
		/* merge: journal_output = local_output(260, 249, 260) */
		reached[3][249] = 1;
		(trpt+1)->bup.ovals[2] = now.journal_output;
		now.journal_output = now.local_output;
#ifdef VAR_RANGES
		logval("journal_output", now.journal_output);
#endif
		;
		/* merge: receipt_payload = local_output(260, 250, 260) */
		reached[3][250] = 1;
		(trpt+1)->bup.ovals[3] = now.receipt_payload;
		now.receipt_payload = now.local_output;
#ifdef VAR_RANGES
		logval("receipt_payload", now.receipt_payload);
#endif
		;
		/* merge: retained_withheld = local_withheld(260, 251, 260) */
		reached[3][251] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.retained_withheld);
		now.retained_withheld = ((int)now.local_withheld);
#ifdef VAR_RANGES
		logval("retained_withheld", ((int)now.retained_withheld));
#endif
		;
		/* merge: sealed_withheld = local_withheld(260, 252, 260) */
		reached[3][252] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.sealed_withheld);
		now.sealed_withheld = ((int)now.local_withheld);
#ifdef VAR_RANGES
		logval("sealed_withheld", ((int)now.sealed_withheld));
#endif
		;
		/* merge: retained_certainty = observed_certainty(260, 253, 260) */
		reached[3][253] = 1;
		(trpt+1)->bup.ovals[6] = ((int)now.retained_certainty);
		now.retained_certainty = ((int)now.observed_certainty);
#ifdef VAR_RANGES
		logval("retained_certainty", ((int)now.retained_certainty));
#endif
		;
		/* merge: sealed_certainty = observed_certainty(260, 254, 260) */
		reached[3][254] = 1;
		(trpt+1)->bup.ovals[7] = ((int)now.sealed_certainty);
		now.sealed_certainty = ((int)now.observed_certainty);
#ifdef VAR_RANGES
		logval("sealed_certainty", ((int)now.sealed_certainty));
#endif
		;
		/* merge: assert((receipt&&(effect_state==Completed)))(260, 255, 260) */
		reached[3][255] = 1;
		spin_assert((((int)now.receipt)&&(now.effect_state==11)), "(receipt&&(effect_state==11))", II, tt, t);
		_m = 3; goto P999; /* 9 */
	case 109: // STATE 256 - governed-local.pml:342 - [((!((((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))&&local_withheld))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][256] = 1;
		if (!(( !((((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch))))&&((int)now.local_withheld))))
			continue;
		/* merge: completed_while_revoked = 1(544, 257, 544) */
		reached[3][257] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)completed_while_revoked);
		completed_while_revoked = 1;
#ifdef VAR_RANGES
		logval("completed_while_revoked", ((int)completed_while_revoked));
#endif
		;
		/* merge: .(goto)(544, 261, 544) */
		reached[3][261] = 1;
		;
		/* merge: pc = 11(544, 262, 544) */
		reached[3][262] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 11;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 110: // STATE 259 - governed-local.pml:343 - [(1)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][259] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 261, 544) */
		reached[3][261] = 1;
		;
		/* merge: pc = 11(544, 262, 544) */
		reached[3][262] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 11;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 111: // STATE 262 - governed-local.pml:345 - [pc = 11] (0:544:1 - 3)
		IfNotBlocked
		reached[3][262] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 11;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 112: // STATE 263 - governed-local.pml:346 - [((pc==11))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][263] = 1;
		if (!((((int)now.pc)==11)))
			continue;
		/* merge: protocol_output = journal_output(544, 264, 544) */
		reached[3][264] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.protocol_output;
		now.protocol_output = now.journal_output;
#ifdef VAR_RANGES
		logval("protocol_output", now.protocol_output);
#endif
		;
		/* merge: protocol_completed = 1(544, 265, 544) */
		reached[3][265] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.protocol_completed);
		now.protocol_completed = 1;
#ifdef VAR_RANGES
		logval("protocol_completed", ((int)now.protocol_completed));
#endif
		;
		/* merge: pc = 12(544, 266, 544) */
		reached[3][266] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 12;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 113: // STATE 267 - governed-local.pml:354 - [((pc==12))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][267] = 1;
		if (!((((int)now.pc)==12)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 114: // STATE 268 - governed-local.pml:357 - [forwarded_parent = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][268] = 1;
		(trpt+1)->bup.oval = ((int)now.forwarded_parent);
		now.forwarded_parent = 1;
#ifdef VAR_RANGES
		logval("forwarded_parent", ((int)now.forwarded_parent));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 115: // STATE 269 - governed-local.pml:357 - [forwarded_parent = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][269] = 1;
		(trpt+1)->bup.oval = ((int)now.forwarded_parent);
		now.forwarded_parent = 2;
#ifdef VAR_RANGES
		logval("forwarded_parent", ((int)now.forwarded_parent));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 116: // STATE 272 - governed-local.pml:358 - [forwarded_actor = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][272] = 1;
		(trpt+1)->bup.oval = ((int)now.forwarded_actor);
		now.forwarded_actor = 1;
#ifdef VAR_RANGES
		logval("forwarded_actor", ((int)now.forwarded_actor));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 117: // STATE 273 - governed-local.pml:358 - [forwarded_actor = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][273] = 1;
		(trpt+1)->bup.oval = ((int)now.forwarded_actor);
		now.forwarded_actor = 2;
#ifdef VAR_RANGES
		logval("forwarded_actor", ((int)now.forwarded_actor));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 118: // STATE 276 - governed-local.pml:360 - [((local_withheld&&((forwarded_parent!=1)||(forwarded_actor!=1))))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][276] = 1;
		if (!((((int)now.local_withheld)&&((((int)now.forwarded_parent)!=1)||(((int)now.forwarded_actor)!=1)))))
			continue;
		/* merge: forwarded_certainty = 0(544, 277, 544) */
		reached[3][277] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.forwarded_certainty);
		now.forwarded_certainty = 0;
#ifdef VAR_RANGES
		logval("forwarded_certainty", ((int)now.forwarded_certainty));
#endif
		;
		/* merge: .(goto)(544, 281, 544) */
		reached[3][281] = 1;
		;
		/* merge: assert(((!(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0)))(544, 282, 544) */
		reached[3][282] = 1;
		spin_assert((( !(((int)now.local_withheld))||((((int)now.forwarded_parent)==1)&&(((int)now.forwarded_actor)==1)))||(((int)now.forwarded_certainty)==0)), "(( !(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0))", II, tt, t);
		/* merge: pc = 13(544, 283, 544) */
		reached[3][283] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 119: // STATE 279 - governed-local.pml:366 - [forwarded_certainty = retained_certainty] (0:544:2 - 1)
		IfNotBlocked
		reached[3][279] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.forwarded_certainty);
		now.forwarded_certainty = ((int)now.retained_certainty);
#ifdef VAR_RANGES
		logval("forwarded_certainty", ((int)now.forwarded_certainty));
#endif
		;
		/* merge: .(goto)(544, 281, 544) */
		reached[3][281] = 1;
		;
		/* merge: assert(((!(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0)))(544, 282, 544) */
		reached[3][282] = 1;
		spin_assert((( !(((int)now.local_withheld))||((((int)now.forwarded_parent)==1)&&(((int)now.forwarded_actor)==1)))||(((int)now.forwarded_certainty)==0)), "(( !(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0))", II, tt, t);
		/* merge: pc = 13(544, 283, 544) */
		reached[3][283] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 120: // STATE 282 - governed-local.pml:368 - [assert(((!(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0)))] (0:544:1 - 3)
		IfNotBlocked
		reached[3][282] = 1;
		spin_assert((( !(((int)now.local_withheld))||((((int)now.forwarded_parent)==1)&&(((int)now.forwarded_actor)==1)))||(((int)now.forwarded_certainty)==0)), "(( !(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0))", II, tt, t);
		/* merge: pc = 13(544, 283, 544) */
		reached[3][283] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 121: // STATE 284 - governed-local.pml:370 - [((pc==13))] (326:0:1 - 1)
		IfNotBlocked
		reached[3][284] = 1;
		if (!((((int)now.pc)==13)))
			continue;
		/* merge: delivery_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(326, 285, 326) */
		reached[3][285] = 1;
		(trpt+1)->bup.oval = ((int)now.delivery_check);
		now.delivery_check = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("delivery_check", ((int)now.delivery_check));
#endif
		;
		/* merge: assert((!(delivery_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(326, 286, 326) */
		reached[3][286] = 1;
		spin_assert(( !(((int)now.delivery_check))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(delivery_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 122: // STATE 287 - governed-local.pml:377 - [(delivery_check)] (0:0:0 - 1)
		IfNotBlocked
		reached[3][287] = 1;
		if (!(((int)now.delivery_check)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 123: // STATE 288 - governed-local.pml:379 - [(retained_withheld)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][288] = 1;
		if (!(((int)now.retained_withheld)))
			continue;
		/* merge: pc = 14(0, 289, 544) */
		reached[3][289] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 14;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 294, 544) */
		reached[3][294] = 1;
		;
		/* merge: .(goto)(0, 327, 544) */
		reached[3][327] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 124: // STATE 290 - governed-local.pml:380 - [(!(retained_withheld))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][290] = 1;
		if (!( !(((int)now.retained_withheld))))
			continue;
		/* merge: inspection_precheck = delivery_check(544, 291, 544) */
		reached[3][291] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_precheck);
		now.inspection_precheck = ((int)now.delivery_check);
#ifdef VAR_RANGES
		logval("inspection_precheck", ((int)now.inspection_precheck));
#endif
		;
		/* merge: pc = 36(544, 292, 544) */
		reached[3][292] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 36;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 294, 544) */
		reached[3][294] = 1;
		;
		/* merge: .(goto)(0, 327, 544) */
		reached[3][327] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 125: // STATE 295 - governed-local.pml:382 - [(!(delivery_check))] (325:0:1 - 1)
		IfNotBlocked
		reached[3][295] = 1;
		if (!( !(((int)now.delivery_check))))
			continue;
		/* merge: terminal = Denied(0, 296, 325) */
		reached[3][296] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 126: // STATE 297 - governed-local.pml:203 - [(replayed)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][297] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 298, 544) */
		reached[3][298] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 324, 544) */
		reached[3][324] = 1;
		;
		/* merge: .(goto)(0, 327, 544) */
		reached[3][327] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 127: // STATE 299 - governed-local.pml:204 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][299] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 128: // STATE 300 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][300] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 129: // STATE 301 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][301] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 130: // STATE 302 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][302] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 131: // STATE 305 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][305] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 132: // STATE 306 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][306] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 133: // STATE 309 - governed-local.pml:158 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][309] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 319, 544) */
		reached[3][319] = 1;
		;
		/* merge: sealed_calls = calls(544, 320, 544) */
		reached[3][320] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 321, 544) */
		reached[3][321] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 324, 544) */
		reached[3][324] = 1;
		;
		/* merge: .(goto)(0, 327, 544) */
		reached[3][327] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 134: // STATE 310 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:316:2 - 1)
		IfNotBlocked
		reached[3][310] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(316, 311, 316) */
		reached[3][311] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 135: // STATE 312 - governed-local.pml:160 - [((grant_epoch==2))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][312] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(544, 313, 544) */
		reached[3][313] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.epoch_refreshed);
		now.epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)now.epoch_refreshed));
#endif
		;
		/* merge: .(goto)(544, 317, 544) */
		reached[3][317] = 1;
		;
		/* merge: .(goto)(544, 319, 544) */
		reached[3][319] = 1;
		;
		/* merge: sealed_calls = calls(544, 320, 544) */
		reached[3][320] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 321, 544) */
		reached[3][321] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 324, 544) */
		reached[3][324] = 1;
		;
		/* merge: .(goto)(0, 327, 544) */
		reached[3][327] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 136: // STATE 315 - governed-local.pml:160 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][315] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 317, 544) */
		reached[3][317] = 1;
		;
		/* merge: .(goto)(544, 319, 544) */
		reached[3][319] = 1;
		;
		/* merge: sealed_calls = calls(544, 320, 544) */
		reached[3][320] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 321, 544) */
		reached[3][321] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 324, 544) */
		reached[3][324] = 1;
		;
		/* merge: .(goto)(0, 327, 544) */
		reached[3][327] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 137: // STATE 320 - governed-local.pml:162 - [sealed_calls = calls] (0:544:2 - 5)
		IfNotBlocked
		reached[3][320] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 321, 544) */
		reached[3][321] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 324, 544) */
		reached[3][324] = 1;
		;
		/* merge: .(goto)(0, 327, 544) */
		reached[3][327] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 138: // STATE 328 - governed-local.pml:384 - [((pc==36))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][328] = 1;
		if (!((((int)now.pc)==36)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 139: // STATE 329 - governed-local.pml:171 - [inspection_complete = 1] (0:338:4 - 1)
		IfNotBlocked
		reached[3][329] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 1;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: inspection_exact = 1(338, 330, 338) */
		reached[3][330] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_exact);
		now.inspection_exact = 1;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: inspection_clean = 1(338, 331, 338) */
		reached[3][331] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inspection_clean);
		now.inspection_clean = 1;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: inspection_original_positive = 0(338, 332, 338) */
		reached[3][332] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 0;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 140: // STATE 333 - governed-local.pml:174 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][333] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 339, 544) */
		reached[3][339] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 340, 544) */
		reached[3][340] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 341, 544) */
		reached[3][341] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(544, 343, 544) */
		reached[3][343] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 141: // STATE 334 - governed-local.pml:175 - [inspection_original_positive = 1] (0:544:3 - 1)
		IfNotBlocked
		reached[3][334] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 1;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		/* merge: .(goto)(544, 339, 544) */
		reached[3][339] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 340, 544) */
		reached[3][340] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 341, 544) */
		reached[3][341] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(544, 343, 544) */
		reached[3][343] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 142: // STATE 335 - governed-local.pml:176 - [inspection_complete = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][335] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 0;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: .(goto)(544, 339, 544) */
		reached[3][339] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 340, 544) */
		reached[3][340] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 341, 544) */
		reached[3][341] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(544, 343, 544) */
		reached[3][343] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 143: // STATE 336 - governed-local.pml:177 - [inspection_exact = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][336] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_exact);
		now.inspection_exact = 0;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: .(goto)(544, 339, 544) */
		reached[3][339] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 340, 544) */
		reached[3][340] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 341, 544) */
		reached[3][341] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(544, 343, 544) */
		reached[3][343] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 144: // STATE 337 - governed-local.pml:178 - [inspection_clean = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][337] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_clean);
		now.inspection_clean = 0;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: .(goto)(544, 339, 544) */
		reached[3][339] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 340, 544) */
		reached[3][340] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 341, 544) */
		reached[3][341] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(544, 343, 544) */
		reached[3][343] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 145: // STATE 340 - governed-local.pml:180 - [inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)] (0:544:2 - 6)
		IfNotBlocked
		reached[3][340] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 341, 544) */
		reached[3][341] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 37(544, 343, 544) */
		reached[3][343] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 37;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 146: // STATE 344 - governed-local.pml:385 - [((pc==37))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][344] = 1;
		if (!((((int)now.pc)==37)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 147: // STATE 345 - governed-local.pml:194 - [inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))] (0:382:2 - 1)
		IfNotBlocked
		reached[3][345] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_postcheck);
		now.inspection_postcheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_postcheck", ((int)now.inspection_postcheck));
#endif
		;
		/* merge: assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(382, 346, 382) */
		reached[3][346] = 1;
		spin_assert(( !(((int)now.inspection_postcheck))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		/* merge: delivery_check = (inspection_accepted&&inspection_postcheck)(382, 348, 382) */
		reached[3][348] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.delivery_check);
		now.delivery_check = (((int)now.inspection_accepted)&&((int)now.inspection_postcheck));
#ifdef VAR_RANGES
		logval("delivery_check", ((int)now.delivery_check));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 148: // STATE 349 - governed-local.pml:389 - [(delivery_check)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][349] = 1;
		if (!(((int)now.delivery_check)))
			continue;
		/* merge: pc = 14(0, 350, 544) */
		reached[3][350] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 14;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 383, 544) */
		reached[3][383] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 149: // STATE 351 - governed-local.pml:390 - [(!(delivery_check))] (381:0:1 - 1)
		IfNotBlocked
		reached[3][351] = 1;
		if (!( !(((int)now.delivery_check))))
			continue;
		/* merge: terminal = Denied(0, 352, 381) */
		reached[3][352] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 150: // STATE 353 - governed-local.pml:203 - [(replayed)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][353] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 354, 544) */
		reached[3][354] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 380, 544) */
		reached[3][380] = 1;
		;
		/* merge: .(goto)(0, 383, 544) */
		reached[3][383] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 151: // STATE 355 - governed-local.pml:204 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][355] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 152: // STATE 356 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][356] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 153: // STATE 357 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][357] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 154: // STATE 358 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][358] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 155: // STATE 361 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][361] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 156: // STATE 362 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][362] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 157: // STATE 365 - governed-local.pml:158 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][365] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 375, 544) */
		reached[3][375] = 1;
		;
		/* merge: sealed_calls = calls(544, 376, 544) */
		reached[3][376] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 377, 544) */
		reached[3][377] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 380, 544) */
		reached[3][380] = 1;
		;
		/* merge: .(goto)(0, 383, 544) */
		reached[3][383] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 158: // STATE 366 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:372:2 - 1)
		IfNotBlocked
		reached[3][366] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(372, 367, 372) */
		reached[3][367] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 159: // STATE 368 - governed-local.pml:160 - [((grant_epoch==2))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][368] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(544, 369, 544) */
		reached[3][369] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.epoch_refreshed);
		now.epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)now.epoch_refreshed));
#endif
		;
		/* merge: .(goto)(544, 373, 544) */
		reached[3][373] = 1;
		;
		/* merge: .(goto)(544, 375, 544) */
		reached[3][375] = 1;
		;
		/* merge: sealed_calls = calls(544, 376, 544) */
		reached[3][376] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 377, 544) */
		reached[3][377] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 380, 544) */
		reached[3][380] = 1;
		;
		/* merge: .(goto)(0, 383, 544) */
		reached[3][383] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 160: // STATE 371 - governed-local.pml:160 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][371] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 373, 544) */
		reached[3][373] = 1;
		;
		/* merge: .(goto)(544, 375, 544) */
		reached[3][375] = 1;
		;
		/* merge: sealed_calls = calls(544, 376, 544) */
		reached[3][376] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 377, 544) */
		reached[3][377] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 380, 544) */
		reached[3][380] = 1;
		;
		/* merge: .(goto)(0, 383, 544) */
		reached[3][383] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 161: // STATE 376 - governed-local.pml:162 - [sealed_calls = calls] (0:544:2 - 5)
		IfNotBlocked
		reached[3][376] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 377, 544) */
		reached[3][377] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 380, 544) */
		reached[3][380] = 1;
		;
		/* merge: .(goto)(0, 383, 544) */
		reached[3][383] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 162: // STATE 384 - governed-local.pml:392 - [((pc==14))] (416:0:2 - 1)
		IfNotBlocked
		reached[3][384] = 1;
		if (!((((int)now.pc)==14)))
			continue;
		/* merge: assert((delivery_check&&(attempt_tenant==1)))(416, 385, 416) */
		reached[3][385] = 1;
		spin_assert((((int)now.delivery_check)&&(((int)now.attempt_tenant)==1)), "(delivery_check&&(attempt_tenant==1))", II, tt, t);
		/* merge: delivered_once = 1(416, 386, 416) */
		reached[3][386] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)delivered_once);
		delivered_once = 1;
#ifdef VAR_RANGES
		logval("delivered_once", ((int)delivered_once));
#endif
		;
		/* merge: terminal = Delivered(416, 387, 416) */
		reached[3][387] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 3;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 163: // STATE 388 - governed-local.pml:203 - [(replayed)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][388] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 389, 544) */
		reached[3][389] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 415, 544) */
		reached[3][415] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 164: // STATE 390 - governed-local.pml:204 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][390] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 165: // STATE 391 - governed-local.pml:152 - [terminal = Running] (0:0:1 - 1)
		IfNotBlocked
		reached[3][391] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 166: // STATE 392 - governed-local.pml:153 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][392] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 167: // STATE 393 - governed-local.pml:153 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][393] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 168: // STATE 396 - governed-local.pml:154 - [attempt_original = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][396] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 1;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 169: // STATE 397 - governed-local.pml:154 - [attempt_original = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][397] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_original);
		now.attempt_original = 2;
#ifdef VAR_RANGES
		logval("attempt_original", ((int)now.attempt_original));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 170: // STATE 400 - governed-local.pml:158 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][400] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 410, 544) */
		reached[3][410] = 1;
		;
		/* merge: sealed_calls = calls(544, 411, 544) */
		reached[3][411] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 412, 544) */
		reached[3][412] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 415, 544) */
		reached[3][415] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 171: // STATE 401 - governed-local.pml:159 - [lease_epoch = credential_epoch] (0:407:2 - 1)
		IfNotBlocked
		reached[3][401] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.lease_epoch);
		now.lease_epoch = ((int)now.credential_epoch);
#ifdef VAR_RANGES
		logval("lease_epoch", ((int)now.lease_epoch));
#endif
		;
		/* merge: session_grant_epoch = grant_epoch(407, 402, 407) */
		reached[3][402] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.session_grant_epoch);
		now.session_grant_epoch = ((int)now.grant_epoch);
#ifdef VAR_RANGES
		logval("session_grant_epoch", ((int)now.session_grant_epoch));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 172: // STATE 403 - governed-local.pml:160 - [((grant_epoch==2))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][403] = 1;
		if (!((((int)now.grant_epoch)==2)))
			continue;
		/* merge: epoch_refreshed = 1(544, 404, 544) */
		reached[3][404] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.epoch_refreshed);
		now.epoch_refreshed = 1;
#ifdef VAR_RANGES
		logval("epoch_refreshed", ((int)now.epoch_refreshed));
#endif
		;
		/* merge: .(goto)(544, 408, 544) */
		reached[3][408] = 1;
		;
		/* merge: .(goto)(544, 410, 544) */
		reached[3][410] = 1;
		;
		/* merge: sealed_calls = calls(544, 411, 544) */
		reached[3][411] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 412, 544) */
		reached[3][412] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 415, 544) */
		reached[3][415] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 173: // STATE 406 - governed-local.pml:160 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][406] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 408, 544) */
		reached[3][408] = 1;
		;
		/* merge: .(goto)(544, 410, 544) */
		reached[3][410] = 1;
		;
		/* merge: sealed_calls = calls(544, 411, 544) */
		reached[3][411] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 412, 544) */
		reached[3][412] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 415, 544) */
		reached[3][415] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 174: // STATE 411 - governed-local.pml:162 - [sealed_calls = calls] (0:544:2 - 5)
		IfNotBlocked
		reached[3][411] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_calls);
		now.sealed_calls = ((int)now.calls);
#ifdef VAR_RANGES
		logval("sealed_calls", ((int)now.sealed_calls));
#endif
		;
		/* merge: pc = 20(544, 412, 544) */
		reached[3][412] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 415, 544) */
		reached[3][415] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 175: // STATE 417 - governed-local.pml:395 - [((pc==30))] (424:0:1 - 1)
		IfNotBlocked
		reached[3][417] = 1;
		if (!((((int)now.pc)==30)))
			continue;
		/* merge: inspection_precheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 418, 424) */
		reached[3][418] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_precheck);
		now.inspection_precheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_precheck", ((int)now.inspection_precheck));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 176: // STATE 419 - governed-local.pml:398 - [(inspection_precheck)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][419] = 1;
		if (!(((int)now.inspection_precheck)))
			continue;
		/* merge: pc = 31(0, 420, 544) */
		reached[3][420] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 31;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 425, 544) */
		reached[3][425] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 177: // STATE 421 - governed-local.pml:399 - [(!(inspection_precheck))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][421] = 1;
		if (!( !(((int)now.inspection_precheck))))
			continue;
		/* merge: terminal = Denied(544, 422, 544) */
		reached[3][422] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 423, 544) */
		reached[3][423] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 425, 544) */
		reached[3][425] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 178: // STATE 426 - governed-local.pml:401 - [((pc==31))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][426] = 1;
		if (!((((int)now.pc)==31)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 179: // STATE 427 - governed-local.pml:171 - [inspection_complete = 1] (0:436:4 - 1)
		IfNotBlocked
		reached[3][427] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 1;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: inspection_exact = 1(436, 428, 436) */
		reached[3][428] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_exact);
		now.inspection_exact = 1;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: inspection_clean = 1(436, 429, 436) */
		reached[3][429] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inspection_clean);
		now.inspection_clean = 1;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: inspection_original_positive = 0(436, 430, 436) */
		reached[3][430] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 0;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 180: // STATE 431 - governed-local.pml:174 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][431] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 437, 544) */
		reached[3][437] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 438, 544) */
		reached[3][438] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 439, 544) */
		reached[3][439] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(544, 441, 544) */
		reached[3][441] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 181: // STATE 432 - governed-local.pml:175 - [inspection_original_positive = 1] (0:544:3 - 1)
		IfNotBlocked
		reached[3][432] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 1;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		/* merge: .(goto)(544, 437, 544) */
		reached[3][437] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 438, 544) */
		reached[3][438] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 439, 544) */
		reached[3][439] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(544, 441, 544) */
		reached[3][441] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 182: // STATE 433 - governed-local.pml:176 - [inspection_complete = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][433] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 0;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: .(goto)(544, 437, 544) */
		reached[3][437] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 438, 544) */
		reached[3][438] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 439, 544) */
		reached[3][439] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(544, 441, 544) */
		reached[3][441] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 183: // STATE 434 - governed-local.pml:177 - [inspection_exact = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][434] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_exact);
		now.inspection_exact = 0;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: .(goto)(544, 437, 544) */
		reached[3][437] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 438, 544) */
		reached[3][438] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 439, 544) */
		reached[3][439] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(544, 441, 544) */
		reached[3][441] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 184: // STATE 435 - governed-local.pml:178 - [inspection_clean = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][435] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_clean);
		now.inspection_clean = 0;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: .(goto)(544, 437, 544) */
		reached[3][437] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 438, 544) */
		reached[3][438] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 439, 544) */
		reached[3][439] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(544, 441, 544) */
		reached[3][441] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 185: // STATE 438 - governed-local.pml:180 - [inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)] (0:544:2 - 6)
		IfNotBlocked
		reached[3][438] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 439, 544) */
		reached[3][439] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 32(544, 441, 544) */
		reached[3][441] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 32;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 186: // STATE 442 - governed-local.pml:402 - [((pc==32))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][442] = 1;
		if (!((((int)now.pc)==32)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 187: // STATE 443 - governed-local.pml:194 - [inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))] (0:459:1 - 1)
		IfNotBlocked
		reached[3][443] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_postcheck);
		now.inspection_postcheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_postcheck", ((int)now.inspection_postcheck));
#endif
		;
		/* merge: assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(459, 444, 459) */
		reached[3][444] = 1;
		spin_assert(( !(((int)now.inspection_postcheck))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 188: // STATE 446 - governed-local.pml:405 - [((inspection_accepted&&inspection_postcheck))] (452:0:1 - 1)
		IfNotBlocked
		reached[3][446] = 1;
		if (!((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))))
			continue;
		/* merge: input_inspected = 1(0, 447, 452) */
		reached[3][447] = 1;
		(trpt+1)->bup.oval = ((int)now.input_inspected);
		now.input_inspected = 1;
#ifdef VAR_RANGES
		logval("input_inspected", ((int)now.input_inspected));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 189: // STATE 448 - governed-local.pml:408 - [(inspection_original_positive)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][448] = 1;
		if (!(((int)now.inspection_original_positive)))
			continue;
		/* merge: positive_original_projected = 1(544, 449, 544) */
		reached[3][449] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)positive_original_projected);
		positive_original_projected = 1;
#ifdef VAR_RANGES
		logval("positive_original_projected", ((int)positive_original_projected));
#endif
		;
		/* merge: .(goto)(544, 453, 544) */
		reached[3][453] = 1;
		;
		/* merge: pc = 1(544, 454, 544) */
		reached[3][454] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 460, 544) */
		reached[3][460] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 190: // STATE 451 - governed-local.pml:409 - [(1)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][451] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 453, 544) */
		reached[3][453] = 1;
		;
		/* merge: pc = 1(544, 454, 544) */
		reached[3][454] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 460, 544) */
		reached[3][460] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 191: // STATE 454 - governed-local.pml:411 - [pc = 1] (0:544:1 - 3)
		IfNotBlocked
		reached[3][454] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 460, 544) */
		reached[3][460] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 192: // STATE 455 - governed-local.pml:412 - [((!(inspection_accepted)||!(inspection_postcheck)))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][455] = 1;
		if (!(( !(((int)now.inspection_accepted))|| !(((int)now.inspection_postcheck)))))
			continue;
		/* merge: inspection_denied = 1(544, 456, 544) */
		reached[3][456] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)inspection_denied);
		inspection_denied = 1;
#ifdef VAR_RANGES
		logval("inspection_denied", ((int)inspection_denied));
#endif
		;
		/* merge: terminal = Denied(544, 457, 544) */
		reached[3][457] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 458, 544) */
		reached[3][458] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 460, 544) */
		reached[3][460] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 193: // STATE 461 - governed-local.pml:415 - [((pc==40))] (468:0:1 - 1)
		IfNotBlocked
		reached[3][461] = 1;
		if (!((((int)now.pc)==40)))
			continue;
		/* merge: inspection_precheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))(0, 462, 468) */
		reached[3][462] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_precheck);
		now.inspection_precheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_precheck", ((int)now.inspection_precheck));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 194: // STATE 463 - governed-local.pml:418 - [(inspection_precheck)] (544:0:1 - 1)
		IfNotBlocked
		reached[3][463] = 1;
		if (!(((int)now.inspection_precheck)))
			continue;
		/* merge: pc = 41(0, 464, 544) */
		reached[3][464] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 41;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 469, 544) */
		reached[3][469] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 195: // STATE 465 - governed-local.pml:419 - [(!(inspection_precheck))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][465] = 1;
		if (!( !(((int)now.inspection_precheck))))
			continue;
		/* merge: terminal = Denied(544, 466, 544) */
		reached[3][466] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 467, 544) */
		reached[3][467] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 469, 544) */
		reached[3][469] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 196: // STATE 470 - governed-local.pml:421 - [((pc==41))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][470] = 1;
		if (!((((int)now.pc)==41)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 197: // STATE 471 - governed-local.pml:171 - [inspection_complete = 1] (0:480:4 - 1)
		IfNotBlocked
		reached[3][471] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 1;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: inspection_exact = 1(480, 472, 480) */
		reached[3][472] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_exact);
		now.inspection_exact = 1;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: inspection_clean = 1(480, 473, 480) */
		reached[3][473] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inspection_clean);
		now.inspection_clean = 1;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: inspection_original_positive = 0(480, 474, 480) */
		reached[3][474] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 0;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 198: // STATE 475 - governed-local.pml:174 - [(1)] (544:0:2 - 1)
		IfNotBlocked
		reached[3][475] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(544, 481, 544) */
		reached[3][481] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 482, 544) */
		reached[3][482] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 483, 544) */
		reached[3][483] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(544, 485, 544) */
		reached[3][485] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 199: // STATE 476 - governed-local.pml:175 - [inspection_original_positive = 1] (0:544:3 - 1)
		IfNotBlocked
		reached[3][476] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_original_positive);
		now.inspection_original_positive = 1;
#ifdef VAR_RANGES
		logval("inspection_original_positive", ((int)now.inspection_original_positive));
#endif
		;
		/* merge: .(goto)(544, 481, 544) */
		reached[3][481] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 482, 544) */
		reached[3][482] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 483, 544) */
		reached[3][483] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(544, 485, 544) */
		reached[3][485] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 200: // STATE 477 - governed-local.pml:176 - [inspection_complete = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][477] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_complete);
		now.inspection_complete = 0;
#ifdef VAR_RANGES
		logval("inspection_complete", ((int)now.inspection_complete));
#endif
		;
		/* merge: .(goto)(544, 481, 544) */
		reached[3][481] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 482, 544) */
		reached[3][482] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 483, 544) */
		reached[3][483] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(544, 485, 544) */
		reached[3][485] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 201: // STATE 478 - governed-local.pml:177 - [inspection_exact = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][478] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_exact);
		now.inspection_exact = 0;
#ifdef VAR_RANGES
		logval("inspection_exact", ((int)now.inspection_exact));
#endif
		;
		/* merge: .(goto)(544, 481, 544) */
		reached[3][481] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 482, 544) */
		reached[3][482] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 483, 544) */
		reached[3][483] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(544, 485, 544) */
		reached[3][485] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 202: // STATE 479 - governed-local.pml:178 - [inspection_clean = 0] (0:544:3 - 1)
		IfNotBlocked
		reached[3][479] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_clean);
		now.inspection_clean = 0;
#ifdef VAR_RANGES
		logval("inspection_clean", ((int)now.inspection_clean));
#endif
		;
		/* merge: .(goto)(544, 481, 544) */
		reached[3][481] = 1;
		;
		/* merge: inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)(544, 482, 544) */
		reached[3][482] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 483, 544) */
		reached[3][483] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(544, 485, 544) */
		reached[3][485] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 203: // STATE 482 - governed-local.pml:180 - [inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)] (0:544:2 - 6)
		IfNotBlocked
		reached[3][482] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inspection_accepted);
		now.inspection_accepted = ((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean));
#ifdef VAR_RANGES
		logval("inspection_accepted", ((int)now.inspection_accepted));
#endif
		;
		/* merge: assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))(544, 483, 544) */
		reached[3][483] = 1;
		spin_assert(( !(((int)now.inspection_accepted))||((((int)now.inspection_complete)&&((int)now.inspection_exact))&&((int)now.inspection_clean))), "( !(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean))", II, tt, t);
		/* merge: pc = 42(544, 485, 544) */
		reached[3][485] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 42;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 204: // STATE 486 - governed-local.pml:422 - [((pc==42))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][486] = 1;
		if (!((((int)now.pc)==42)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 205: // STATE 487 - governed-local.pml:194 - [inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))] (0:497:1 - 1)
		IfNotBlocked
		reached[3][487] = 1;
		(trpt+1)->bup.oval = ((int)now.inspection_postcheck);
		now.inspection_postcheck = (((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)));
#ifdef VAR_RANGES
		logval("inspection_postcheck", ((int)now.inspection_postcheck));
#endif
		;
		/* merge: assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))(497, 488, 497) */
		reached[3][488] = 1;
		spin_assert(( !(((int)now.inspection_postcheck))||(((((((int)now.authority_available)&&((int)now.grant_active))&&(((int)now.grant_epoch)==((int)now.session_grant_epoch)))&&(((int)now.policy_epoch)==1))&&(((int)now.key_epoch)==1))&&(((int)now.lease_epoch)==((int)now.credential_epoch)))), "( !(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 206: // STATE 490 - governed-local.pml:425 - [((inspection_accepted&&inspection_postcheck))] (544:0:2 - 1)
		IfNotBlocked
		reached[3][490] = 1;
		if (!((((int)now.inspection_accepted)&&((int)now.inspection_postcheck))))
			continue;
		/* merge: outbound_inspected = 1(544, 491, 544) */
		reached[3][491] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.outbound_inspected);
		now.outbound_inspected = 1;
#ifdef VAR_RANGES
		logval("outbound_inspected", ((int)now.outbound_inspected));
#endif
		;
		/* merge: pc = 4(544, 492, 544) */
		reached[3][492] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 498, 544) */
		reached[3][498] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 207: // STATE 493 - governed-local.pml:426 - [((!(inspection_accepted)||!(inspection_postcheck)))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][493] = 1;
		if (!(( !(((int)now.inspection_accepted))|| !(((int)now.inspection_postcheck)))))
			continue;
		/* merge: inspection_denied = 1(544, 494, 544) */
		reached[3][494] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)inspection_denied);
		inspection_denied = 1;
#ifdef VAR_RANGES
		logval("inspection_denied", ((int)inspection_denied));
#endif
		;
		/* merge: terminal = Denied(544, 495, 544) */
		reached[3][495] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 496, 544) */
		reached[3][496] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 498, 544) */
		reached[3][498] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 208: // STATE 499 - governed-local.pml:429 - [((pc==20))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][499] = 1;
		if (!((((int)now.pc)==20)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 209: // STATE 500 - governed-local.pml:434 - [((attempt_tenant!=1))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][500] = 1;
		if (!((((int)now.attempt_tenant)!=1)))
			continue;
		/* merge: foreign_denied = 1(544, 501, 544) */
		reached[3][501] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)foreign_denied);
		foreign_denied = 1;
#ifdef VAR_RANGES
		logval("foreign_denied", ((int)foreign_denied));
#endif
		;
		/* merge: terminal = Denied(544, 502, 544) */
		reached[3][502] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 503, 544) */
		reached[3][503] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 514, 544) */
		reached[3][514] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 210: // STATE 504 - governed-local.pml:440 - [((attempt_tenant==1))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][504] = 1;
		if (!((((int)now.attempt_tenant)==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 211: // STATE 505 - governed-local.pml:442 - [((attempt_original!=bound_original))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][505] = 1;
		if (!((((int)now.attempt_original)!=((int)now.bound_original))))
			continue;
		/* merge: input_conflict = 1(544, 506, 544) */
		reached[3][506] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)input_conflict);
		input_conflict = 1;
#ifdef VAR_RANGES
		logval("input_conflict", ((int)input_conflict));
#endif
		;
		/* merge: terminal = Denied(544, 507, 544) */
		reached[3][507] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 508, 544) */
		reached[3][508] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 512, 544) */
		reached[3][512] = 1;
		;
		/* merge: .(goto)(0, 514, 544) */
		reached[3][514] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 212: // STATE 509 - governed-local.pml:449 - [((attempt_original==bound_original))] (544:0:1 - 1)
		IfNotBlocked
		reached[3][509] = 1;
		if (!((((int)now.attempt_original)==((int)now.bound_original))))
			continue;
		/* merge: pc = 21(0, 510, 544) */
		reached[3][510] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 21;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 512, 544) */
		reached[3][512] = 1;
		;
		/* merge: .(goto)(0, 514, 544) */
		reached[3][514] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 213: // STATE 515 - governed-local.pml:452 - [((pc==21))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][515] = 1;
		if (!((((int)now.pc)==21)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 214: // STATE 516 - governed-local.pml:454 - [((effect_state==Unknown))] (544:0:3 - 1)
		IfNotBlocked
		reached[3][516] = 1;
		if (!((now.effect_state==10)))
			continue;
		/* merge: assert((calls==sealed_calls))(544, 517, 544) */
		reached[3][517] = 1;
		spin_assert((((int)now.calls)==((int)now.sealed_calls)), "(calls==sealed_calls)", II, tt, t);
		/* merge: unknown_retry_blocked = 1(544, 518, 544) */
		reached[3][518] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)unknown_retry_blocked);
		unknown_retry_blocked = 1;
#ifdef VAR_RANGES
		logval("unknown_retry_blocked", ((int)unknown_retry_blocked));
#endif
		;
		/* merge: terminal = Blocked(544, 519, 544) */
		reached[3][519] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: finished = 1(544, 520, 544) */
		reached[3][520] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 528, 544) */
		reached[3][528] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 215: // STATE 521 - governed-local.pml:460 - [((effect_state==Completed))] (544:0:4 - 1)
		IfNotBlocked
		reached[3][521] = 1;
		if (!((now.effect_state==11)))
			continue;
		/* merge: assert((effect_state==Completed))(544, 522, 544) */
		reached[3][522] = 1;
		spin_assert((now.effect_state==11), "(effect_state==11)", II, tt, t);
		/* merge: replayed = 1(544, 523, 544) */
		reached[3][523] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: protocol_output = journal_output(544, 524, 544) */
		reached[3][524] = 1;
		(trpt+1)->bup.ovals[1] = now.protocol_output;
		now.protocol_output = now.journal_output;
#ifdef VAR_RANGES
		logval("protocol_output", now.protocol_output);
#endif
		;
		/* merge: protocol_completed = 1(544, 525, 544) */
		reached[3][525] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.protocol_completed);
		now.protocol_completed = 1;
#ifdef VAR_RANGES
		logval("protocol_completed", ((int)now.protocol_completed));
#endif
		;
		/* merge: pc = 13(544, 526, 544) */
		reached[3][526] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 528, 544) */
		reached[3][528] = 1;
		;
		/* merge: .(goto)(0, 530, 544) */
		reached[3][530] = 1;
		;
		/* merge: .(goto)(0, 532, 544) */
		reached[3][532] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 216: // STATE 533 - governed-local.pml:93 - [assert((calls<=1))] (0:546:0 - 1)
		IfNotBlocked
		reached[3][533] = 1;
		spin_assert((((int)now.calls)<=1), "(calls<=1)", II, tt, t);
		/* merge: assert(((journal_input!=Raw)&&(protocol_input!=Raw)))(546, 534, 546) */
		reached[3][534] = 1;
		spin_assert(((now.journal_input!=7)&&(now.protocol_input!=7)), "((journal_input!=7)&&(protocol_input!=7))", II, tt, t);
		/* merge: assert((((journal_output!=Raw)&&(protocol_output!=Raw))&&(receipt_payload!=Raw)))(546, 535, 546) */
		reached[3][535] = 1;
		spin_assert((((now.journal_output!=7)&&(now.protocol_output!=7))&&(now.receipt_payload!=7)), "(((journal_output!=7)&&(protocol_output!=7))&&(receipt_payload!=7))", II, tt, t);
		/* merge: assert(((bound_original==0)||(bound_original==1)))(546, 536, 546) */
		reached[3][536] = 1;
		spin_assert(((((int)now.bound_original)==0)||(((int)now.bound_original)==1)), "((bound_original==0)||(bound_original==1))", II, tt, t);
		/* merge: assert((receipt==(effect_state==Completed)))(546, 537, 546) */
		reached[3][537] = 1;
		spin_assert((((int)now.receipt)==(now.effect_state==11)), "(receipt==(effect_state==11))", II, tt, t);
		/* merge: assert((!(receipt)||(retained_certainty==sealed_certainty)))(546, 538, 546) */
		reached[3][538] = 1;
		spin_assert(( !(((int)now.receipt))||(((int)now.retained_certainty)==((int)now.sealed_certainty))), "( !(receipt)||(retained_certainty==sealed_certainty))", II, tt, t);
		/* merge: assert((!(receipt)||(retained_withheld==sealed_withheld)))(546, 539, 546) */
		reached[3][539] = 1;
		spin_assert(( !(((int)now.receipt))||(((int)now.retained_withheld)==((int)now.sealed_withheld))), "( !(receipt)||(retained_withheld==sealed_withheld))", II, tt, t);
		/* merge: assert((!(receipt)||(retained_certainty==observed_certainty)))(546, 540, 546) */
		reached[3][540] = 1;
		spin_assert(( !(((int)now.receipt))||(((int)now.retained_certainty)==((int)now.observed_certainty))), "( !(receipt)||(retained_certainty==observed_certainty))", II, tt, t);
		/* merge: assert((!(protocol_completed)||(receipt&&(protocol_output==journal_output))))(546, 541, 546) */
		reached[3][541] = 1;
		spin_assert(( !(((int)now.protocol_completed))||(((int)now.receipt)&&(now.protocol_output==now.journal_output))), "( !(protocol_completed)||(receipt&&(protocol_output==journal_output)))", II, tt, t);
		/* merge: assert((!(replayed)||(calls==sealed_calls)))(546, 542, 546) */
		reached[3][542] = 1;
		spin_assert(( !(((int)now.replayed))||(((int)now.calls)==((int)now.sealed_calls))), "( !(replayed)||(calls==sealed_calls))", II, tt, t);
		/* merge: assert(((terminal!=Delivered)||(delivery_check&&(attempt_tenant==1))))(546, 543, 546) */
		reached[3][543] = 1;
		spin_assert(((now.terminal!=3)||(((int)now.delivery_check)&&(((int)now.attempt_tenant)==1))), "((terminal!=3)||(delivery_check&&(attempt_tenant==1)))", II, tt, t);
		/* merge: .(goto)(0, 547, 546) */
		reached[3][547] = 1;
		;
		_m = 3; goto P999; /* 11 */
	case 217: // STATE 549 - governed-local.pml:502 - [assert(!(((epoch_refreshed&&replayed)&&(terminal==Delivered))))] (0:0:0 - 3)
		IfNotBlocked
		reached[3][549] = 1;
		spin_assert( !(((((int)now.epoch_refreshed)&&((int)now.replayed))&&(now.terminal==3))), " !(((epoch_refreshed&&replayed)&&(terminal==3)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 218: // STATE 550 - governed-local.pml:516 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[3][550] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC External */
	case 219: // STATE 1 - governed-local.pml:139 - [requests?request_id] (0:0:2 - 1)
		reached[2][1] = 1;
		if (q_len(now.requests) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P2 *)_this)->request_id);
		;
		((P2 *)_this)->request_id = qrecv(now.requests, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("External:request_id", ((int)((P2 *)_this)->request_id));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.requests);
			sprintf(simtmp, "%d", ((int)((P2 *)_this)->request_id)); strcat(simvals, simtmp);
		}
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: request_id */  (trpt+1)->bup.ovals[1] = ((P2 *)_this)->request_id;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->request_id = 0;
		_m = 4; goto P999; /* 0 */
	case 220: // STATE 2 - governed-local.pml:143 - [output = Safe] (0:0:1 - 1)
		IfNotBlocked
		reached[2][2] = 1;
		(trpt+1)->bup.oval = ((P2 *)_this)->output;
		((P2 *)_this)->output = 8;
#ifdef VAR_RANGES
		logval("External:output", ((P2 *)_this)->output);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 221: // STATE 3 - governed-local.pml:143 - [output = Raw] (0:0:1 - 1)
		IfNotBlocked
		reached[2][3] = 1;
		(trpt+1)->bup.oval = ((P2 *)_this)->output;
		((P2 *)_this)->output = 7;
#ifdef VAR_RANGES
		logval("External:output", ((P2 *)_this)->output);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 222: // STATE 4 - governed-local.pml:143 - [output = TransportLost] (0:0:1 - 1)
		IfNotBlocked
		reached[2][4] = 1;
		(trpt+1)->bup.oval = ((P2 *)_this)->output;
		((P2 *)_this)->output = 5;
#ifdef VAR_RANGES
		logval("External:output", ((P2 *)_this)->output);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 223: // STATE 7 - governed-local.pml:144 - [certainty = 0] (0:13:1 - 1)
		IfNotBlocked
		reached[2][7] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->certainty);
		((P2 *)_this)->certainty = 0;
#ifdef VAR_RANGES
		logval("External:certainty", ((int)((P2 *)_this)->certainty));
#endif
		;
		/* merge: .(goto)(13, 12, 13) */
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 224: // STATE 12 - governed-local.pml:145 - [.(goto)] (0:13:0 - 4)
		IfNotBlocked
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 0 */
	case 225: // STATE 8 - governed-local.pml:144 - [certainty = 1] (0:13:1 - 1)
		IfNotBlocked
		reached[2][8] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->certainty);
		((P2 *)_this)->certainty = 1;
#ifdef VAR_RANGES
		logval("External:certainty", ((int)((P2 *)_this)->certainty));
#endif
		;
		/* merge: .(goto)(13, 12, 13) */
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 226: // STATE 9 - governed-local.pml:144 - [certainty = 2] (0:13:1 - 1)
		IfNotBlocked
		reached[2][9] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->certainty);
		((P2 *)_this)->certainty = 2;
#ifdef VAR_RANGES
		logval("External:certainty", ((int)((P2 *)_this)->certainty));
#endif
		;
		/* merge: .(goto)(13, 12, 13) */
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 227: // STATE 10 - governed-local.pml:144 - [certainty = 3] (0:13:1 - 1)
		IfNotBlocked
		reached[2][10] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->certainty);
		((P2 *)_this)->certainty = 3;
#ifdef VAR_RANGES
		logval("External:certainty", ((int)((P2 *)_this)->certainty));
#endif
		;
		/* merge: .(goto)(13, 12, 13) */
		reached[2][12] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 228: // STATE 13 - governed-local.pml:145 - [results!output,certainty] (0:0:0 - 1)
		IfNotBlocked
		reached[2][13] = 1;
		if (q_full(now.results))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.results);
		sprintf(simtmp, "%d", ((P2 *)_this)->output); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)_this)->certainty)); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.results, 0, ((P2 *)_this)->output, ((int)((P2 *)_this)->certainty), 2);
		_m = 2; goto P999; /* 0 */
	case 229: // STATE 15 - governed-local.pml:147 - [(finished)] (0:0:0 - 1)
		IfNotBlocked
		reached[2][15] = 1;
		if (!(((int)now.finished)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 230: // STATE 19 - governed-local.pml:149 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[2][19] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Crash */
	case 231: // STATE 2 - governed-local.pml:130 - [(!(finished))] (8:0:2 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!( !(((int)now.finished))))
			continue;
		/* merge: crash = 1(8, 3, 8) */
		reached[1][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.crash);
		now.crash = 1;
#ifdef VAR_RANGES
		logval("crash", ((int)now.crash));
#endif
		;
		/* merge: crashed_once = 1(8, 4, 8) */
		reached[1][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)crashed_once);
		crashed_once = 1;
#ifdef VAR_RANGES
		logval("crashed_once", ((int)crashed_once));
#endif
		;
		/* merge: .(goto)(0, 7, 8) */
		reached[1][7] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 232: // STATE 8 - governed-local.pml:132 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[1][8] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Authority */
	case 233: // STATE 2 - governed-local.pml:113 - [(!(finished))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 234: // STATE 3 - governed-local.pml:115 - [grant_active = 0] (0:15:2 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.grant_active);
		now.grant_active = 0;
#ifdef VAR_RANGES
		logval("grant_active", ((int)now.grant_active));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 235: // STATE 10 - governed-local.pml:122 - [.(goto)] (0:15:1 - 6)
		IfNotBlocked
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.oval = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 236: // STATE 4 - governed-local.pml:116 - [authority_available = 0] (0:15:2 - 1)
		IfNotBlocked
		reached[0][4] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.authority_available);
		now.authority_available = 0;
#ifdef VAR_RANGES
		logval("authority_available", ((int)now.authority_available));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 237: // STATE 5 - governed-local.pml:117 - [grant_epoch = 2] (0:15:2 - 1)
		IfNotBlocked
		reached[0][5] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.grant_epoch);
		now.grant_epoch = 2;
#ifdef VAR_RANGES
		logval("grant_epoch", ((int)now.grant_epoch));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 238: // STATE 6 - governed-local.pml:118 - [policy_epoch = 2] (0:15:2 - 1)
		IfNotBlocked
		reached[0][6] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.policy_epoch);
		now.policy_epoch = 2;
#ifdef VAR_RANGES
		logval("policy_epoch", ((int)now.policy_epoch));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 239: // STATE 7 - governed-local.pml:119 - [key_epoch = 2] (0:15:2 - 1)
		IfNotBlocked
		reached[0][7] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.key_epoch);
		now.key_epoch = 2;
#ifdef VAR_RANGES
		logval("key_epoch", ((int)now.key_epoch));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 240: // STATE 8 - governed-local.pml:120 - [credential_epoch = 2] (0:15:2 - 1)
		IfNotBlocked
		reached[0][8] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.credential_epoch);
		now.credential_epoch = 2;
#ifdef VAR_RANGES
		logval("credential_epoch", ((int)now.credential_epoch));
#endif
		;
		/* merge: .(goto)(15, 10, 15) */
		reached[0][10] = 1;
		;
		/* merge: authority_changed = 1(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)authority_changed);
		authority_changed = 1;
#ifdef VAR_RANGES
		logval("authority_changed", ((int)authority_changed));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 241: // STATE 15 - governed-local.pml:125 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[0][15] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

