#ifdef PEG
struct T_SRC {
	char *fl; int ln;
} T_SRC[NTRANS];

void
tr_2_src(int m, char *file, int ln)
{	T_SRC[m].fl = file;
	T_SRC[m].ln = ln;
}

void
putpeg(int n, int m)
{	printf("%5d	trans %4d ", m, n);
	printf("%s:%d\n",
		T_SRC[n].fl, T_SRC[n].ln);
}
#endif

void
settable(void)
{	Trans *T;
	Trans *settr(int, int, int, int, int, char *, int, int, int);

	trans = (Trans ***) emalloc(7*sizeof(Trans **));

	/* proctype 5: governed_local_settles */

	trans[5] = (Trans **) emalloc(7*sizeof(Trans *));

	trans[5][4]	= settr(601,0,3,1,0,".(goto)", 0, 2, 0);
	T = trans[5][3] = settr(600,0,0,0,0,"DO", 0, 2, 0);
	    T->nxt	= settr(600,0,1,0,0,"DO", 0, 2, 0);
	trans[5][1]	= settr(598,0,3,3,0,"(!(finished))", 1, 2, 0);
	trans[5][2]	= settr(599,0,3,1,0,"goto T0_init", 0, 2, 0);
	trans[5][5]	= settr(602,0,6,1,0,"break", 0, 2, 0);
	trans[5][6]	= settr(603,0,0,4,4,"-end-", 0, 3500, 0);

	/* proctype 4: :init: */

	trans[4] = (Trans **) emalloc(7*sizeof(Trans *));

	T = trans[ 4][5] = settr(596,2,0,0,0,"ATOMIC", 0, 2, 0);
	T->nxt	= settr(596,2,1,0,0,"ATOMIC", 0, 2, 0);
	trans[4][1]	= settr(592,2,2,5,5,"(run Host())", 0, 2, 0);
	trans[4][2]	= settr(593,2,3,6,6,"(run External())", 0, 2, 0);
	trans[4][3]	= settr(594,2,4,7,7,"(run Authority())", 0, 2, 0);
	trans[4][4]	= settr(595,0,6,8,8,"(run Crash())", 0, 2, 0);
	trans[4][6]	= settr(597,0,0,9,9,"-end-", 0, 3500, 0);

	/* proctype 3: Host */

	trans[3] = (Trans **) emalloc(551*sizeof(Trans *));

	trans[3][1]	= settr(42,0,2,10,10,"attempt_tenant = 1", 1, 2, 0);
	trans[3][2]	= settr(43,0,546,11,11,"attempt_original = 1", 1, 2, 0);
	trans[3][547]	= settr(588,0,546,1,0,".(goto)", 0, 2, 0);
	T = trans[3][546] = settr(587,0,0,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(587,0,3,0,0,"DO", 0, 2, 0);
	    T->nxt	= settr(587,0,5,0,0,"DO", 0, 2, 0);
	trans[3][3]	= settr(44,0,549,12,0,"(finished)", 1, 2, 0);
	trans[3][4]	= settr(45,0,549,1,0,"goto :b0", 0, 2, 0);
	trans[3][5]	= settr(46,0,545,13,0,"(!(finished))", 1, 2, 0);
	T = trans[ 3][545] = settr(586,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(586,2,531,0,0,"ATOMIC", 1, 3, 504);
	T = trans[3][531] = settr(572,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(572,2,6,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(572,2,95,0,0,"IF", 1, 3, 504);
	trans[3][6]	= settr(47,2,93,14,14,"(crash)", 1, 3, 504); /* m: 7 -> 93,0 */
	reached3[7] = 1;
	trans[3][7]	= settr(0,0,0,0,0,"crash = 0",0,0,0);
	trans[3][8]	= settr(0,0,0,0,0,"restarted = 1",0,0,0);
	T = trans[3][93] = settr(134,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(134,2,9,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(134,2,36,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(134,2,66,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(134,2,91,0,0,"IF", 1, 3, 504);
	trans[3][9]	= settr(50,2,35,15,15,"((effect_state==Executing))", 1, 3, 504); /* m: 10 -> 35,0 */
	reached3[10] = 1;
	trans[3][10]	= settr(0,0,0,0,0,"effect_state = Unknown",0,0,0);
	trans[3][11]	= settr(0,0,0,0,0,"unknown_seen = 1",0,0,0);
	trans[3][12]	= settr(0,0,0,0,0,"terminal = Blocked",0,0,0);
	T = trans[ 3][35] = settr(76,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(76,0,13,0,0,"sub-sequence", 1, 3, 504);
	trans[3][13]	= settr(54,2,16,16,16,"terminal = Running", 1, 3, 504);
	T = trans[3][16] = settr(57,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(57,2,14,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(57,2,15,0,0,"IF", 1, 3, 504);
	trans[3][14]	= settr(55,2,20,17,17,"attempt_tenant = 1", 1, 3, 504);
	trans[3][17]	= settr(58,2,20,1,0,".(goto)", 1, 3, 504);
	trans[3][15]	= settr(56,2,20,18,18,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][20] = settr(61,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(61,2,18,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(61,2,19,0,0,"IF", 1, 3, 504);
	trans[3][18]	= settr(59,2,31,19,19,"attempt_original = 1", 1, 3, 504);
	trans[3][21]	= settr(62,2,31,1,0,".(goto)", 1, 3, 504);
	trans[3][19]	= settr(60,2,31,20,20,"attempt_original = 2", 1, 3, 504);
	T = trans[3][31] = settr(72,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(72,2,22,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(72,2,23,0,0,"IF", 1, 3, 504);
	trans[3][22]	= settr(63,2,544,21,21,"(1)", 1, 3, 504); /* m: 33 -> 544,0 */
	reached3[33] = 1;
	trans[3][32]	= settr(73,2,33,1,0,".(goto)", 1, 3, 504); /* m: 33 -> 0,544 */
	reached3[33] = 1;
	trans[3][23]	= settr(64,2,29,22,22,"lease_epoch = credential_epoch", 1, 3, 504); /* m: 24 -> 0,29 */
	reached3[24] = 1;
	trans[3][24]	= settr(0,0,0,0,0,"session_grant_epoch = grant_epoch",0,0,0);
	T = trans[3][29] = settr(70,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(70,2,25,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(70,2,27,0,0,"IF", 1, 3, 504);
	trans[3][25]	= settr(66,2,544,23,23,"((grant_epoch==2))", 1, 3, 504); /* m: 26 -> 544,0 */
	reached3[26] = 1;
	trans[3][26]	= settr(0,0,0,0,0,"epoch_refreshed = 1",0,0,0);
	trans[3][30]	= settr(71,2,33,1,0,".(goto)", 1, 3, 504); /* m: 33 -> 0,544 */
	reached3[33] = 1;
	trans[3][27]	= settr(68,2,28,2,0,"else", 1, 3, 504);
	trans[3][28]	= settr(69,2,544,24,24,"(1)", 1, 3, 504); /* m: 33 -> 544,0 */
	reached3[33] = 1;
	trans[3][33]	= settr(74,2,544,25,25,"sealed_calls = calls", 1, 3, 504); /* m: 34 -> 0,544 */
	reached3[34] = 1;
	trans[3][34]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][94]	= settr(135,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][36]	= settr(77,2,41,26,0,"((effect_state==Completed))", 1, 3, 504);
	T = trans[3][41] = settr(82,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(82,2,37,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(82,2,39,0,0,"IF", 1, 3, 504);
	trans[3][37]	= settr(78,2,65,27,27,"(!(protocol_completed))", 1, 3, 504); /* m: 38 -> 65,0 */
	reached3[38] = 1;
	trans[3][38]	= settr(0,0,0,0,0,"completion_gap_crash = 1",0,0,0);
	trans[3][42]	= settr(83,2,65,1,0,".(goto)", 1, 3, 504);
	trans[3][39]	= settr(80,2,40,2,0,"else", 1, 3, 504);
	trans[3][40]	= settr(81,2,65,1,0,"(1)", 1, 3, 504);
	T = trans[ 3][65] = settr(106,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(106,0,43,0,0,"sub-sequence", 1, 3, 504);
	trans[3][43]	= settr(84,2,46,28,28,"terminal = Running", 1, 3, 504);
	T = trans[3][46] = settr(87,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(87,2,44,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(87,2,45,0,0,"IF", 1, 3, 504);
	trans[3][44]	= settr(85,2,50,29,29,"attempt_tenant = 1", 1, 3, 504);
	trans[3][47]	= settr(88,2,50,1,0,".(goto)", 1, 3, 504);
	trans[3][45]	= settr(86,2,50,30,30,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][50] = settr(91,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(91,2,48,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(91,2,49,0,0,"IF", 1, 3, 504);
	trans[3][48]	= settr(89,2,61,31,31,"attempt_original = 1", 1, 3, 504);
	trans[3][51]	= settr(92,2,61,1,0,".(goto)", 1, 3, 504);
	trans[3][49]	= settr(90,2,61,32,32,"attempt_original = 2", 1, 3, 504);
	T = trans[3][61] = settr(102,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(102,2,52,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(102,2,53,0,0,"IF", 1, 3, 504);
	trans[3][52]	= settr(93,2,544,33,33,"(1)", 1, 3, 504); /* m: 63 -> 544,0 */
	reached3[63] = 1;
	trans[3][62]	= settr(103,2,63,1,0,".(goto)", 1, 3, 504); /* m: 63 -> 0,544 */
	reached3[63] = 1;
	trans[3][53]	= settr(94,2,59,34,34,"lease_epoch = credential_epoch", 1, 3, 504); /* m: 54 -> 0,59 */
	reached3[54] = 1;
	trans[3][54]	= settr(0,0,0,0,0,"session_grant_epoch = grant_epoch",0,0,0);
	T = trans[3][59] = settr(100,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(100,2,55,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(100,2,57,0,0,"IF", 1, 3, 504);
	trans[3][55]	= settr(96,2,544,35,35,"((grant_epoch==2))", 1, 3, 504); /* m: 56 -> 544,0 */
	reached3[56] = 1;
	trans[3][56]	= settr(0,0,0,0,0,"epoch_refreshed = 1",0,0,0);
	trans[3][60]	= settr(101,2,63,1,0,".(goto)", 1, 3, 504); /* m: 63 -> 0,544 */
	reached3[63] = 1;
	trans[3][57]	= settr(98,2,58,2,0,"else", 1, 3, 504);
	trans[3][58]	= settr(99,2,544,36,36,"(1)", 1, 3, 504); /* m: 63 -> 544,0 */
	reached3[63] = 1;
	trans[3][63]	= settr(104,2,544,37,37,"sealed_calls = calls", 1, 3, 504); /* m: 64 -> 0,544 */
	reached3[64] = 1;
	trans[3][64]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][66]	= settr(107,2,90,38,38,"((effect_state==Unknown))", 1, 3, 504); /* m: 67 -> 90,0 */
	reached3[67] = 1;
	trans[3][67]	= settr(0,0,0,0,0,"terminal = Blocked",0,0,0);
	T = trans[ 3][90] = settr(131,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(131,0,68,0,0,"sub-sequence", 1, 3, 504);
	trans[3][68]	= settr(109,2,71,39,39,"terminal = Running", 1, 3, 504);
	T = trans[3][71] = settr(112,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(112,2,69,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(112,2,70,0,0,"IF", 1, 3, 504);
	trans[3][69]	= settr(110,2,75,40,40,"attempt_tenant = 1", 1, 3, 504);
	trans[3][72]	= settr(113,2,75,1,0,".(goto)", 1, 3, 504);
	trans[3][70]	= settr(111,2,75,41,41,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][75] = settr(116,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(116,2,73,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(116,2,74,0,0,"IF", 1, 3, 504);
	trans[3][73]	= settr(114,2,86,42,42,"attempt_original = 1", 1, 3, 504);
	trans[3][76]	= settr(117,2,86,1,0,".(goto)", 1, 3, 504);
	trans[3][74]	= settr(115,2,86,43,43,"attempt_original = 2", 1, 3, 504);
	T = trans[3][86] = settr(127,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(127,2,77,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(127,2,78,0,0,"IF", 1, 3, 504);
	trans[3][77]	= settr(118,2,544,44,44,"(1)", 1, 3, 504); /* m: 88 -> 544,0 */
	reached3[88] = 1;
	trans[3][87]	= settr(128,2,88,1,0,".(goto)", 1, 3, 504); /* m: 88 -> 0,544 */
	reached3[88] = 1;
	trans[3][78]	= settr(119,2,84,45,45,"lease_epoch = credential_epoch", 1, 3, 504); /* m: 79 -> 0,84 */
	reached3[79] = 1;
	trans[3][79]	= settr(0,0,0,0,0,"session_grant_epoch = grant_epoch",0,0,0);
	T = trans[3][84] = settr(125,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(125,2,80,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(125,2,82,0,0,"IF", 1, 3, 504);
	trans[3][80]	= settr(121,2,544,46,46,"((grant_epoch==2))", 1, 3, 504); /* m: 81 -> 544,0 */
	reached3[81] = 1;
	trans[3][81]	= settr(0,0,0,0,0,"epoch_refreshed = 1",0,0,0);
	trans[3][85]	= settr(126,2,88,1,0,".(goto)", 1, 3, 504); /* m: 88 -> 0,544 */
	reached3[88] = 1;
	trans[3][82]	= settr(123,2,83,2,0,"else", 1, 3, 504);
	trans[3][83]	= settr(124,2,544,47,47,"(1)", 1, 3, 504); /* m: 88 -> 544,0 */
	reached3[88] = 1;
	trans[3][88]	= settr(129,2,544,48,48,"sealed_calls = calls", 1, 3, 504); /* m: 89 -> 0,544 */
	reached3[89] = 1;
	trans[3][89]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][91]	= settr(132,2,92,2,0,"else", 1, 3, 504);
	trans[3][92]	= settr(133,2,544,49,49,"pc = 0", 1, 3, 504);
	trans[3][532]	= settr(573,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][95]	= settr(136,2,529,50,0,"(!(crash))", 1, 3, 504);
	T = trans[3][529] = settr(570,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,96,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,105,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,111,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,120,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,124,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,134,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,139,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,148,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,158,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,162,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,165,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,197,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,207,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,223,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,246,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,263,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,267,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,284,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,328,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,344,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,384,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,417,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,426,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,442,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,461,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,470,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,486,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(570,2,499,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(570,2,515,0,0,"IF", 1, 3, 504);
	trans[3][96]	= settr(137,2,103,51,51,"((pc==0))", 1, 3, 504); /* m: 97 -> 103,0 */
	reached3[97] = 1;
	trans[3][97]	= settr(0,0,0,0,0,"request_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))",0,0,0);
	T = trans[3][103] = settr(144,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(144,2,98,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(144,2,100,0,0,"IF", 1, 3, 504);
	trans[3][98]	= settr(139,2,544,52,52,"(request_check)", 1, 3, 504); /* m: 99 -> 544,0 */
	reached3[99] = 1;
	trans[3][99]	= settr(0,0,0,0,0,"pc = 30",0,0,0);
	trans[3][104]	= settr(145,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][100]	= settr(141,2,544,53,53,"(!(request_check))", 1, 3, 504); /* m: 101 -> 544,0 */
	reached3[101] = 1;
	trans[3][101]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][102]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][530]	= settr(571,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][105]	= settr(146,2,544,54,54,"((pc==1))", 1, 3, 504); /* m: 106 -> 544,0 */
	reached3[106] = 1;
	trans[3][106]	= settr(0,0,0,0,0,"assert(request_check)",0,0,0);
	trans[3][107]	= settr(0,0,0,0,0,"assert(input_inspected)",0,0,0);
	trans[3][108]	= settr(0,0,0,0,0,"bound_original = 1",0,0,0);
	trans[3][109]	= settr(0,0,0,0,0,"journal_input = Safe",0,0,0);
	trans[3][110]	= settr(0,0,0,0,0,"pc = 2",0,0,0);
	trans[3][111]	= settr(152,2,118,55,55,"((pc==2))", 1, 3, 504); /* m: 112 -> 118,0 */
	reached3[112] = 1;
	trans[3][112]	= settr(0,0,0,0,0,"protocol_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))",0,0,0);
	T = trans[3][118] = settr(159,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(159,2,113,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(159,2,115,0,0,"IF", 1, 3, 504);
	trans[3][113]	= settr(154,2,544,56,56,"(protocol_check)", 1, 3, 504); /* m: 114 -> 544,0 */
	reached3[114] = 1;
	trans[3][114]	= settr(0,0,0,0,0,"pc = 23",0,0,0);
	trans[3][119]	= settr(160,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][115]	= settr(156,2,544,57,57,"(!(protocol_check))", 1, 3, 504); /* m: 116 -> 544,0 */
	reached3[116] = 1;
	trans[3][116]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][117]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][120]	= settr(161,2,544,58,58,"((pc==23))", 1, 3, 504); /* m: 121 -> 544,0 */
	reached3[121] = 1;
	trans[3][121]	= settr(0,0,0,0,0,"assert(protocol_check)",0,0,0);
	trans[3][122]	= settr(0,0,0,0,0,"protocol_input = journal_input",0,0,0);
	trans[3][123]	= settr(0,0,0,0,0,"pc = 3",0,0,0);
	trans[3][124]	= settr(165,2,132,59,59,"((pc==3))", 1, 3, 504); /* m: 125 -> 132,0 */
	reached3[125] = 1;
	trans[3][125]	= settr(0,0,0,0,0,"effect_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))",0,0,0);
	trans[3][126]	= settr(0,0,0,0,0,"assert((!(effect_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))",0,0,0);
	T = trans[3][132] = settr(173,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(173,2,127,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(173,2,129,0,0,"IF", 1, 3, 504);
	trans[3][127]	= settr(168,2,544,60,60,"(effect_check)", 1, 3, 504); /* m: 128 -> 544,0 */
	reached3[128] = 1;
	trans[3][128]	= settr(0,0,0,0,0,"pc = 40",0,0,0);
	trans[3][133]	= settr(174,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][129]	= settr(170,2,544,61,61,"(!(effect_check))", 1, 3, 504); /* m: 130 -> 544,0 */
	reached3[130] = 1;
	trans[3][130]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][131]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][134]	= settr(175,2,544,62,62,"((pc==4))", 1, 3, 504); /* m: 135 -> 544,0 */
	reached3[135] = 1;
	trans[3][135]	= settr(0,0,0,0,0,"assert(outbound_inspected)",0,0,0);
	trans[3][136]	= settr(0,0,0,0,0,"effect_state = Prepared",0,0,0);
	trans[3][137]	= settr(0,0,0,0,0,"reservation = 1",0,0,0);
	trans[3][138]	= settr(0,0,0,0,0,"pc = 5",0,0,0);
	trans[3][139]	= settr(180,2,146,63,63,"((pc==5))", 1, 3, 504); /* m: 140 -> 146,0 */
	reached3[140] = 1;
	trans[3][140]	= settr(0,0,0,0,0,"effect_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))",0,0,0);
	T = trans[3][146] = settr(187,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(187,2,141,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(187,2,143,0,0,"IF", 1, 3, 504);
	trans[3][141]	= settr(182,2,544,64,64,"(effect_check)", 1, 3, 504); /* m: 142 -> 544,0 */
	reached3[142] = 1;
	trans[3][142]	= settr(0,0,0,0,0,"pc = 6",0,0,0);
	trans[3][147]	= settr(188,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][143]	= settr(184,2,544,65,65,"(!(effect_check))", 1, 3, 504); /* m: 144 -> 544,0 */
	reached3[144] = 1;
	trans[3][144]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][145]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][148]	= settr(189,2,154,66,66,"((pc==6))", 1, 3, 504); /* m: 149 -> 154,0 */
	reached3[149] = 1;
	trans[3][149]	= settr(0,0,0,0,0,"assert((effect_check&&reservation))",0,0,0);
	T = trans[3][154] = settr(195,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(195,2,150,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(195,2,152,0,0,"IF", 1, 3, 504);
	trans[3][150]	= settr(191,2,544,67,67,"(!((((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))", 1, 3, 504); /* m: 151 -> 544,0 */
	reached3[151] = 1;
	trans[3][151]	= settr(0,0,0,0,0,"check_action_race = 1",0,0,0);
	trans[3][155]	= settr(196,2,156,1,0,".(goto)", 1, 3, 504); /* m: 156 -> 0,544 */
	reached3[156] = 1;
	trans[3][152]	= settr(193,2,153,2,0,"else", 1, 3, 504);
	trans[3][153]	= settr(194,2,544,68,68,"(1)", 1, 3, 504); /* m: 156 -> 544,0 */
	reached3[156] = 1;
	trans[3][156]	= settr(197,2,544,69,69,"effect_state = Executing", 1, 3, 504); /* m: 157 -> 0,544 */
	reached3[157] = 1;
	trans[3][157]	= settr(0,0,0,0,0,"pc = 7",0,0,0);
	trans[3][158]	= settr(199,2,160,70,70,"((pc==7))", 1, 3, 504); /* m: 159 -> 160,0 */
	reached3[159] = 1;
	trans[3][159]	= settr(0,0,0,0,0,"calls = (calls+1)",0,0,0);
	trans[3][160]	= settr(201,2,544,71,71,"requests!1", 1, 3, 504); /* m: 161 -> 544,0 */
	reached3[161] = 1;
	trans[3][161]	= settr(0,0,0,0,0,"pc = 8",0,0,0);
	trans[3][162]	= settr(203,2,163,72,0,"((pc==8))", 1, 3, 504);
	trans[3][163]	= settr(204,2,544,73,73,"results?observed,observed_certainty", 1, 3, 504); /* m: 164 -> 544,0 */
	reached3[164] = 1;
	trans[3][164]	= settr(0,0,0,0,0,"pc = 9",0,0,0);
	trans[3][165]	= settr(206,2,195,74,0,"((pc==9))", 1, 3, 504);
	T = trans[3][195] = settr(236,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(236,2,166,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(236,2,193,0,0,"IF", 1, 3, 504);
	trans[3][166]	= settr(207,2,192,75,75,"((observed==TransportLost))", 1, 3, 504); /* m: 167 -> 192,0 */
	reached3[167] = 1;
	trans[3][167]	= settr(0,0,0,0,0,"effect_state = Unknown",0,0,0);
	trans[3][168]	= settr(0,0,0,0,0,"unknown_seen = 1",0,0,0);
	trans[3][169]	= settr(0,0,0,0,0,"terminal = Blocked",0,0,0);
	T = trans[ 3][192] = settr(233,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(233,0,170,0,0,"sub-sequence", 1, 3, 504);
	trans[3][170]	= settr(211,2,173,76,76,"terminal = Running", 1, 3, 504);
	T = trans[3][173] = settr(214,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(214,2,171,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(214,2,172,0,0,"IF", 1, 3, 504);
	trans[3][171]	= settr(212,2,177,77,77,"attempt_tenant = 1", 1, 3, 504);
	trans[3][174]	= settr(215,2,177,1,0,".(goto)", 1, 3, 504);
	trans[3][172]	= settr(213,2,177,78,78,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][177] = settr(218,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(218,2,175,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(218,2,176,0,0,"IF", 1, 3, 504);
	trans[3][175]	= settr(216,2,188,79,79,"attempt_original = 1", 1, 3, 504);
	trans[3][178]	= settr(219,2,188,1,0,".(goto)", 1, 3, 504);
	trans[3][176]	= settr(217,2,188,80,80,"attempt_original = 2", 1, 3, 504);
	T = trans[3][188] = settr(229,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(229,2,179,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(229,2,180,0,0,"IF", 1, 3, 504);
	trans[3][179]	= settr(220,2,544,81,81,"(1)", 1, 3, 504); /* m: 190 -> 544,0 */
	reached3[190] = 1;
	trans[3][189]	= settr(230,2,190,1,0,".(goto)", 1, 3, 504); /* m: 190 -> 0,544 */
	reached3[190] = 1;
	trans[3][180]	= settr(221,2,186,82,82,"lease_epoch = credential_epoch", 1, 3, 504); /* m: 181 -> 0,186 */
	reached3[181] = 1;
	trans[3][181]	= settr(0,0,0,0,0,"session_grant_epoch = grant_epoch",0,0,0);
	T = trans[3][186] = settr(227,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(227,2,182,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(227,2,184,0,0,"IF", 1, 3, 504);
	trans[3][182]	= settr(223,2,544,83,83,"((grant_epoch==2))", 1, 3, 504); /* m: 183 -> 544,0 */
	reached3[183] = 1;
	trans[3][183]	= settr(0,0,0,0,0,"epoch_refreshed = 1",0,0,0);
	trans[3][187]	= settr(228,2,190,1,0,".(goto)", 1, 3, 504); /* m: 190 -> 0,544 */
	reached3[190] = 1;
	trans[3][184]	= settr(225,2,185,2,0,"else", 1, 3, 504);
	trans[3][185]	= settr(226,2,544,84,84,"(1)", 1, 3, 504); /* m: 190 -> 544,0 */
	reached3[190] = 1;
	trans[3][190]	= settr(231,2,544,85,85,"sealed_calls = calls", 1, 3, 504); /* m: 191 -> 0,544 */
	reached3[191] = 1;
	trans[3][191]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][196]	= settr(237,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][193]	= settr(234,2,544,86,86,"((observed!=TransportLost))", 1, 3, 504); /* m: 194 -> 544,0 */
	reached3[194] = 1;
	trans[3][194]	= settr(0,0,0,0,0,"pc = 33",0,0,0);
	trans[3][197]	= settr(238,2,205,87,87,"((pc==33))", 1, 3, 504); /* m: 198 -> 205,0 */
	reached3[198] = 1;
	trans[3][198]	= settr(0,0,0,0,0,"inspection_precheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))",0,0,0);
	T = trans[3][205] = settr(246,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(246,2,199,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(246,2,201,0,0,"IF", 1, 3, 504);
	trans[3][199]	= settr(240,2,544,88,88,"(inspection_precheck)", 1, 3, 504); /* m: 200 -> 544,0 */
	reached3[200] = 1;
	trans[3][200]	= settr(0,0,0,0,0,"pc = 34",0,0,0);
	trans[3][206]	= settr(247,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][201]	= settr(242,2,544,89,89,"(!(inspection_precheck))", 1, 3, 504); /* m: 202 -> 544,0 */
	reached3[202] = 1;
	trans[3][202]	= settr(0,0,0,0,0,"local_withheld = 1",0,0,0);
	trans[3][203]	= settr(0,0,0,0,0,"local_output = Withheld",0,0,0);
	trans[3][204]	= settr(0,0,0,0,0,"pc = 10",0,0,0);
	trans[3][207]	= settr(248,2,221,90,0,"((pc==34))", 1, 3, 504);
	T = trans[ 3][221] = settr(262,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(262,0,208,0,0,"sub-sequence", 1, 3, 504);
	trans[3][208]	= settr(249,2,217,91,91,"inspection_complete = 1", 1, 3, 504); /* m: 209 -> 0,217 */
	reached3[209] = 1;
	trans[3][209]	= settr(0,0,0,0,0,"inspection_exact = 1",0,0,0);
	trans[3][210]	= settr(0,0,0,0,0,"inspection_clean = 1",0,0,0);
	trans[3][211]	= settr(0,0,0,0,0,"inspection_original_positive = 0",0,0,0);
	T = trans[3][217] = settr(258,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(258,2,212,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(258,2,213,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(258,2,214,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(258,2,215,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(258,2,216,0,0,"IF", 1, 3, 504);
	trans[3][212]	= settr(253,2,544,92,92,"(1)", 1, 3, 504); /* m: 219 -> 544,0 */
	reached3[219] = 1;
	trans[3][218]	= settr(259,2,219,1,0,".(goto)", 1, 3, 504); /* m: 219 -> 0,544 */
	reached3[219] = 1;
	trans[3][213]	= settr(254,2,544,93,93,"inspection_original_positive = 1", 1, 3, 504); /* m: 219 -> 0,544 */
	reached3[219] = 1;
	trans[3][214]	= settr(255,2,544,94,94,"inspection_complete = 0", 1, 3, 504); /* m: 219 -> 0,544 */
	reached3[219] = 1;
	trans[3][215]	= settr(256,2,544,95,95,"inspection_exact = 0", 1, 3, 504); /* m: 219 -> 0,544 */
	reached3[219] = 1;
	trans[3][216]	= settr(257,2,544,96,96,"inspection_clean = 0", 1, 3, 504); /* m: 219 -> 0,544 */
	reached3[219] = 1;
	trans[3][219]	= settr(260,2,544,97,97,"inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)", 1, 3, 504); /* m: 220 -> 0,544 */
	reached3[220] = 1;
	trans[3][220]	= settr(0,0,0,0,0,"assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))",0,0,0);
	trans[3][222]	= settr(0,0,0,0,0,"pc = 35",0,0,0);
	trans[3][223]	= settr(264,2,226,98,0,"((pc==35))", 1, 3, 504);
	T = trans[ 3][226] = settr(267,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(267,0,224,0,0,"sub-sequence", 1, 3, 504);
	trans[3][224]	= settr(265,2,229,99,99,"inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))", 1, 3, 504); /* m: 225 -> 0,229 */
	reached3[225] = 1;
	trans[3][225]	= settr(0,0,0,0,0,"assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))",0,0,0);
	T = trans[3][229] = settr(270,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(270,2,227,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(270,2,228,0,0,"IF", 1, 3, 504);
	trans[3][227]	= settr(268,2,237,100,100,"envelope_valid = 1", 1, 3, 504); /* m: 231 -> 0,237 */
	reached3[231] = 1;
	trans[3][230]	= settr(271,2,231,1,0,".(goto)", 1, 3, 504); /* m: 231 -> 0,237 */
	reached3[231] = 1;
	trans[3][228]	= settr(269,2,237,101,101,"envelope_valid = 0", 1, 3, 504); /* m: 231 -> 0,237 */
	reached3[231] = 1;
	trans[3][231]	= settr(272,2,237,102,102,"result_projected = (((inspection_accepted&&inspection_postcheck)&&(observed==Safe))&&envelope_valid)", 1, 3, 504); /* m: 232 -> 0,237 */
	reached3[232] = 1;
	trans[3][232]	= settr(0,0,0,0,0,"local_withheld = !(result_projected)",0,0,0);
	T = trans[3][237] = settr(278,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(278,2,233,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(278,2,235,0,0,"IF", 1, 3, 504);
	trans[3][233]	= settr(274,2,243,103,103,"(result_projected)", 1, 3, 504); /* m: 234 -> 243,0 */
	reached3[234] = 1;
	trans[3][234]	= settr(0,0,0,0,0,"local_output = Safe",0,0,0);
	trans[3][238]	= settr(279,2,243,1,0,".(goto)", 1, 3, 504);
	trans[3][235]	= settr(276,2,243,104,104,"(!(result_projected))", 1, 3, 504); /* m: 236 -> 243,0 */
	reached3[236] = 1;
	trans[3][236]	= settr(0,0,0,0,0,"local_output = Withheld",0,0,0);
	T = trans[3][243] = settr(284,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(284,2,239,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(284,2,241,0,0,"IF", 1, 3, 504);
	trans[3][239]	= settr(280,2,544,105,105,"(!(inspection_accepted))", 1, 3, 504); /* m: 240 -> 544,0 */
	reached3[240] = 1;
	trans[3][240]	= settr(0,0,0,0,0,"inspection_withheld = 1",0,0,0);
	trans[3][244]	= settr(285,2,245,1,0,".(goto)", 1, 3, 504); /* m: 245 -> 0,544 */
	reached3[245] = 1;
	trans[3][241]	= settr(282,2,242,2,0,"else", 1, 3, 504);
	trans[3][242]	= settr(283,2,544,106,106,"(1)", 1, 3, 504); /* m: 245 -> 544,0 */
	reached3[245] = 1;
	trans[3][245]	= settr(286,2,544,107,107,"pc = 10", 1, 3, 504);
	trans[3][246]	= settr(287,2,260,108,108,"((pc==10))", 1, 3, 504); /* m: 247 -> 260,0 */
	reached3[247] = 1;
	trans[3][247]	= settr(0,0,0,0,0,"receipt = 1",0,0,0);
	trans[3][248]	= settr(0,0,0,0,0,"effect_state = Completed",0,0,0);
	trans[3][249]	= settr(0,0,0,0,0,"journal_output = local_output",0,0,0);
	trans[3][250]	= settr(0,0,0,0,0,"receipt_payload = local_output",0,0,0);
	trans[3][251]	= settr(0,0,0,0,0,"retained_withheld = local_withheld",0,0,0);
	trans[3][252]	= settr(0,0,0,0,0,"sealed_withheld = local_withheld",0,0,0);
	trans[3][253]	= settr(0,0,0,0,0,"retained_certainty = observed_certainty",0,0,0);
	trans[3][254]	= settr(0,0,0,0,0,"sealed_certainty = observed_certainty",0,0,0);
	trans[3][255]	= settr(0,0,0,0,0,"assert((receipt&&(effect_state==Completed)))",0,0,0);
	T = trans[3][260] = settr(301,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(301,2,256,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(301,2,258,0,0,"IF", 1, 3, 504);
	trans[3][256]	= settr(297,2,544,109,109,"((!((((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch)))&&local_withheld))", 1, 3, 504); /* m: 257 -> 544,0 */
	reached3[257] = 1;
	trans[3][257]	= settr(0,0,0,0,0,"completed_while_revoked = 1",0,0,0);
	trans[3][261]	= settr(302,2,262,1,0,".(goto)", 1, 3, 504); /* m: 262 -> 0,544 */
	reached3[262] = 1;
	trans[3][258]	= settr(299,2,259,2,0,"else", 1, 3, 504);
	trans[3][259]	= settr(300,2,544,110,110,"(1)", 1, 3, 504); /* m: 262 -> 544,0 */
	reached3[262] = 1;
	trans[3][262]	= settr(303,2,544,111,111,"pc = 11", 1, 3, 504);
	trans[3][263]	= settr(304,2,544,112,112,"((pc==11))", 1, 3, 504); /* m: 264 -> 544,0 */
	reached3[264] = 1;
	trans[3][264]	= settr(0,0,0,0,0,"protocol_output = journal_output",0,0,0);
	trans[3][265]	= settr(0,0,0,0,0,"protocol_completed = 1",0,0,0);
	trans[3][266]	= settr(0,0,0,0,0,"pc = 12",0,0,0);
	trans[3][267]	= settr(308,2,270,113,0,"((pc==12))", 1, 3, 504);
	T = trans[3][270] = settr(311,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(311,2,268,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(311,2,269,0,0,"IF", 1, 3, 504);
	trans[3][268]	= settr(309,2,274,114,114,"forwarded_parent = 1", 1, 3, 504);
	trans[3][271]	= settr(312,2,274,1,0,".(goto)", 1, 3, 504);
	trans[3][269]	= settr(310,2,274,115,115,"forwarded_parent = 2", 1, 3, 504);
	T = trans[3][274] = settr(315,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(315,2,272,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(315,2,273,0,0,"IF", 1, 3, 504);
	trans[3][272]	= settr(313,2,280,116,116,"forwarded_actor = 1", 1, 3, 504);
	trans[3][275]	= settr(316,2,280,1,0,".(goto)", 1, 3, 504);
	trans[3][273]	= settr(314,2,280,117,117,"forwarded_actor = 2", 1, 3, 504);
	T = trans[3][280] = settr(321,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(321,2,276,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(321,2,278,0,0,"IF", 1, 3, 504);
	trans[3][276]	= settr(317,2,544,118,118,"((local_withheld&&((forwarded_parent!=1)||(forwarded_actor!=1))))", 1, 3, 504); /* m: 277 -> 544,0 */
	reached3[277] = 1;
	trans[3][277]	= settr(0,0,0,0,0,"forwarded_certainty = 0",0,0,0);
	trans[3][281]	= settr(322,2,282,1,0,".(goto)", 1, 3, 504); /* m: 282 -> 0,544 */
	reached3[282] = 1;
	trans[3][278]	= settr(319,2,279,2,0,"else", 1, 3, 504);
	trans[3][279]	= settr(320,2,544,119,119,"forwarded_certainty = retained_certainty", 1, 3, 504); /* m: 282 -> 0,544 */
	reached3[282] = 1;
	trans[3][282]	= settr(323,2,544,120,120,"assert(((!(local_withheld)||((forwarded_parent==1)&&(forwarded_actor==1)))||(forwarded_certainty==0)))", 1, 3, 504); /* m: 283 -> 0,544 */
	reached3[283] = 1;
	trans[3][283]	= settr(0,0,0,0,0,"pc = 13",0,0,0);
	trans[3][284]	= settr(325,2,326,121,121,"((pc==13))", 1, 3, 504); /* m: 285 -> 326,0 */
	reached3[285] = 1;
	trans[3][285]	= settr(0,0,0,0,0,"delivery_check = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))",0,0,0);
	trans[3][286]	= settr(0,0,0,0,0,"assert((!(delivery_check)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))",0,0,0);
	T = trans[3][326] = settr(367,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(367,2,287,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(367,2,295,0,0,"IF", 1, 3, 504);
	trans[3][287]	= settr(328,2,293,122,0,"(delivery_check)", 1, 3, 504);
	T = trans[3][293] = settr(334,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(334,2,288,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(334,2,290,0,0,"IF", 1, 3, 504);
	trans[3][288]	= settr(329,2,544,123,123,"(retained_withheld)", 1, 3, 504); /* m: 289 -> 544,0 */
	reached3[289] = 1;
	trans[3][289]	= settr(0,0,0,0,0,"pc = 14",0,0,0);
	trans[3][294]	= settr(335,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][290]	= settr(331,2,544,124,124,"(!(retained_withheld))", 1, 3, 504); /* m: 291 -> 544,0 */
	reached3[291] = 1;
	trans[3][291]	= settr(0,0,0,0,0,"inspection_precheck = delivery_check",0,0,0);
	trans[3][292]	= settr(0,0,0,0,0,"pc = 36",0,0,0);
	trans[3][327]	= settr(368,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][295]	= settr(336,2,325,125,125,"(!(delivery_check))", 1, 3, 504); /* m: 296 -> 325,0 */
	reached3[296] = 1;
	trans[3][296]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	T = trans[ 3][325] = settr(366,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(366,0,323,0,0,"sub-sequence", 1, 3, 504);
	T = trans[3][323] = settr(364,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(364,2,297,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(364,2,299,0,0,"IF", 1, 3, 504);
	trans[3][297]	= settr(338,2,544,126,126,"(replayed)", 1, 3, 504); /* m: 298 -> 544,0 */
	reached3[298] = 1;
	trans[3][298]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][324]	= settr(365,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][299]	= settr(340,2,322,127,0,"(!(replayed))", 1, 3, 504);
	T = trans[ 3][322] = settr(363,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(363,0,300,0,0,"sub-sequence", 1, 3, 504);
	trans[3][300]	= settr(341,2,303,128,128,"terminal = Running", 1, 3, 504);
	T = trans[3][303] = settr(344,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(344,2,301,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(344,2,302,0,0,"IF", 1, 3, 504);
	trans[3][301]	= settr(342,2,307,129,129,"attempt_tenant = 1", 1, 3, 504);
	trans[3][304]	= settr(345,2,307,1,0,".(goto)", 1, 3, 504);
	trans[3][302]	= settr(343,2,307,130,130,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][307] = settr(348,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(348,2,305,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(348,2,306,0,0,"IF", 1, 3, 504);
	trans[3][305]	= settr(346,2,318,131,131,"attempt_original = 1", 1, 3, 504);
	trans[3][308]	= settr(349,2,318,1,0,".(goto)", 1, 3, 504);
	trans[3][306]	= settr(347,2,318,132,132,"attempt_original = 2", 1, 3, 504);
	T = trans[3][318] = settr(359,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(359,2,309,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(359,2,310,0,0,"IF", 1, 3, 504);
	trans[3][309]	= settr(350,2,544,133,133,"(1)", 1, 3, 504); /* m: 320 -> 544,0 */
	reached3[320] = 1;
	trans[3][319]	= settr(360,2,320,1,0,".(goto)", 1, 3, 504); /* m: 320 -> 0,544 */
	reached3[320] = 1;
	trans[3][310]	= settr(351,2,316,134,134,"lease_epoch = credential_epoch", 1, 3, 504); /* m: 311 -> 0,316 */
	reached3[311] = 1;
	trans[3][311]	= settr(0,0,0,0,0,"session_grant_epoch = grant_epoch",0,0,0);
	T = trans[3][316] = settr(357,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(357,2,312,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(357,2,314,0,0,"IF", 1, 3, 504);
	trans[3][312]	= settr(353,2,544,135,135,"((grant_epoch==2))", 1, 3, 504); /* m: 313 -> 544,0 */
	reached3[313] = 1;
	trans[3][313]	= settr(0,0,0,0,0,"epoch_refreshed = 1",0,0,0);
	trans[3][317]	= settr(358,2,320,1,0,".(goto)", 1, 3, 504); /* m: 320 -> 0,544 */
	reached3[320] = 1;
	trans[3][314]	= settr(355,2,315,2,0,"else", 1, 3, 504);
	trans[3][315]	= settr(356,2,544,136,136,"(1)", 1, 3, 504); /* m: 320 -> 544,0 */
	reached3[320] = 1;
	trans[3][320]	= settr(361,2,544,137,137,"sealed_calls = calls", 1, 3, 504); /* m: 321 -> 0,544 */
	reached3[321] = 1;
	trans[3][321]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][328]	= settr(369,2,342,138,0,"((pc==36))", 1, 3, 504);
	T = trans[ 3][342] = settr(383,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(383,0,329,0,0,"sub-sequence", 1, 3, 504);
	trans[3][329]	= settr(370,2,338,139,139,"inspection_complete = 1", 1, 3, 504); /* m: 330 -> 0,338 */
	reached3[330] = 1;
	trans[3][330]	= settr(0,0,0,0,0,"inspection_exact = 1",0,0,0);
	trans[3][331]	= settr(0,0,0,0,0,"inspection_clean = 1",0,0,0);
	trans[3][332]	= settr(0,0,0,0,0,"inspection_original_positive = 0",0,0,0);
	T = trans[3][338] = settr(379,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(379,2,333,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(379,2,334,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(379,2,335,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(379,2,336,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(379,2,337,0,0,"IF", 1, 3, 504);
	trans[3][333]	= settr(374,2,544,140,140,"(1)", 1, 3, 504); /* m: 340 -> 544,0 */
	reached3[340] = 1;
	trans[3][339]	= settr(380,2,340,1,0,".(goto)", 1, 3, 504); /* m: 340 -> 0,544 */
	reached3[340] = 1;
	trans[3][334]	= settr(375,2,544,141,141,"inspection_original_positive = 1", 1, 3, 504); /* m: 340 -> 0,544 */
	reached3[340] = 1;
	trans[3][335]	= settr(376,2,544,142,142,"inspection_complete = 0", 1, 3, 504); /* m: 340 -> 0,544 */
	reached3[340] = 1;
	trans[3][336]	= settr(377,2,544,143,143,"inspection_exact = 0", 1, 3, 504); /* m: 340 -> 0,544 */
	reached3[340] = 1;
	trans[3][337]	= settr(378,2,544,144,144,"inspection_clean = 0", 1, 3, 504); /* m: 340 -> 0,544 */
	reached3[340] = 1;
	trans[3][340]	= settr(381,2,544,145,145,"inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)", 1, 3, 504); /* m: 341 -> 0,544 */
	reached3[341] = 1;
	trans[3][341]	= settr(0,0,0,0,0,"assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))",0,0,0);
	trans[3][343]	= settr(0,0,0,0,0,"pc = 37",0,0,0);
	trans[3][344]	= settr(385,2,347,146,0,"((pc==37))", 1, 3, 504);
	T = trans[ 3][347] = settr(388,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(388,0,345,0,0,"sub-sequence", 1, 3, 504);
	trans[3][345]	= settr(386,2,382,147,147,"inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))", 1, 3, 504); /* m: 346 -> 0,382 */
	reached3[346] = 1;
	trans[3][346]	= settr(0,0,0,0,0,"assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))",0,0,0);
	trans[3][348]	= settr(0,0,0,0,0,"delivery_check = (inspection_accepted&&inspection_postcheck)",0,0,0);
	T = trans[3][382] = settr(423,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(423,2,349,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(423,2,351,0,0,"IF", 1, 3, 504);
	trans[3][349]	= settr(390,2,544,148,148,"(delivery_check)", 1, 3, 504); /* m: 350 -> 544,0 */
	reached3[350] = 1;
	trans[3][350]	= settr(0,0,0,0,0,"pc = 14",0,0,0);
	trans[3][383]	= settr(424,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][351]	= settr(392,2,381,149,149,"(!(delivery_check))", 1, 3, 504); /* m: 352 -> 381,0 */
	reached3[352] = 1;
	trans[3][352]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	T = trans[ 3][381] = settr(422,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(422,0,379,0,0,"sub-sequence", 1, 3, 504);
	T = trans[3][379] = settr(420,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(420,2,353,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(420,2,355,0,0,"IF", 1, 3, 504);
	trans[3][353]	= settr(394,2,544,150,150,"(replayed)", 1, 3, 504); /* m: 354 -> 544,0 */
	reached3[354] = 1;
	trans[3][354]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][380]	= settr(421,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][355]	= settr(396,2,378,151,0,"(!(replayed))", 1, 3, 504);
	T = trans[ 3][378] = settr(419,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(419,0,356,0,0,"sub-sequence", 1, 3, 504);
	trans[3][356]	= settr(397,2,359,152,152,"terminal = Running", 1, 3, 504);
	T = trans[3][359] = settr(400,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(400,2,357,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(400,2,358,0,0,"IF", 1, 3, 504);
	trans[3][357]	= settr(398,2,363,153,153,"attempt_tenant = 1", 1, 3, 504);
	trans[3][360]	= settr(401,2,363,1,0,".(goto)", 1, 3, 504);
	trans[3][358]	= settr(399,2,363,154,154,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][363] = settr(404,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(404,2,361,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(404,2,362,0,0,"IF", 1, 3, 504);
	trans[3][361]	= settr(402,2,374,155,155,"attempt_original = 1", 1, 3, 504);
	trans[3][364]	= settr(405,2,374,1,0,".(goto)", 1, 3, 504);
	trans[3][362]	= settr(403,2,374,156,156,"attempt_original = 2", 1, 3, 504);
	T = trans[3][374] = settr(415,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(415,2,365,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(415,2,366,0,0,"IF", 1, 3, 504);
	trans[3][365]	= settr(406,2,544,157,157,"(1)", 1, 3, 504); /* m: 376 -> 544,0 */
	reached3[376] = 1;
	trans[3][375]	= settr(416,2,376,1,0,".(goto)", 1, 3, 504); /* m: 376 -> 0,544 */
	reached3[376] = 1;
	trans[3][366]	= settr(407,2,372,158,158,"lease_epoch = credential_epoch", 1, 3, 504); /* m: 367 -> 0,372 */
	reached3[367] = 1;
	trans[3][367]	= settr(0,0,0,0,0,"session_grant_epoch = grant_epoch",0,0,0);
	T = trans[3][372] = settr(413,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(413,2,368,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(413,2,370,0,0,"IF", 1, 3, 504);
	trans[3][368]	= settr(409,2,544,159,159,"((grant_epoch==2))", 1, 3, 504); /* m: 369 -> 544,0 */
	reached3[369] = 1;
	trans[3][369]	= settr(0,0,0,0,0,"epoch_refreshed = 1",0,0,0);
	trans[3][373]	= settr(414,2,376,1,0,".(goto)", 1, 3, 504); /* m: 376 -> 0,544 */
	reached3[376] = 1;
	trans[3][370]	= settr(411,2,371,2,0,"else", 1, 3, 504);
	trans[3][371]	= settr(412,2,544,160,160,"(1)", 1, 3, 504); /* m: 376 -> 544,0 */
	reached3[376] = 1;
	trans[3][376]	= settr(417,2,544,161,161,"sealed_calls = calls", 1, 3, 504); /* m: 377 -> 0,544 */
	reached3[377] = 1;
	trans[3][377]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][384]	= settr(425,2,416,162,162,"((pc==14))", 1, 3, 504); /* m: 385 -> 416,0 */
	reached3[385] = 1;
	trans[3][385]	= settr(0,0,0,0,0,"assert((delivery_check&&(attempt_tenant==1)))",0,0,0);
	trans[3][386]	= settr(0,0,0,0,0,"delivered_once = 1",0,0,0);
	trans[3][387]	= settr(0,0,0,0,0,"terminal = Delivered",0,0,0);
	T = trans[ 3][416] = settr(457,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(457,0,414,0,0,"sub-sequence", 1, 3, 504);
	T = trans[3][414] = settr(455,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(455,2,388,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(455,2,390,0,0,"IF", 1, 3, 504);
	trans[3][388]	= settr(429,2,544,163,163,"(replayed)", 1, 3, 504); /* m: 389 -> 544,0 */
	reached3[389] = 1;
	trans[3][389]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][415]	= settr(456,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][390]	= settr(431,2,413,164,0,"(!(replayed))", 1, 3, 504);
	T = trans[ 3][413] = settr(454,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(454,0,391,0,0,"sub-sequence", 1, 3, 504);
	trans[3][391]	= settr(432,2,394,165,165,"terminal = Running", 1, 3, 504);
	T = trans[3][394] = settr(435,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(435,2,392,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(435,2,393,0,0,"IF", 1, 3, 504);
	trans[3][392]	= settr(433,2,398,166,166,"attempt_tenant = 1", 1, 3, 504);
	trans[3][395]	= settr(436,2,398,1,0,".(goto)", 1, 3, 504);
	trans[3][393]	= settr(434,2,398,167,167,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][398] = settr(439,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(439,2,396,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(439,2,397,0,0,"IF", 1, 3, 504);
	trans[3][396]	= settr(437,2,409,168,168,"attempt_original = 1", 1, 3, 504);
	trans[3][399]	= settr(440,2,409,1,0,".(goto)", 1, 3, 504);
	trans[3][397]	= settr(438,2,409,169,169,"attempt_original = 2", 1, 3, 504);
	T = trans[3][409] = settr(450,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(450,2,400,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(450,2,401,0,0,"IF", 1, 3, 504);
	trans[3][400]	= settr(441,2,544,170,170,"(1)", 1, 3, 504); /* m: 411 -> 544,0 */
	reached3[411] = 1;
	trans[3][410]	= settr(451,2,411,1,0,".(goto)", 1, 3, 504); /* m: 411 -> 0,544 */
	reached3[411] = 1;
	trans[3][401]	= settr(442,2,407,171,171,"lease_epoch = credential_epoch", 1, 3, 504); /* m: 402 -> 0,407 */
	reached3[402] = 1;
	trans[3][402]	= settr(0,0,0,0,0,"session_grant_epoch = grant_epoch",0,0,0);
	T = trans[3][407] = settr(448,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(448,2,403,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(448,2,405,0,0,"IF", 1, 3, 504);
	trans[3][403]	= settr(444,2,544,172,172,"((grant_epoch==2))", 1, 3, 504); /* m: 404 -> 544,0 */
	reached3[404] = 1;
	trans[3][404]	= settr(0,0,0,0,0,"epoch_refreshed = 1",0,0,0);
	trans[3][408]	= settr(449,2,411,1,0,".(goto)", 1, 3, 504); /* m: 411 -> 0,544 */
	reached3[411] = 1;
	trans[3][405]	= settr(446,2,406,2,0,"else", 1, 3, 504);
	trans[3][406]	= settr(447,2,544,173,173,"(1)", 1, 3, 504); /* m: 411 -> 544,0 */
	reached3[411] = 1;
	trans[3][411]	= settr(452,2,544,174,174,"sealed_calls = calls", 1, 3, 504); /* m: 412 -> 0,544 */
	reached3[412] = 1;
	trans[3][412]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][417]	= settr(458,2,424,175,175,"((pc==30))", 1, 3, 504); /* m: 418 -> 424,0 */
	reached3[418] = 1;
	trans[3][418]	= settr(0,0,0,0,0,"inspection_precheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))",0,0,0);
	T = trans[3][424] = settr(465,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(465,2,419,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(465,2,421,0,0,"IF", 1, 3, 504);
	trans[3][419]	= settr(460,2,544,176,176,"(inspection_precheck)", 1, 3, 504); /* m: 420 -> 544,0 */
	reached3[420] = 1;
	trans[3][420]	= settr(0,0,0,0,0,"pc = 31",0,0,0);
	trans[3][425]	= settr(466,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][421]	= settr(462,2,544,177,177,"(!(inspection_precheck))", 1, 3, 504); /* m: 422 -> 544,0 */
	reached3[422] = 1;
	trans[3][422]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][423]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][426]	= settr(467,2,440,178,0,"((pc==31))", 1, 3, 504);
	T = trans[ 3][440] = settr(481,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(481,0,427,0,0,"sub-sequence", 1, 3, 504);
	trans[3][427]	= settr(468,2,436,179,179,"inspection_complete = 1", 1, 3, 504); /* m: 428 -> 0,436 */
	reached3[428] = 1;
	trans[3][428]	= settr(0,0,0,0,0,"inspection_exact = 1",0,0,0);
	trans[3][429]	= settr(0,0,0,0,0,"inspection_clean = 1",0,0,0);
	trans[3][430]	= settr(0,0,0,0,0,"inspection_original_positive = 0",0,0,0);
	T = trans[3][436] = settr(477,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(477,2,431,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(477,2,432,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(477,2,433,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(477,2,434,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(477,2,435,0,0,"IF", 1, 3, 504);
	trans[3][431]	= settr(472,2,544,180,180,"(1)", 1, 3, 504); /* m: 438 -> 544,0 */
	reached3[438] = 1;
	trans[3][437]	= settr(478,2,438,1,0,".(goto)", 1, 3, 504); /* m: 438 -> 0,544 */
	reached3[438] = 1;
	trans[3][432]	= settr(473,2,544,181,181,"inspection_original_positive = 1", 1, 3, 504); /* m: 438 -> 0,544 */
	reached3[438] = 1;
	trans[3][433]	= settr(474,2,544,182,182,"inspection_complete = 0", 1, 3, 504); /* m: 438 -> 0,544 */
	reached3[438] = 1;
	trans[3][434]	= settr(475,2,544,183,183,"inspection_exact = 0", 1, 3, 504); /* m: 438 -> 0,544 */
	reached3[438] = 1;
	trans[3][435]	= settr(476,2,544,184,184,"inspection_clean = 0", 1, 3, 504); /* m: 438 -> 0,544 */
	reached3[438] = 1;
	trans[3][438]	= settr(479,2,544,185,185,"inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)", 1, 3, 504); /* m: 439 -> 0,544 */
	reached3[439] = 1;
	trans[3][439]	= settr(0,0,0,0,0,"assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))",0,0,0);
	trans[3][441]	= settr(0,0,0,0,0,"pc = 32",0,0,0);
	trans[3][442]	= settr(483,2,445,186,0,"((pc==32))", 1, 3, 504);
	T = trans[ 3][445] = settr(486,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(486,0,443,0,0,"sub-sequence", 1, 3, 504);
	trans[3][443]	= settr(484,2,459,187,187,"inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))", 1, 3, 504); /* m: 444 -> 0,459 */
	reached3[444] = 1;
	trans[3][444]	= settr(0,0,0,0,0,"assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))",0,0,0);
	T = trans[3][459] = settr(500,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(500,2,446,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(500,2,455,0,0,"IF", 1, 3, 504);
	trans[3][446]	= settr(487,2,452,188,188,"((inspection_accepted&&inspection_postcheck))", 1, 3, 504); /* m: 447 -> 452,0 */
	reached3[447] = 1;
	trans[3][447]	= settr(0,0,0,0,0,"input_inspected = 1",0,0,0);
	T = trans[3][452] = settr(493,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(493,2,448,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(493,2,450,0,0,"IF", 1, 3, 504);
	trans[3][448]	= settr(489,2,544,189,189,"(inspection_original_positive)", 1, 3, 504); /* m: 449 -> 544,0 */
	reached3[449] = 1;
	trans[3][449]	= settr(0,0,0,0,0,"positive_original_projected = 1",0,0,0);
	trans[3][453]	= settr(494,2,454,1,0,".(goto)", 1, 3, 504); /* m: 454 -> 0,544 */
	reached3[454] = 1;
	trans[3][450]	= settr(491,2,451,2,0,"else", 1, 3, 504);
	trans[3][451]	= settr(492,2,544,190,190,"(1)", 1, 3, 504); /* m: 454 -> 544,0 */
	reached3[454] = 1;
	trans[3][454]	= settr(495,2,544,191,191,"pc = 1", 1, 3, 504);
	trans[3][460]	= settr(501,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][455]	= settr(496,2,544,192,192,"((!(inspection_accepted)||!(inspection_postcheck)))", 1, 3, 504); /* m: 456 -> 544,0 */
	reached3[456] = 1;
	trans[3][456]	= settr(0,0,0,0,0,"inspection_denied = 1",0,0,0);
	trans[3][457]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][458]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][461]	= settr(502,2,468,193,193,"((pc==40))", 1, 3, 504); /* m: 462 -> 468,0 */
	reached3[462] = 1;
	trans[3][462]	= settr(0,0,0,0,0,"inspection_precheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))",0,0,0);
	T = trans[3][468] = settr(509,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(509,2,463,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(509,2,465,0,0,"IF", 1, 3, 504);
	trans[3][463]	= settr(504,2,544,194,194,"(inspection_precheck)", 1, 3, 504); /* m: 464 -> 544,0 */
	reached3[464] = 1;
	trans[3][464]	= settr(0,0,0,0,0,"pc = 41",0,0,0);
	trans[3][469]	= settr(510,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][465]	= settr(506,2,544,195,195,"(!(inspection_precheck))", 1, 3, 504); /* m: 466 -> 544,0 */
	reached3[466] = 1;
	trans[3][466]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][467]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][470]	= settr(511,2,484,196,0,"((pc==41))", 1, 3, 504);
	T = trans[ 3][484] = settr(525,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(525,0,471,0,0,"sub-sequence", 1, 3, 504);
	trans[3][471]	= settr(512,2,480,197,197,"inspection_complete = 1", 1, 3, 504); /* m: 472 -> 0,480 */
	reached3[472] = 1;
	trans[3][472]	= settr(0,0,0,0,0,"inspection_exact = 1",0,0,0);
	trans[3][473]	= settr(0,0,0,0,0,"inspection_clean = 1",0,0,0);
	trans[3][474]	= settr(0,0,0,0,0,"inspection_original_positive = 0",0,0,0);
	T = trans[3][480] = settr(521,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(521,2,475,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(521,2,476,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(521,2,477,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(521,2,478,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(521,2,479,0,0,"IF", 1, 3, 504);
	trans[3][475]	= settr(516,2,544,198,198,"(1)", 1, 3, 504); /* m: 482 -> 544,0 */
	reached3[482] = 1;
	trans[3][481]	= settr(522,2,482,1,0,".(goto)", 1, 3, 504); /* m: 482 -> 0,544 */
	reached3[482] = 1;
	trans[3][476]	= settr(517,2,544,199,199,"inspection_original_positive = 1", 1, 3, 504); /* m: 482 -> 0,544 */
	reached3[482] = 1;
	trans[3][477]	= settr(518,2,544,200,200,"inspection_complete = 0", 1, 3, 504); /* m: 482 -> 0,544 */
	reached3[482] = 1;
	trans[3][478]	= settr(519,2,544,201,201,"inspection_exact = 0", 1, 3, 504); /* m: 482 -> 0,544 */
	reached3[482] = 1;
	trans[3][479]	= settr(520,2,544,202,202,"inspection_clean = 0", 1, 3, 504); /* m: 482 -> 0,544 */
	reached3[482] = 1;
	trans[3][482]	= settr(523,2,544,203,203,"inspection_accepted = ((inspection_complete&&inspection_exact)&&inspection_clean)", 1, 3, 504); /* m: 483 -> 0,544 */
	reached3[483] = 1;
	trans[3][483]	= settr(0,0,0,0,0,"assert((!(inspection_accepted)||((inspection_complete&&inspection_exact)&&inspection_clean)))",0,0,0);
	trans[3][485]	= settr(0,0,0,0,0,"pc = 42",0,0,0);
	trans[3][486]	= settr(527,2,489,204,0,"((pc==42))", 1, 3, 504);
	T = trans[ 3][489] = settr(530,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(530,0,487,0,0,"sub-sequence", 1, 3, 504);
	trans[3][487]	= settr(528,2,497,205,205,"inspection_postcheck = (((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))", 1, 3, 504); /* m: 488 -> 0,497 */
	reached3[488] = 1;
	trans[3][488]	= settr(0,0,0,0,0,"assert((!(inspection_postcheck)||(((((authority_available&&grant_active)&&(grant_epoch==session_grant_epoch))&&(policy_epoch==1))&&(key_epoch==1))&&(lease_epoch==credential_epoch))))",0,0,0);
	T = trans[3][497] = settr(538,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(538,2,490,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(538,2,493,0,0,"IF", 1, 3, 504);
	trans[3][490]	= settr(531,2,544,206,206,"((inspection_accepted&&inspection_postcheck))", 1, 3, 504); /* m: 491 -> 544,0 */
	reached3[491] = 1;
	trans[3][491]	= settr(0,0,0,0,0,"outbound_inspected = 1",0,0,0);
	trans[3][492]	= settr(0,0,0,0,0,"pc = 4",0,0,0);
	trans[3][498]	= settr(539,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][493]	= settr(534,2,544,207,207,"((!(inspection_accepted)||!(inspection_postcheck)))", 1, 3, 504); /* m: 494 -> 544,0 */
	reached3[494] = 1;
	trans[3][494]	= settr(0,0,0,0,0,"inspection_denied = 1",0,0,0);
	trans[3][495]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][496]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][499]	= settr(540,2,513,208,0,"((pc==20))", 1, 3, 504);
	T = trans[3][513] = settr(554,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(554,2,500,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(554,2,504,0,0,"IF", 1, 3, 504);
	trans[3][500]	= settr(541,2,544,209,209,"((attempt_tenant!=1))", 1, 3, 504); /* m: 501 -> 544,0 */
	reached3[501] = 1;
	trans[3][501]	= settr(0,0,0,0,0,"foreign_denied = 1",0,0,0);
	trans[3][502]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][503]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][514]	= settr(555,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][504]	= settr(545,2,511,210,0,"((attempt_tenant==1))", 1, 3, 504);
	T = trans[3][511] = settr(552,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(552,2,505,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(552,2,509,0,0,"IF", 1, 3, 504);
	trans[3][505]	= settr(546,2,544,211,211,"((attempt_original!=bound_original))", 1, 3, 504); /* m: 506 -> 544,0 */
	reached3[506] = 1;
	trans[3][506]	= settr(0,0,0,0,0,"input_conflict = 1",0,0,0);
	trans[3][507]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][508]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][512]	= settr(553,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][509]	= settr(550,2,544,212,212,"((attempt_original==bound_original))", 1, 3, 504); /* m: 510 -> 544,0 */
	reached3[510] = 1;
	trans[3][510]	= settr(0,0,0,0,0,"pc = 21",0,0,0);
	trans[3][515]	= settr(556,2,527,213,0,"((pc==21))", 1, 3, 504);
	T = trans[3][527] = settr(568,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(568,2,516,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(568,2,521,0,0,"IF", 1, 3, 504);
	trans[3][516]	= settr(557,2,544,214,214,"((effect_state==Unknown))", 1, 3, 504); /* m: 517 -> 544,0 */
	reached3[517] = 1;
	trans[3][517]	= settr(0,0,0,0,0,"assert((calls==sealed_calls))",0,0,0);
	trans[3][518]	= settr(0,0,0,0,0,"unknown_retry_blocked = 1",0,0,0);
	trans[3][519]	= settr(0,0,0,0,0,"terminal = Blocked",0,0,0);
	trans[3][520]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][528]	= settr(569,2,544,1,0,".(goto)", 1, 3, 504);
	trans[3][521]	= settr(562,2,544,215,215,"((effect_state==Completed))", 1, 3, 504); /* m: 522 -> 544,0 */
	reached3[522] = 1;
	trans[3][522]	= settr(0,0,0,0,0,"assert((effect_state==Completed))",0,0,0);
	trans[3][523]	= settr(0,0,0,0,0,"replayed = 1",0,0,0);
	trans[3][524]	= settr(0,0,0,0,0,"protocol_output = journal_output",0,0,0);
	trans[3][525]	= settr(0,0,0,0,0,"protocol_completed = 1",0,0,0);
	trans[3][526]	= settr(0,0,0,0,0,"pc = 13",0,0,0);
	T = trans[ 3][544] = settr(585,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(585,0,533,0,0,"sub-sequence", 1, 3, 504);
	trans[3][533]	= settr(574,0,546,216,216,"assert((calls<=1))", 1, 3, 504); /* m: 534 -> 0,546 */
	reached3[534] = 1;
	trans[3][534]	= settr(0,0,0,0,0,"assert(((journal_input!=Raw)&&(protocol_input!=Raw)))",0,0,0);
	trans[3][535]	= settr(0,0,0,0,0,"assert((((journal_output!=Raw)&&(protocol_output!=Raw))&&(receipt_payload!=Raw)))",0,0,0);
	trans[3][536]	= settr(0,0,0,0,0,"assert(((bound_original==0)||(bound_original==1)))",0,0,0);
	trans[3][537]	= settr(0,0,0,0,0,"assert((receipt==(effect_state==Completed)))",0,0,0);
	trans[3][538]	= settr(0,0,0,0,0,"assert((!(receipt)||(retained_certainty==sealed_certainty)))",0,0,0);
	trans[3][539]	= settr(0,0,0,0,0,"assert((!(receipt)||(retained_withheld==sealed_withheld)))",0,0,0);
	trans[3][540]	= settr(0,0,0,0,0,"assert((!(receipt)||(retained_certainty==observed_certainty)))",0,0,0);
	trans[3][541]	= settr(0,0,0,0,0,"assert((!(protocol_completed)||(receipt&&(protocol_output==journal_output))))",0,0,0);
	trans[3][542]	= settr(0,0,0,0,0,"assert((!(replayed)||(calls==sealed_calls)))",0,0,0);
	trans[3][543]	= settr(0,0,0,0,0,"assert(((terminal!=Delivered)||(delivery_check&&(attempt_tenant==1))))",0,0,0);
	trans[3][548]	= settr(589,0,549,1,0,"break", 0, 2, 0);
	trans[3][549]	= settr(590,0,550,217,0,"assert(!(input_conflict))", 1, 2, 0);
	trans[3][550]	= settr(591,0,0,218,218,"-end-", 0, 3500, 0);

	/* proctype 2: External */

	trans[2] = (Trans **) emalloc(20*sizeof(Trans *));

	T = trans[2][17] = settr(39,0,0,0,0,"IF", 0, 2, 0);
	T = T->nxt	= settr(39,0,1,0,0,"IF", 0, 2, 0);
	    T->nxt	= settr(39,0,15,0,0,"IF", 0, 2, 0);
	trans[2][1]	= settr(23,0,14,219,219,"requests?request_id", 1, 503, 0);
	T = trans[ 2][14] = settr(36,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(36,2,5,0,0,"ATOMIC", 1, 4, 0);
	T = trans[2][5] = settr(27,2,0,0,0,"IF", 1, 4, 0);
	T = T->nxt	= settr(27,2,2,0,0,"IF", 1, 4, 0);
	T = T->nxt	= settr(27,2,3,0,0,"IF", 1, 4, 0);
	    T->nxt	= settr(27,2,4,0,0,"IF", 1, 4, 0);
	trans[2][2]	= settr(24,2,11,220,220,"output = Safe", 1, 4, 0);
	trans[2][6]	= settr(28,2,11,1,0,".(goto)", 1, 4, 0);
	trans[2][3]	= settr(25,2,11,221,221,"output = Raw", 1, 4, 0);
	trans[2][4]	= settr(26,2,11,222,222,"output = TransportLost", 1, 4, 0);
	T = trans[2][11] = settr(33,2,0,0,0,"IF", 1, 4, 0);
	T = T->nxt	= settr(33,2,7,0,0,"IF", 1, 4, 0);
	T = T->nxt	= settr(33,2,8,0,0,"IF", 1, 4, 0);
	T = T->nxt	= settr(33,2,9,0,0,"IF", 1, 4, 0);
	    T->nxt	= settr(33,2,10,0,0,"IF", 1, 4, 0);
	trans[2][7]	= settr(29,2,13,223,223,"certainty = 0", 1, 4, 0); /* m: 12 -> 0,13 */
	reached2[12] = 1;
	trans[2][12]	= settr(34,2,13,224,224,".(goto)", 1, 4, 0);
	trans[2][8]	= settr(30,2,13,225,225,"certainty = 1", 1, 4, 0); /* m: 12 -> 0,13 */
	reached2[12] = 1;
	trans[2][9]	= settr(31,2,13,226,226,"certainty = 2", 1, 4, 0); /* m: 12 -> 0,13 */
	reached2[12] = 1;
	trans[2][10]	= settr(32,2,13,227,227,"certainty = 3", 1, 4, 0); /* m: 12 -> 0,13 */
	reached2[12] = 1;
	trans[2][13]	= settr(35,0,19,228,228,"results!output,certainty", 1, 4, 0);
	trans[2][18]	= settr(40,0,19,1,0,".(goto)", 0, 2, 0);
	trans[2][15]	= settr(37,0,16,229,0,"(finished)", 1, 2, 0);
	trans[2][16]	= settr(38,0,19,1,0,"(1)", 0, 2, 0);
	trans[2][19]	= settr(41,0,0,230,230,"-end-", 0, 3500, 0);

	/* proctype 1: Crash */

	trans[1] = (Trans **) emalloc(9*sizeof(Trans *));

	T = trans[1][6] = settr(20,0,0,0,0,"IF", 0, 2, 0);
	T = T->nxt	= settr(20,0,1,0,0,"IF", 0, 2, 0);
	    T->nxt	= settr(20,0,5,0,0,"IF", 0, 2, 0);
	trans[1][1]	= settr(15,0,8,1,0,"(1)", 0, 2, 0);
	trans[1][7]	= settr(21,0,8,1,0,".(goto)", 0, 2, 0);
	T = trans[ 1][5] = settr(19,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(19,2,2,0,0,"ATOMIC", 1, 2, 0);
	trans[1][2]	= settr(16,0,8,231,231,"(!(finished))", 1, 2, 0); /* m: 3 -> 8,0 */
	reached1[3] = 1;
	trans[1][3]	= settr(0,0,0,0,0,"crash = 1",0,0,0);
	trans[1][4]	= settr(0,0,0,0,0,"crashed_once = 1",0,0,0);
	trans[1][8]	= settr(22,0,0,232,232,"-end-", 0, 3500, 0);

	/* proctype 0: Authority */

	trans[0] = (Trans **) emalloc(16*sizeof(Trans *));

	T = trans[0][13] = settr(12,0,0,0,0,"IF", 0, 2, 0);
	T = T->nxt	= settr(12,0,1,0,0,"IF", 0, 2, 0);
	    T->nxt	= settr(12,0,12,0,0,"IF", 0, 2, 0);
	trans[0][1]	= settr(0,0,15,1,0,"(1)", 0, 2, 0);
	trans[0][14]	= settr(13,0,15,1,0,".(goto)", 0, 2, 0);
	T = trans[ 0][12] = settr(11,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(11,2,2,0,0,"ATOMIC", 1, 2, 0);
	trans[0][2]	= settr(1,2,9,233,0,"(!(finished))", 1, 2, 0);
	T = trans[0][9] = settr(8,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(8,2,3,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(8,2,4,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(8,2,5,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(8,2,6,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(8,2,7,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(8,2,8,0,0,"IF", 1, 2, 0);
	trans[0][3]	= settr(2,0,15,234,234,"grant_active = 0", 1, 2, 0); /* m: 10 -> 0,15 */
	reached0[10] = 1;
	trans[0][10]	= settr(9,0,15,235,235,".(goto)", 1, 2, 0); /* m: 11 -> 0,15 */
	reached0[11] = 1;
	trans[0][4]	= settr(3,0,15,236,236,"authority_available = 0", 1, 2, 0); /* m: 10 -> 0,15 */
	reached0[10] = 1;
	trans[0][5]	= settr(4,0,15,237,237,"grant_epoch = 2", 1, 2, 0); /* m: 10 -> 0,15 */
	reached0[10] = 1;
	trans[0][6]	= settr(5,0,15,238,238,"policy_epoch = 2", 1, 2, 0); /* m: 10 -> 0,15 */
	reached0[10] = 1;
	trans[0][7]	= settr(6,0,15,239,239,"key_epoch = 2", 1, 2, 0); /* m: 10 -> 0,15 */
	reached0[10] = 1;
	trans[0][8]	= settr(7,0,15,240,240,"credential_epoch = 2", 1, 2, 0); /* m: 10 -> 0,15 */
	reached0[10] = 1;
	trans[0][11]	= settr(0,0,0,0,0,"authority_changed = 1",0,0,0);
	trans[0][15]	= settr(14,0,0,241,241,"-end-", 0, 3500, 0);
	/* np_ demon: */
	trans[_NP_] = (Trans **) emalloc(3*sizeof(Trans *));
	T = trans[_NP_][0] = settr(9997,0,1,_T5,0,"(np_)", 1,2,0);
	    T->nxt	  = settr(9998,0,0,_T2,0,"(1)",   0,2,0);
	T = trans[_NP_][1] = settr(9999,0,1,_T5,0,"(np_)", 1,2,0);
}

Trans *
settr(	int t_id, int a, int b, int c, int d,
	char *t, int g, int tpe0, int tpe1)
{	Trans *tmp = (Trans *) emalloc(sizeof(Trans));

	tmp->atom  = a&(6|32);	/* only (2|8|32) have meaning */
	if (!g) tmp->atom |= 8;	/* no global references */
	tmp->st    = b;
	tmp->tpe[0] = tpe0;
	tmp->tpe[1] = tpe1;
	tmp->tp    = t;
	tmp->t_id  = t_id;
	tmp->forw  = c;
	tmp->back  = d;
	return tmp;
}

Trans *
cpytr(Trans *a)
{	Trans *tmp = (Trans *) emalloc(sizeof(Trans));

	int i;
	tmp->atom  = a->atom;
	tmp->st    = a->st;
#ifdef HAS_UNLESS
	tmp->e_trans = a->e_trans;
	for (i = 0; i < HAS_UNLESS; i++)
		tmp->escp[i] = a->escp[i];
#endif
	tmp->tpe[0] = a->tpe[0];
	tmp->tpe[1] = a->tpe[1];
	for (i = 0; i < 6; i++)
	{	tmp->qu[i] = a->qu[i];
		tmp->ty[i] = a->ty[i];
	}
	tmp->tp    = (char *) emalloc(strlen(a->tp)+1);
	strcpy(tmp->tp, a->tp);
	tmp->t_id  = a->t_id;
	tmp->forw  = a->forw;
	tmp->back  = a->back;
	return tmp;
}

#ifndef NOREDUCE
int
srinc_set(int n)
{	if (n <= 2) return LOCAL;
	if (n <= 2+  DELTA) return Q_FULL_F; /* 's' or nfull  */
	if (n <= 2+2*DELTA) return Q_EMPT_F; /* 'r' or nempty */
	if (n <= 2+3*DELTA) return Q_EMPT_T; /* empty */
	if (n <= 2+4*DELTA) return Q_FULL_T; /* full  */
	if (n ==   5*DELTA) return GLOBAL;
	if (n ==   6*DELTA) return TIMEOUT_F;
	if (n ==   7*DELTA) return ALPHA_F;
	Uerror("cannot happen srinc_class");
	return BAD;
}
int
srunc(int n, int m)
{	switch(m) {
	case Q_FULL_F: return n-2;
	case Q_EMPT_F: return n-2-DELTA;
	case Q_EMPT_T: return n-2-2*DELTA;
	case Q_FULL_T: return n-2-3*DELTA;
	case ALPHA_F:
	case TIMEOUT_F: return 257; /* non-zero, and > MAXQ */
	}
	Uerror("cannot happen srunc");
	return 0;
}
#endif
int cnt;
#ifdef HAS_UNLESS
int
isthere(Trans *a, int b)
{	Trans *t;
	for (t = a; t; t = t->nxt)
		if (t->t_id == b)
			return 1;
	return 0;
}
#endif
#ifndef NOREDUCE
int
mark_safety(Trans *t) /* for conditional safety */
{	int g = 0, i, j, k;

	if (!t) return 0;
	if (t->qu[0])
		return (t->qu[1])?2:1;	/* marked */

	for (i = 0; i < 2; i++)
	{	j = srinc_set(t->tpe[i]);
		if (j >= GLOBAL && j != ALPHA_F)
			return -1;
		if (j != LOCAL)
		{	k = srunc(t->tpe[i], j);
			if (g == 0
			||  t->qu[0] != k
			||  t->ty[0] != j)
			{	t->qu[g] = k;
				t->ty[g] = j;
				g++;
	}	}	}
	return g;
}
#endif
void
retrans(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
	/* process n, with m states, is=initial state */
{	Trans *T0, *T1, *T2, *T3;
	Trans *T4, *T5; /* t_reverse or has_unless */
	int i;
#if defined(HAS_UNLESS) || !defined(NOREDUCE)
	int k;
#endif
#ifndef NOREDUCE
	int g, h, j, aa;
#endif
#ifdef HAS_UNLESS
	int p;
#endif
	if (state_tables >= 4)
	{	printf("STEP 1 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
	do {
		for (i = 1, cnt = 0; i < m; i++)
		{	T2 = trans[n][i];
			T1 = T2?T2->nxt:(Trans *)0;
/* prescan: */		for (T0 = T1; T0; T0 = T0->nxt)
/* choice in choice */	{	if (T0->st && trans[n][T0->st]
				&&  trans[n][T0->st]->nxt)
					break;
			}
#if 0
		if (T0)
		printf("\tstate %d / %d: choice in choice\n",
		i, T0->st);
#endif
			if (T0)
			for (T0 = T1; T0; T0 = T0->nxt)
			{	T3 = trans[n][T0->st];
				if (!T3->nxt)
				{	T2->nxt = cpytr(T0);
					T2 = T2->nxt;
					imed(T2, T0->st, n, i);
					continue;
				}
				do {	T3 = T3->nxt;
					T2->nxt = cpytr(T3);
					T2 = T2->nxt;
					imed(T2, T0->st, n, i);
				} while (T3->nxt);
				cnt++;
			}
		}
	} while (cnt);
	if (state_tables >= 3)
	{	printf("STEP 2 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
	for (i = 1; i < m; i++)
	{	if (trans[n][i] && trans[n][i]->nxt) /* optimize */
		{	T1 = trans[n][i]->nxt;
#if 0
			printf("\t\tpull %d (%d) to %d\n",
			T1->st, T1->forw, i);
#endif
			srcln[i] = srcln[T1->st];	/* Oyvind Teig, 5.2.0 */

			if (!trans[n][T1->st]) continue;
			T0 = cpytr(trans[n][T1->st]);
			trans[n][i] = T0;
			reach[T1->st] = 1;
			imed(T0, T1->st, n, i);
			for (T1 = T1->nxt; T1; T1 = T1->nxt)
			{
#if 0
			printf("\t\tpull %d (%d) to %d\n",
				T1->st, T1->forw, i);
#endif
		/*		srcln[i] = srcln[T1->st];  gh: not useful */
				if (!trans[n][T1->st]) continue;
				T0->nxt = cpytr(trans[n][T1->st]);
				T0 = T0->nxt;
				reach[T1->st] = 1;
				imed(T0, T1->st, n, i);
	}	}	}
	if (state_tables >= 2)
	{	printf("STEP 3 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
#ifdef HAS_UNLESS
	for (i = 1; i < m; i++)
	{	if (!trans[n][i]) continue;
		/* check for each state i if an
		 * escape to some state p is defined
		 * if so, copy and mark p's transitions
		 * and prepend them to the transition-
		 * list of state i
		 */
	 if (!like_java) /* the default */
	 {	for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		for (k = HAS_UNLESS-1; k >= 0; k--)
		{	if (p = T0->escp[k])
			for (T1 = trans[n][p]; T1; T1 = T1->nxt)
			{	if (isthere(trans[n][i], T1->t_id))
					continue;
				T2 = cpytr(T1);
				T2->e_trans = p;
				T2->nxt = trans[n][i];
				trans[n][i] = T2;
		}	}
	 } else /* outermost unless checked first */
	 {	T4 = T3 = (Trans *) 0;
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		for (k = HAS_UNLESS-1; k >= 0; k--)
		{	if (p = T0->escp[k])
			for (T1 = trans[n][p]; T1; T1 = T1->nxt)
			{	if (isthere(trans[n][i], T1->t_id))
					continue;
				T2 = cpytr(T1);
				T2->nxt = (Trans *) 0;
				T2->e_trans = p;
				if (T3)	T3->nxt = T2;
				else	T4 = T2;
				T3 = T2;
		}	}
		if (T4)
		{	T3->nxt = trans[n][i];
			trans[n][i] = T4;
		}
	 }
	}
#endif
#ifndef NOREDUCE
	for (i = 1; i < m; i++)
	{	if (a_cycles)
		{ /* moves through these states are visible */
	#if PROG_LAB>0 && defined(HAS_NP)
			if (progstate[n][i])
				goto degrade;
			for (T1 = trans[n][i]; T1; T1 = T1->nxt)
				if (progstate[n][T1->st])
					goto degrade;
	#endif
			if (accpstate[n][i] || visstate[n][i])
				goto degrade;
			for (T1 = trans[n][i]; T1; T1 = T1->nxt)
				if (accpstate[n][T1->st])
					goto degrade;
		}
		T1 = trans[n][i];
		if (!T1) continue;
		g = mark_safety(T1);	/* V3.3.1 */
		if (g < 0) goto degrade; /* global */
		/* check if mixing of guards preserves reduction */
		if (T1->nxt)
		{	k = 0;
			for (T0 = T1; T0; T0 = T0->nxt)
			{	if (!(T0->atom&8))
					goto degrade;
				for (aa = 0; aa < 2; aa++)
				{	j = srinc_set(T0->tpe[aa]);
					if (j >= GLOBAL && j != ALPHA_F)
						goto degrade;
					if (T0->tpe[aa]
					&&  T0->tpe[aa]
					!=  T1->tpe[0])
						k = 1;
			}	}
			/* g = 0;	V3.3.1 */
			if (k)	/* non-uniform selection */
			for (T0 = T1; T0; T0 = T0->nxt)
			for (aa = 0; aa < 2; aa++)
			{	j = srinc_set(T0->tpe[aa]);
				if (j != LOCAL)
				{	k = srunc(T0->tpe[aa], j);
					for (h = 0; h < 6; h++)
						if (T1->qu[h] == k
						&&  T1->ty[h] == j)
							break;
					if (h >= 6)
					{	T1->qu[g%6] = k;
						T1->ty[g%6] = j;
						g++;
			}	}	}
			if (g > 6)
			{	T1->qu[0] = 0;	/* turn it off */
				printf("pan: warning, line %d, ",
					srcln[i]);
			 	printf("too many stmnt types (%d)",
					g);
			  	printf(" in selection\n");
			  goto degrade;
			}
		}
		/* mark all options global if >=1 is global */
		for (T1 = trans[n][i]; T1; T1 = T1->nxt)
			if (!(T1->atom&8)) break;
		if (T1)
degrade:	for (T1 = trans[n][i]; T1; T1 = T1->nxt)
			T1->atom &= ~8;	/* mark as unsafe */
		/* can only mix 'r's or 's's if on same chan */
		/* and not mixed with other local operations */
		T1 = trans[n][i];
		if (!T1 || T1->qu[0]) continue;
		j = T1->tpe[0];
		if (T1->nxt && T1->atom&8)
		{ if (j == 5*DELTA)
		  {	printf("warning: line %d ", srcln[i]);
			printf("mixed condition ");
			printf("(defeats reduction)\n");
			goto degrade;
		  }
		  for (T0 = T1; T0; T0 = T0->nxt)
		  for (aa = 0; aa < 2; aa++)
		  if  (T0->tpe[aa] && T0->tpe[aa] != j)
		  {	printf("warning: line %d ", srcln[i]);
			printf("[%d-%d] mixed %stion ",
				T0->tpe[aa], j, 
				(j==5*DELTA)?"condi":"selec");
			printf("(defeats reduction)\n");
			printf("	'%s' <-> '%s'\n",
				T1->tp, T0->tp);
			goto degrade;
		} }
	}
#endif
	for (i = 1; i < m; i++)
	{	T2 = trans[n][i];
		if (!T2
		||  T2->nxt
		||  strncmp(T2->tp, ".(goto)", 7)
		||  !stopstate[n][i])
			continue;
		stopstate[n][T2->st] = 1;
	}
	if (state_tables && !verbose)
	{	if (dodot)
		{	char buf[256], *q = buf, *p = procname[n];
			while (*p != '\0')
			{	if (*p != ':')
				{	*q++ = *p;
				}
				p++;
			}
			*q = '\0';
			printf("digraph ");
			switch (Btypes[n]) {
			case I_PROC:  printf("init {\n"); break;
			case N_CLAIM: printf("claim_%s {\n", buf); break;
			case E_TRACE: printf("notrace {\n"); break;
			case N_TRACE: printf("trace {\n"); break;
			default:      printf("p_%s {\n", buf); break;
			}
			printf("size=\"8,10\";\n");
			printf("  GT [shape=box,style=dotted,label=\"%s\"];\n", buf);
			printf("  GT -> S%d;\n", is);
		} else
		{	switch (Btypes[n]) {
			case I_PROC:  printf("init\n"); break;
			case N_CLAIM: printf("claim %s\n", procname[n]); break;
			case E_TRACE: printf("notrace assertion\n"); break;
			case N_TRACE: printf("trace assertion\n"); break;
			default:      printf("proctype %s\n", procname[n]); break;
		}	}
		for (i = 1; i < m; i++)
		{	reach[i] = 1;
		}
		tagtable(n, m, is, srcln, reach);
		if (dodot) printf("}\n");
	} else
	for (i = 1; i < m; i++)
	{	int nrelse;
		if (Btypes[n] != N_CLAIM)
		{	for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			{	if (T0->st == i
				&& strcmp(T0->tp, "(1)") == 0)
				{	printf("error: proctype '%s' ",
						procname[n]);
		  			printf("line %d, state %d: has un",
						srcln[i], i);
					printf("conditional self-loop\n");
					pan_exit(1);
		}	}	}
		nrelse = 0;
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		{	if (strcmp(T0->tp, "else") == 0)
				nrelse++;
		}
		if (nrelse > 1)
		{	printf("error: proctype '%s' state",
				procname[n]);
		  	printf(" %d, inherits %d", i, nrelse);
		  	printf(" 'else' stmnts\n");
			pan_exit(1);
	}	}
#if !defined(LOOPSTATE) && !defined(BFS_PAR)
	if (state_tables)
#endif
	do_dfs(n, m, is, srcln, reach, lpstate);

	if (!t_reverse)
	{	return;
	}
	/* process n, with m states, is=initial state -- reverse list */
	if (!state_tables && Btypes[n] != N_CLAIM)
	{	for (i = 1; i < m; i++)
		{	Trans *Tx = (Trans *) 0; /* list of escapes */
			Trans *Ty = (Trans *) 0; /* its tail element */
			T1 = (Trans *) 0; /* reversed list */
			T2 = (Trans *) 0; /* its tail */
			T3 = (Trans *) 0; /* remembers possible 'else' */

			/* find unless-escapes, they should go first */
			T4 = T5 = T0 = trans[n][i];
	#ifdef HAS_UNLESS
			while (T4 && T4->e_trans) /* escapes are first in orig list */
			{	T5 = T4;	  /* remember predecessor */
				T4 = T4->nxt;
			}
	#endif
			/* T4 points to first non-escape, T5 to its parent, T0 to original list */
			if (T4 != T0)		 /* there was at least one escape */
			{	T3 = T5->nxt;		 /* start of non-escapes */
				T5->nxt = (Trans *) 0;	 /* separate */
				Tx = T0;		 /* start of the escapes */
				Ty = T5;		 /* its tail */
				T0 = T3;		 /* the rest, to be reversed */
			}
			/* T0 points to first non-escape, Tx to the list of escapes, Ty to its tail */

			/* first tail-add non-escape transitions, reversed */
			T3 = (Trans *) 0;
			for (T5 = T0; T5; T5 = T4)
			{	T4 = T5->nxt;
	#ifdef HAS_UNLESS
				if (T5->e_trans)
				{	printf("error: cannot happen!\n");
					continue;
				}
	#endif
				if (strcmp(T5->tp, "else") == 0)
				{	T3 = T5;
					T5->nxt = (Trans *) 0;
				} else
				{	T5->nxt = T1;
					if (!T1) { T2 = T5; }
					T1 = T5;
			}	}
			/* T3 points to a possible else, which is removed from the list */
			/* T1 points to the reversed list so far (without escapes) */
			/* T2 points to the tail element -- where the else should go */
			if (T2 && T3)
			{	T2->nxt = T3;	/* add else */
			} else
			{	if (T3) /* there was an else, but there's no tail */
				{	if (!T1)	/* and no reversed list */
					{	T1 = T3; /* odd, but possible */
					} else		/* even stranger */
					{	T1->nxt = T3;
			}	}	}

			/* add in the escapes, to that they appear at the front */
			if (Tx && Ty) { Ty->nxt = T1; T1 = Tx; }

			trans[n][i] = T1;
			/* reversed, with escapes first and else last */
	}	}
	if (state_tables && verbose)
	{	printf("FINAL proctype %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
	}
}
void
imed(Trans *T, int v, int n, int j)	/* set intermediate state */
{	progstate[n][T->st] |= progstate[n][v];
	accpstate[n][T->st] |= accpstate[n][v];
	stopstate[n][T->st] |= stopstate[n][v];
	mapstate[n][j] = T->st;
}
void
tagtable(int n, int m, int is, short srcln[], uchar reach[])
{	Trans *z;

	if (is >= m || !trans[n][is]
	||  is <= 0 || reach[is] == 0)
		return;
	reach[is] = 0;
	if (state_tables)
	for (z = trans[n][is]; z; z = z->nxt)
	{	if (dodot)
			dot_crack(n, is, z);
		else
			crack(n, is, z, srcln);
	}

	for (z = trans[n][is]; z; z = z->nxt)
	{
#ifdef HAS_UNLESS
		int i, j;
#endif
		tagtable(n, m, z->st, srcln, reach);
#ifdef HAS_UNLESS
		for (i = 0; i < HAS_UNLESS; i++)
		{	j = trans[n][is]->escp[i];
			if (!j) break;
			tagtable(n, m, j, srcln, reach);
		}
#endif
	}
}

extern Trans *t_id_lkup[];

void
dfs_table(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
{	Trans *z;

	if (is >= m || is <= 0 || !trans[n][is])
		return;
	if ((reach[is] & (4|8|16)) != 0)
	{	if ((reach[is] & (8|16)) == 16)	/* on stack, not yet recorded */
		{	lpstate[is] = 1;
			reach[is] |= 8; /* recorded */
			if (state_tables && verbose)
			{	printf("state %d line %d is a loopstate\n", is, srcln[is]);
		}	}
		return;
	}
	reach[is] |= (4|16);	/* visited | onstack */
	for (z = trans[n][is]; z; z = z->nxt)
	{	t_id_lkup[z->t_id] = z;
#ifdef HAS_UNLESS
		int i, j;
#endif
		dfs_table(n, m, z->st, srcln, reach, lpstate);
#ifdef HAS_UNLESS
		for (i = 0; i < HAS_UNLESS; i++)
		{	j = trans[n][is]->escp[i];
			if (!j) break;
			dfs_table(n, m, j, srcln, reach, lpstate);
		}
#endif
	}
	reach[is] &= ~16; /* no longer on stack */
}
void
do_dfs(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
{	int i;
	dfs_table(n, m, is, srcln, reach, lpstate);
	for (i = 0; i < m; i++)
		reach[i] &= ~(4|8|16);
}
void
crack(int n, int j, Trans *z, short srcln[])
{	int i;

	if (!z) return;
	printf("	state %3d -(tr %3d)-> state %3d  ",
		j, z->forw, z->st);
	printf("[id %3d tp %3d", z->t_id, z->tpe[0]);
	if (z->tpe[1]) printf(",%d", z->tpe[1]);
#ifdef HAS_UNLESS
	if (z->e_trans)
		printf(" org %3d", z->e_trans);
	else if (state_tables >= 2)
	for (i = 0; i < HAS_UNLESS; i++)
	{	if (!z->escp[i]) break;
		printf(" esc %d", z->escp[i]);
	}
#endif
	printf("]");
	printf(" [%s%s%s%s%s] %s:%d => ",
		z->atom&6?"A":z->atom&32?"D":"-",
		accpstate[n][j]?"a" :"-",
		stopstate[n][j]?"e" : "-",
		progstate[n][j]?"p" : "-",
		z->atom & 8 ?"L":"G",
		PanSource, srcln[j]);
	for (i = 0; z->tp[i]; i++)
		if (z->tp[i] == '\n')
			printf("\\n");
		else
			putchar(z->tp[i]);
	if (verbose && z->qu[0])
	{	printf("\t[");
		for (i = 0; i < 6; i++)
			if (z->qu[i])
				printf("(%d,%d)",
				z->qu[i], z->ty[i]);
		printf("]");
	}
	printf("\n");
	fflush(stdout);
}
/* spin -a m.pml; cc -o pan pan.c; ./pan -D | dot -Tps > foo.ps; ps2pdf foo.ps */
void
dot_crack(int n, int j, Trans *z)
{	int i;

	if (!z) return;
	printf("	S%d -> S%d  [color=black", j, z->st);

	if (z->atom&6) printf(",style=dashed");
	else if (z->atom&32) printf(",style=dotted");
	else if (z->atom&8) printf(",style=solid");
	else printf(",style=bold");

	printf(",label=\"");
	for (i = 0; z->tp[i]; i++)
	{	if (z->tp[i] == '\\'
		&&  z->tp[i+1] == 'n')
		{	i++; printf(" ");
		} else
		{	putchar(z->tp[i]);
	}	}
	printf("\"];\n");
	if (accpstate[n][j]) printf("  S%d [color=red,style=bold];\n", j);
	else if (progstate[n][j]) printf("  S%d [color=green,style=bold];\n", j);
	if (stopstate[n][j]) printf("  S%d [color=blue,style=bold,shape=box];\n", j);
}

#ifdef VAR_RANGES
#define BYTESIZE	32	/* 2^8 : 2^3 = 256:8 = 32 */

typedef struct Vr_Ptr {
	char	*nm;
	uchar	vals[BYTESIZE];
	struct Vr_Ptr *nxt;
} Vr_Ptr;
Vr_Ptr *ranges = (Vr_Ptr *) 0;

void
logval(char *s, int v)
{	Vr_Ptr *tmp;

	if (v<0 || v > 255) return;
	for (tmp = ranges; tmp; tmp = tmp->nxt)
		if (!strcmp(tmp->nm, s))
			goto found;
	tmp = (Vr_Ptr *) emalloc(sizeof(Vr_Ptr));
	tmp->nxt = ranges;
	ranges = tmp;
	tmp->nm = s;
found:
	tmp->vals[(v)/8] |= 1<<((v)%8);
}

void
dumpval(uchar X[], int range)
{	int w, x, i, j = -1;

	for (w = i = 0; w < range; w++)
	for (x = 0; x < 8; x++, i++)
	{
from:		if ((X[w] & (1<<x)))
		{	printf("%d", i);
			j = i;
			goto upto;
	}	}
	return;
	for (w = 0; w < range; w++)
	for (x = 0; x < 8; x++, i++)
	{
upto:		if (!(X[w] & (1<<x)))
		{	if (i-1 == j)
				printf(", ");
			else
				printf("-%d, ", i-1);
			goto from;
	}	}
	if (j >= 0 && j != 255)
		printf("-255");
}

void
dumpranges(void)
{	Vr_Ptr *tmp;
	printf("\nValues assigned within ");
	printf("interval [0..255]:\n");
	for (tmp = ranges; tmp; tmp = tmp->nxt)
	{	printf("\t%s\t: ", tmp->nm);
		dumpval(tmp->vals, BYTESIZE);
		printf("\n");
	}
}
#endif
