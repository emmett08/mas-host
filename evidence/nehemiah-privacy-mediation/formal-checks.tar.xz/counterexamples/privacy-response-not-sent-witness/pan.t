#ifdef PEG
struct T_SRC {
	char *fl; int ln;
} T_SRC[NTRANS];

void
tr_2_src(int m, char *file, int ln)
{	T_SRC[m].fl = file;
	T_SRC[m].ln = ln;
}

void
putpeg(int n, int m)
{	printf("%5d	trans %4d ", m, n);
	printf("%s:%d\n",
		T_SRC[n].fl, T_SRC[n].ln);
}
#endif

void
settable(void)
{	Trans *T;
	Trans *settr(int, int, int, int, int, char *, int, int, int);

	trans = (Trans ***) emalloc(7*sizeof(Trans **));

	/* proctype 5: privacy_response_settles */

	trans[5] = (Trans **) emalloc(7*sizeof(Trans *));

	trans[5][4]	= settr(349,0,3,1,0,".(goto)", 0, 2, 0);
	T = trans[5][3] = settr(348,0,0,0,0,"DO", 0, 2, 0);
	    T->nxt	= settr(348,0,1,0,0,"DO", 0, 2, 0);
	trans[5][1]	= settr(346,0,3,3,0,"(!(finished))", 1, 2, 0);
	trans[5][2]	= settr(347,0,3,1,0,"goto T0_init", 0, 2, 0);
	trans[5][5]	= settr(350,0,6,1,0,"break", 0, 2, 0);
	trans[5][6]	= settr(351,0,0,4,4,"-end-", 0, 3500, 0);

	/* proctype 4: :init: */

	trans[4] = (Trans **) emalloc(7*sizeof(Trans *));

	T = trans[ 4][5] = settr(344,2,0,0,0,"ATOMIC", 0, 2, 0);
	T->nxt	= settr(344,2,1,0,0,"ATOMIC", 0, 2, 0);
	trans[4][1]	= settr(340,2,2,5,5,"(run Handler())", 0, 2, 0);
	trans[4][2]	= settr(341,2,3,6,6,"(run Endpoint())", 0, 2, 0);
	trans[4][3]	= settr(342,2,4,7,7,"(run Revoke())", 0, 2, 0);
	trans[4][4]	= settr(343,0,6,8,8,"(run Crash())", 0, 2, 0);
	trans[4][6]	= settr(345,0,0,9,9,"-end-", 0, 3500, 0);

	/* proctype 3: Handler */

	trans[3] = (Trans **) emalloc(312*sizeof(Trans *));

	T = trans[ 3][23] = settr(51,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(51,2,7,0,0,"ATOMIC", 1, 2, 0);
	T = trans[3][7] = settr(35,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(35,2,1,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(35,2,3,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(35,2,5,0,0,"IF", 1, 2, 0);
	trans[3][1]	= settr(29,2,22,10,10,"reason = Privacy", 1, 2, 0); /* m: 2 -> 0,22 */
	reached3[2] = 1;
	trans[3][2]	= settr(0,0,0,0,0,"required_route = 1",0,0,0);
	trans[3][8]	= settr(36,2,9,1,0,".(goto)", 1, 2, 0); /* m: 9 -> 0,22 */
	reached3[9] = 1;
	trans[3][3]	= settr(31,2,22,11,11,"reason = Secret", 1, 2, 0); /* m: 4 -> 0,22 */
	reached3[4] = 1;
	trans[3][4]	= settr(0,0,0,0,0,"required_route = 2",0,0,0);
	trans[3][5]	= settr(33,2,22,12,12,"reason = Coverage", 1, 2, 0); /* m: 6 -> 0,22 */
	reached3[6] = 1;
	trans[3][6]	= settr(0,0,0,0,0,"required_route = 3",0,0,0);
	trans[3][9]	= settr(37,2,22,13,13,"route = required_route", 1, 2, 0);
	T = trans[ 3][22] = settr(50,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(50,0,10,0,0,"sub-sequence", 1, 2, 0);
	trans[3][10]	= settr(38,0,307,14,14,"assert(((intent_calls<=1)&&(notification_calls<=1)))", 1, 2, 0); /* m: 11 -> 0,307 */
	reached3[11] = 1;
	trans[3][11]	= settr(0,0,0,0,0,"assert((route==required_route))",0,0,0);
	trans[3][12]	= settr(0,0,0,0,0,"assert(((frozen_route==0)||(frozen_route==required_route)))",0,0,0);
	trans[3][13]	= settr(0,0,0,0,0,"assert(((frozen_event==0)||(frozen_event==1)))",0,0,0);
	trans[3][14]	= settr(0,0,0,0,0,"assert(((frozen_destination==0)||(frozen_destination==1)))",0,0,0);
	trans[3][15]	= settr(0,0,0,0,0,"assert((!(intent_receipt)||(intent_state==Completed)))",0,0,0);
	trans[3][16]	= settr(0,0,0,0,0,"assert((!(notification_receipt)||(notification_state==Completed)))",0,0,0);
	trans[3][17]	= settr(0,0,0,0,0,"assert(((notification_calls==0)||(intent_receipt&&intent_exposed)))",0,0,0);
	trans[3][18]	= settr(0,0,0,0,0,"assert((!(notification_receipt)||(provider_outcome==sealed_outcome)))",0,0,0);
	trans[3][19]	= settr(0,0,0,0,0,"assert((!(notification_receipt)||(provider_outcome==observed_outcome)))",0,0,0);
	trans[3][20]	= settr(0,0,0,0,0,"assert(!(recipient_delivery_known))",0,0,0);
	trans[3][21]	= settr(0,0,0,0,0,"assert((!(replayed)||((intent_calls==sealed_intent_calls)&&(notification_calls==sealed_notification_calls))))",0,0,0);
	trans[3][308]	= settr(336,0,307,1,0,".(goto)", 0, 2, 0);
	T = trans[3][307] = settr(335,0,0,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(335,0,24,0,0,"DO", 0, 2, 0);
	    T->nxt	= settr(335,0,26,0,0,"DO", 0, 2, 0);
	trans[3][24]	= settr(52,0,310,15,0,"(finished)", 1, 2, 0);
	trans[3][25]	= settr(53,0,310,1,0,"goto :b0", 0, 2, 0);
	trans[3][26]	= settr(54,0,306,16,0,"(!(finished))", 1, 2, 0);
	T = trans[ 3][306] = settr(334,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(334,2,291,0,0,"ATOMIC", 1, 3, 504);
	T = trans[3][291] = settr(319,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(319,2,27,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(319,2,100,0,0,"IF", 1, 3, 504);
	trans[3][27]	= settr(55,2,98,17,17,"(crash)", 1, 3, 504); /* m: 28 -> 98,0 */
	reached3[28] = 1;
	trans[3][28]	= settr(0,0,0,0,0,"crash = 0",0,0,0);
	trans[3][29]	= settr(0,0,0,0,0,"restarted = 1",0,0,0);
	T = trans[3][98] = settr(126,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(126,2,30,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(126,2,56,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(126,2,82,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(126,2,85,0,0,"IF", 1, 3, 504);
	trans[3][30]	= settr(58,2,55,18,18,"((intent_state==Executing))", 1, 3, 504); /* m: 31 -> 55,0 */
	reached3[31] = 1;
	trans[3][31]	= settr(0,0,0,0,0,"intent_state = Unknown",0,0,0);
	trans[3][32]	= settr(0,0,0,0,0,"terminal = Blocked",0,0,0);
	T = trans[ 3][55] = settr(83,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(83,0,53,0,0,"sub-sequence", 1, 3, 504);
	T = trans[3][53] = settr(81,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(81,2,33,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(81,2,35,0,0,"IF", 1, 3, 504);
	trans[3][33]	= settr(61,2,305,19,19,"(replayed)", 1, 3, 504); /* m: 34 -> 305,0 */
	reached3[34] = 1;
	trans[3][34]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][54]	= settr(82,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][35]	= settr(63,2,38,20,0,"(!(replayed))", 1, 3, 504);
	T = trans[3][38] = settr(66,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(66,2,36,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(66,2,37,0,0,"IF", 1, 3, 504);
	trans[3][36]	= settr(64,2,42,21,21,"attempt_event = 1", 1, 3, 504);
	trans[3][39]	= settr(67,2,42,1,0,".(goto)", 1, 3, 504);
	trans[3][37]	= settr(65,2,42,22,22,"attempt_event = 2", 1, 3, 504);
	T = trans[3][42] = settr(70,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(70,2,40,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(70,2,41,0,0,"IF", 1, 3, 504);
	trans[3][40]	= settr(68,2,46,23,23,"attempt_tenant = 1", 1, 3, 504);
	trans[3][43]	= settr(71,2,46,1,0,".(goto)", 1, 3, 504);
	trans[3][41]	= settr(69,2,46,24,24,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][46] = settr(74,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(74,2,44,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(74,2,45,0,0,"IF", 1, 3, 504);
	trans[3][44]	= settr(72,2,305,25,25,"attempt_destination = 1", 1, 3, 504); /* m: 48 -> 0,305 */
	reached3[48] = 1;
	trans[3][47]	= settr(75,2,48,1,0,".(goto)", 1, 3, 504); /* m: 48 -> 0,305 */
	reached3[48] = 1;
	trans[3][45]	= settr(73,2,305,26,26,"attempt_destination = 2", 1, 3, 504); /* m: 48 -> 0,305 */
	reached3[48] = 1;
	trans[3][48]	= settr(76,2,305,27,27,"sealed_intent_calls = intent_calls", 1, 3, 504); /* m: 49 -> 0,305 */
	reached3[49] = 1;
	trans[3][49]	= settr(0,0,0,0,0,"sealed_notification_calls = notification_calls",0,0,0);
	trans[3][50]	= settr(0,0,0,0,0,"replayed = 1",0,0,0);
	trans[3][51]	= settr(0,0,0,0,0,"terminal = Running",0,0,0);
	trans[3][52]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][99]	= settr(127,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][56]	= settr(84,2,81,28,28,"((notification_state==Executing))", 1, 3, 504); /* m: 57 -> 81,0 */
	reached3[57] = 1;
	trans[3][57]	= settr(0,0,0,0,0,"notification_state = Unknown",0,0,0);
	trans[3][58]	= settr(0,0,0,0,0,"terminal = Blocked",0,0,0);
	T = trans[ 3][81] = settr(109,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(109,0,79,0,0,"sub-sequence", 1, 3, 504);
	T = trans[3][79] = settr(107,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(107,2,59,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(107,2,61,0,0,"IF", 1, 3, 504);
	trans[3][59]	= settr(87,2,305,29,29,"(replayed)", 1, 3, 504); /* m: 60 -> 305,0 */
	reached3[60] = 1;
	trans[3][60]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][80]	= settr(108,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][61]	= settr(89,2,64,30,0,"(!(replayed))", 1, 3, 504);
	T = trans[3][64] = settr(92,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(92,2,62,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(92,2,63,0,0,"IF", 1, 3, 504);
	trans[3][62]	= settr(90,2,68,31,31,"attempt_event = 1", 1, 3, 504);
	trans[3][65]	= settr(93,2,68,1,0,".(goto)", 1, 3, 504);
	trans[3][63]	= settr(91,2,68,32,32,"attempt_event = 2", 1, 3, 504);
	T = trans[3][68] = settr(96,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(96,2,66,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(96,2,67,0,0,"IF", 1, 3, 504);
	trans[3][66]	= settr(94,2,72,33,33,"attempt_tenant = 1", 1, 3, 504);
	trans[3][69]	= settr(97,2,72,1,0,".(goto)", 1, 3, 504);
	trans[3][67]	= settr(95,2,72,34,34,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][72] = settr(100,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(100,2,70,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(100,2,71,0,0,"IF", 1, 3, 504);
	trans[3][70]	= settr(98,2,305,35,35,"attempt_destination = 1", 1, 3, 504); /* m: 74 -> 0,305 */
	reached3[74] = 1;
	trans[3][73]	= settr(101,2,74,1,0,".(goto)", 1, 3, 504); /* m: 74 -> 0,305 */
	reached3[74] = 1;
	trans[3][71]	= settr(99,2,305,36,36,"attempt_destination = 2", 1, 3, 504); /* m: 74 -> 0,305 */
	reached3[74] = 1;
	trans[3][74]	= settr(102,2,305,37,37,"sealed_intent_calls = intent_calls", 1, 3, 504); /* m: 75 -> 0,305 */
	reached3[75] = 1;
	trans[3][75]	= settr(0,0,0,0,0,"sealed_notification_calls = notification_calls",0,0,0);
	trans[3][76]	= settr(0,0,0,0,0,"replayed = 1",0,0,0);
	trans[3][77]	= settr(0,0,0,0,0,"terminal = Running",0,0,0);
	trans[3][78]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][82]	= settr(110,2,305,38,38,"(((intent_state==Unknown)||(notification_state==Unknown)))", 1, 3, 504); /* m: 83 -> 305,0 */
	reached3[83] = 1;
	trans[3][83]	= settr(0,0,0,0,0,"terminal = Blocked",0,0,0);
	trans[3][84]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][85]	= settr(113,2,90,2,0,"else", 1, 3, 504);
	T = trans[3][90] = settr(118,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(118,2,86,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(118,2,88,0,0,"IF", 1, 3, 504);
	trans[3][86]	= settr(114,2,96,39,39,"(((intent_state==Completed)&&(notification_state==Empty)))", 1, 3, 504); /* m: 87 -> 96,0 */
	reached3[87] = 1;
	trans[3][87]	= settr(0,0,0,0,0,"crashed_between_effects = 1",0,0,0);
	trans[3][91]	= settr(119,2,96,1,0,".(goto)", 1, 3, 504);
	trans[3][88]	= settr(116,2,89,2,0,"else", 1, 3, 504);
	trans[3][89]	= settr(117,2,96,1,0,"(1)", 1, 3, 504);
	T = trans[3][96] = settr(124,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(124,2,92,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(124,2,94,0,0,"IF", 1, 3, 504);
	trans[3][92]	= settr(120,2,305,40,40,"(replayed)", 1, 3, 504); /* m: 93 -> 305,0 */
	reached3[93] = 1;
	trans[3][93]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][97]	= settr(125,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][94]	= settr(122,2,305,41,41,"(!(replayed))", 1, 3, 504); /* m: 95 -> 305,0 */
	reached3[95] = 1;
	trans[3][95]	= settr(0,0,0,0,0,"pc = 0",0,0,0);
	trans[3][292]	= settr(320,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][100]	= settr(128,2,289,42,0,"(!(crash))", 1, 3, 504);
	T = trans[3][289] = settr(317,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,101,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,115,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,122,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,125,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,133,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,163,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,174,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,184,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,188,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,191,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,230,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(317,2,256,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(317,2,272,0,0,"IF", 1, 3, 504);
	trans[3][101]	= settr(129,2,113,43,43,"((pc==0))", 1, 3, 504); /* m: 102 -> 113,0 */
	reached3[102] = 1;
	trans[3][102]	= settr(0,0,0,0,0,"admission_check = rights",0,0,0);
	T = trans[3][113] = settr(141,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(141,2,103,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(141,2,106,0,0,"IF", 1, 3, 504);
	trans[3][103]	= settr(131,2,305,44,44,"(!(admission_check))", 1, 3, 504); /* m: 104 -> 305,0 */
	reached3[104] = 1;
	trans[3][104]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][105]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][114]	= settr(142,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][106]	= settr(134,2,111,45,0,"(admission_check)", 1, 3, 504);
	T = trans[3][111] = settr(139,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(139,2,107,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(139,2,109,0,0,"IF", 1, 3, 504);
	trans[3][107]	= settr(135,2,305,46,46,"((intent_state==Completed))", 1, 3, 504); /* m: 108 -> 305,0 */
	reached3[108] = 1;
	trans[3][108]	= settr(0,0,0,0,0,"pc = 4",0,0,0);
	trans[3][112]	= settr(140,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][109]	= settr(137,2,305,47,47,"((intent_state==Empty))", 1, 3, 504); /* m: 110 -> 305,0 */
	reached3[110] = 1;
	trans[3][110]	= settr(0,0,0,0,0,"pc = 1",0,0,0);
	trans[3][290]	= settr(318,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][115]	= settr(143,2,305,48,48,"((pc==1))", 1, 3, 504); /* m: 116 -> 305,0 */
	reached3[116] = 1;
	trans[3][116]	= settr(0,0,0,0,0,"assert(admission_check)",0,0,0);
	trans[3][117]	= settr(0,0,0,0,0,"frozen_event = 1",0,0,0);
	trans[3][118]	= settr(0,0,0,0,0,"frozen_route = route",0,0,0);
	trans[3][119]	= settr(0,0,0,0,0,"frozen_destination = 1",0,0,0);
	trans[3][120]	= settr(0,0,0,0,0,"intent_state = Executing",0,0,0);
	trans[3][121]	= settr(0,0,0,0,0,"pc = 2",0,0,0);
	trans[3][122]	= settr(150,2,305,49,49,"((pc==2))", 1, 3, 504); /* m: 123 -> 305,0 */
	reached3[123] = 1;
	trans[3][123]	= settr(0,0,0,0,0,"intent_calls = (intent_calls+1)",0,0,0);
	trans[3][124]	= settr(0,0,0,0,0,"pc = 3",0,0,0);
	trans[3][125]	= settr(153,2,130,50,50,"((pc==3))", 1, 3, 504); /* m: 126 -> 130,0 */
	reached3[126] = 1;
	trans[3][126]	= settr(0,0,0,0,0,"intent_state = Completed",0,0,0);
	trans[3][127]	= settr(0,0,0,0,0,"intent_receipt = 1",0,0,0);
	T = trans[3][130] = settr(158,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(158,2,128,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(158,2,129,0,0,"IF", 1, 3, 504);
	trans[3][128]	= settr(156,2,305,51,51,"intent_exposed = 1", 1, 3, 504); /* m: 132 -> 0,305 */
	reached3[132] = 1;
	trans[3][131]	= settr(159,2,132,1,0,".(goto)", 1, 3, 504); /* m: 132 -> 0,305 */
	reached3[132] = 1;
	trans[3][129]	= settr(157,2,305,52,52,"intent_exposed = 0", 1, 3, 504); /* m: 132 -> 0,305 */
	reached3[132] = 1;
	trans[3][132]	= settr(160,2,305,53,53,"pc = 4", 1, 3, 504);
	trans[3][133]	= settr(161,2,161,54,0,"((pc==4))", 1, 3, 504);
	T = trans[3][161] = settr(189,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(189,2,134,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(189,2,136,0,0,"IF", 1, 3, 504);
	trans[3][134]	= settr(162,2,305,55,55,"(intent_exposed)", 1, 3, 504); /* m: 135 -> 305,0 */
	reached3[135] = 1;
	trans[3][135]	= settr(0,0,0,0,0,"pc = 5",0,0,0);
	trans[3][162]	= settr(190,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][136]	= settr(164,2,160,56,56,"(!(intent_exposed))", 1, 3, 504); /* m: 137 -> 160,0 */
	reached3[137] = 1;
	trans[3][137]	= settr(0,0,0,0,0,"terminal = Held",0,0,0);
	T = trans[ 3][160] = settr(188,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(188,0,158,0,0,"sub-sequence", 1, 3, 504);
	T = trans[3][158] = settr(186,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(186,2,138,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(186,2,140,0,0,"IF", 1, 3, 504);
	trans[3][138]	= settr(166,2,305,57,57,"(replayed)", 1, 3, 504); /* m: 139 -> 305,0 */
	reached3[139] = 1;
	trans[3][139]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][159]	= settr(187,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][140]	= settr(168,2,143,58,0,"(!(replayed))", 1, 3, 504);
	T = trans[3][143] = settr(171,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(171,2,141,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(171,2,142,0,0,"IF", 1, 3, 504);
	trans[3][141]	= settr(169,2,147,59,59,"attempt_event = 1", 1, 3, 504);
	trans[3][144]	= settr(172,2,147,1,0,".(goto)", 1, 3, 504);
	trans[3][142]	= settr(170,2,147,60,60,"attempt_event = 2", 1, 3, 504);
	T = trans[3][147] = settr(175,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(175,2,145,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(175,2,146,0,0,"IF", 1, 3, 504);
	trans[3][145]	= settr(173,2,151,61,61,"attempt_tenant = 1", 1, 3, 504);
	trans[3][148]	= settr(176,2,151,1,0,".(goto)", 1, 3, 504);
	trans[3][146]	= settr(174,2,151,62,62,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][151] = settr(179,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(179,2,149,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(179,2,150,0,0,"IF", 1, 3, 504);
	trans[3][149]	= settr(177,2,305,63,63,"attempt_destination = 1", 1, 3, 504); /* m: 153 -> 0,305 */
	reached3[153] = 1;
	trans[3][152]	= settr(180,2,153,1,0,".(goto)", 1, 3, 504); /* m: 153 -> 0,305 */
	reached3[153] = 1;
	trans[3][150]	= settr(178,2,305,64,64,"attempt_destination = 2", 1, 3, 504); /* m: 153 -> 0,305 */
	reached3[153] = 1;
	trans[3][153]	= settr(181,2,305,65,65,"sealed_intent_calls = intent_calls", 1, 3, 504); /* m: 154 -> 0,305 */
	reached3[154] = 1;
	trans[3][154]	= settr(0,0,0,0,0,"sealed_notification_calls = notification_calls",0,0,0);
	trans[3][155]	= settr(0,0,0,0,0,"replayed = 1",0,0,0);
	trans[3][156]	= settr(0,0,0,0,0,"terminal = Running",0,0,0);
	trans[3][157]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][163]	= settr(191,2,172,66,66,"((pc==5))", 1, 3, 504); /* m: 164 -> 172,0 */
	reached3[164] = 1;
	trans[3][164]	= settr(0,0,0,0,0,"admission_check = rights",0,0,0);
	trans[3][165]	= settr(0,0,0,0,0,"assert((!(admission_check)||rights))",0,0,0);
	T = trans[3][172] = settr(200,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(200,2,166,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(200,2,168,0,0,"IF", 1, 3, 504);
	trans[3][166]	= settr(194,2,305,67,67,"(admission_check)", 1, 3, 504); /* m: 167 -> 305,0 */
	reached3[167] = 1;
	trans[3][167]	= settr(0,0,0,0,0,"pc = 6",0,0,0);
	trans[3][173]	= settr(201,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][168]	= settr(196,2,305,68,68,"(!(admission_check))", 1, 3, 504); /* m: 169 -> 305,0 */
	reached3[169] = 1;
	trans[3][169]	= settr(0,0,0,0,0,"revoked_before_notification = 1",0,0,0);
	trans[3][170]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][171]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][174]	= settr(202,2,182,69,69,"((pc==6))", 1, 3, 504); /* m: 175 -> 182,0 */
	reached3[175] = 1;
	trans[3][175]	= settr(0,0,0,0,0,"assert((intent_receipt&&intent_exposed))",0,0,0);
	trans[3][176]	= settr(0,0,0,0,0,"assert(admission_check)",0,0,0);
	T = trans[3][182] = settr(210,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(210,2,177,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(210,2,179,0,0,"IF", 1, 3, 504);
	trans[3][177]	= settr(205,2,305,70,70,"((notification_state==Completed))", 1, 3, 504); /* m: 178 -> 305,0 */
	reached3[178] = 1;
	trans[3][178]	= settr(0,0,0,0,0,"pc = 10",0,0,0);
	trans[3][183]	= settr(211,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][179]	= settr(207,2,305,71,71,"((notification_state==Empty))", 1, 3, 504); /* m: 180 -> 305,0 */
	reached3[180] = 1;
	trans[3][180]	= settr(0,0,0,0,0,"notification_state = Executing",0,0,0);
	trans[3][181]	= settr(0,0,0,0,0,"pc = 7",0,0,0);
	trans[3][184]	= settr(212,2,186,72,72,"((pc==7))", 1, 3, 504); /* m: 185 -> 186,0 */
	reached3[185] = 1;
	trans[3][185]	= settr(0,0,0,0,0,"notification_calls = (notification_calls+1)",0,0,0);
	trans[3][186]	= settr(214,2,305,73,73,"submissions!1", 1, 3, 504); /* m: 187 -> 305,0 */
	reached3[187] = 1;
	trans[3][187]	= settr(0,0,0,0,0,"pc = 8",0,0,0);
	trans[3][188]	= settr(216,2,189,74,0,"((pc==8))", 1, 3, 504);
	trans[3][189]	= settr(217,2,305,75,75,"replies?observed_outcome", 1, 3, 504); /* m: 190 -> 305,0 */
	reached3[190] = 1;
	trans[3][190]	= settr(0,0,0,0,0,"pc = 9",0,0,0);
	trans[3][191]	= settr(219,2,228,76,0,"((pc==9))", 1, 3, 504);
	T = trans[3][228] = settr(256,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(256,2,192,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(256,2,218,0,0,"IF", 1, 3, 504);
	trans[3][192]	= settr(220,2,217,77,77,"((observed_outcome==Lost))", 1, 3, 504); /* m: 193 -> 217,0 */
	reached3[193] = 1;
	trans[3][193]	= settr(0,0,0,0,0,"notification_state = Unknown",0,0,0);
	trans[3][194]	= settr(0,0,0,0,0,"terminal = Blocked",0,0,0);
	T = trans[ 3][217] = settr(245,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(245,0,215,0,0,"sub-sequence", 1, 3, 504);
	T = trans[3][215] = settr(243,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(243,2,195,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(243,2,197,0,0,"IF", 1, 3, 504);
	trans[3][195]	= settr(223,2,305,78,78,"(replayed)", 1, 3, 504); /* m: 196 -> 305,0 */
	reached3[196] = 1;
	trans[3][196]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][216]	= settr(244,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][197]	= settr(225,2,200,79,0,"(!(replayed))", 1, 3, 504);
	T = trans[3][200] = settr(228,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(228,2,198,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(228,2,199,0,0,"IF", 1, 3, 504);
	trans[3][198]	= settr(226,2,204,80,80,"attempt_event = 1", 1, 3, 504);
	trans[3][201]	= settr(229,2,204,1,0,".(goto)", 1, 3, 504);
	trans[3][199]	= settr(227,2,204,81,81,"attempt_event = 2", 1, 3, 504);
	T = trans[3][204] = settr(232,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(232,2,202,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(232,2,203,0,0,"IF", 1, 3, 504);
	trans[3][202]	= settr(230,2,208,82,82,"attempt_tenant = 1", 1, 3, 504);
	trans[3][205]	= settr(233,2,208,1,0,".(goto)", 1, 3, 504);
	trans[3][203]	= settr(231,2,208,83,83,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][208] = settr(236,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(236,2,206,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(236,2,207,0,0,"IF", 1, 3, 504);
	trans[3][206]	= settr(234,2,305,84,84,"attempt_destination = 1", 1, 3, 504); /* m: 210 -> 0,305 */
	reached3[210] = 1;
	trans[3][209]	= settr(237,2,210,1,0,".(goto)", 1, 3, 504); /* m: 210 -> 0,305 */
	reached3[210] = 1;
	trans[3][207]	= settr(235,2,305,85,85,"attempt_destination = 2", 1, 3, 504); /* m: 210 -> 0,305 */
	reached3[210] = 1;
	trans[3][210]	= settr(238,2,305,86,86,"sealed_intent_calls = intent_calls", 1, 3, 504); /* m: 211 -> 0,305 */
	reached3[211] = 1;
	trans[3][211]	= settr(0,0,0,0,0,"sealed_notification_calls = notification_calls",0,0,0);
	trans[3][212]	= settr(0,0,0,0,0,"replayed = 1",0,0,0);
	trans[3][213]	= settr(0,0,0,0,0,"terminal = Running",0,0,0);
	trans[3][214]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][229]	= settr(257,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][218]	= settr(246,2,225,87,87,"((observed_outcome!=Lost))", 1, 3, 504); /* m: 219 -> 225,0 */
	reached3[219] = 1;
	trans[3][219]	= settr(0,0,0,0,0,"provider_outcome = observed_outcome",0,0,0);
	trans[3][220]	= settr(0,0,0,0,0,"sealed_outcome = observed_outcome",0,0,0);
	trans[3][221]	= settr(0,0,0,0,0,"notification_state = Completed",0,0,0);
	trans[3][222]	= settr(0,0,0,0,0,"notification_receipt = 1",0,0,0);
	T = trans[3][225] = settr(253,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(253,2,223,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(253,2,224,0,0,"IF", 1, 3, 504);
	trans[3][223]	= settr(251,2,305,88,88,"payload_withheld = 1", 1, 3, 504); /* m: 227 -> 0,305 */
	reached3[227] = 1;
	trans[3][226]	= settr(254,2,227,1,0,".(goto)", 1, 3, 504); /* m: 227 -> 0,305 */
	reached3[227] = 1;
	trans[3][224]	= settr(252,2,305,89,89,"payload_withheld = 0", 1, 3, 504); /* m: 227 -> 0,305 */
	reached3[227] = 1;
	trans[3][227]	= settr(255,2,305,90,90,"pc = 10", 1, 3, 504);
	trans[3][230]	= settr(258,2,255,91,91,"((pc==10))", 1, 3, 504); /* m: 231 -> 255,0 */
	reached3[231] = 1;
	trans[3][231]	= settr(0,0,0,0,0,"assert((((attempt_tenant==1)&&(attempt_event==frozen_event))&&(attempt_destination==frozen_destination)))",0,0,0);
	trans[3][232]	= settr(0,0,0,0,0,"terminal = Settled",0,0,0);
	T = trans[ 3][255] = settr(283,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(283,0,253,0,0,"sub-sequence", 1, 3, 504);
	T = trans[3][253] = settr(281,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(281,2,233,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(281,2,235,0,0,"IF", 1, 3, 504);
	trans[3][233]	= settr(261,2,305,92,92,"(replayed)", 1, 3, 504); /* m: 234 -> 305,0 */
	reached3[234] = 1;
	trans[3][234]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][254]	= settr(282,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][235]	= settr(263,2,238,93,0,"(!(replayed))", 1, 3, 504);
	T = trans[3][238] = settr(266,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(266,2,236,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(266,2,237,0,0,"IF", 1, 3, 504);
	trans[3][236]	= settr(264,2,242,94,94,"attempt_event = 1", 1, 3, 504);
	trans[3][239]	= settr(267,2,242,1,0,".(goto)", 1, 3, 504);
	trans[3][237]	= settr(265,2,242,95,95,"attempt_event = 2", 1, 3, 504);
	T = trans[3][242] = settr(270,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(270,2,240,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(270,2,241,0,0,"IF", 1, 3, 504);
	trans[3][240]	= settr(268,2,246,96,96,"attempt_tenant = 1", 1, 3, 504);
	trans[3][243]	= settr(271,2,246,1,0,".(goto)", 1, 3, 504);
	trans[3][241]	= settr(269,2,246,97,97,"attempt_tenant = 2", 1, 3, 504);
	T = trans[3][246] = settr(274,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(274,2,244,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(274,2,245,0,0,"IF", 1, 3, 504);
	trans[3][244]	= settr(272,2,305,98,98,"attempt_destination = 1", 1, 3, 504); /* m: 248 -> 0,305 */
	reached3[248] = 1;
	trans[3][247]	= settr(275,2,248,1,0,".(goto)", 1, 3, 504); /* m: 248 -> 0,305 */
	reached3[248] = 1;
	trans[3][245]	= settr(273,2,305,99,99,"attempt_destination = 2", 1, 3, 504); /* m: 248 -> 0,305 */
	reached3[248] = 1;
	trans[3][248]	= settr(276,2,305,100,100,"sealed_intent_calls = intent_calls", 1, 3, 504); /* m: 249 -> 0,305 */
	reached3[249] = 1;
	trans[3][249]	= settr(0,0,0,0,0,"sealed_notification_calls = notification_calls",0,0,0);
	trans[3][250]	= settr(0,0,0,0,0,"replayed = 1",0,0,0);
	trans[3][251]	= settr(0,0,0,0,0,"terminal = Running",0,0,0);
	trans[3][252]	= settr(0,0,0,0,0,"pc = 20",0,0,0);
	trans[3][256]	= settr(284,2,270,101,0,"((pc==20))", 1, 3, 504);
	T = trans[3][270] = settr(298,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(298,2,257,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(298,2,261,0,0,"IF", 1, 3, 504);
	trans[3][257]	= settr(285,2,305,102,102,"((attempt_tenant!=1))", 1, 3, 504); /* m: 258 -> 305,0 */
	reached3[258] = 1;
	trans[3][258]	= settr(0,0,0,0,0,"foreign_rejected = 1",0,0,0);
	trans[3][259]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][260]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][271]	= settr(299,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][261]	= settr(289,2,268,103,0,"((attempt_tenant==1))", 1, 3, 504);
	T = trans[3][268] = settr(296,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(296,2,262,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(296,2,266,0,0,"IF", 1, 3, 504);
	trans[3][262]	= settr(290,2,305,104,104,"((attempt_event!=frozen_event))", 1, 3, 504); /* m: 263 -> 305,0 */
	reached3[263] = 1;
	trans[3][263]	= settr(0,0,0,0,0,"conflict_rejected = 1",0,0,0);
	trans[3][264]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][265]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][269]	= settr(297,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][266]	= settr(294,2,305,105,105,"((attempt_event==frozen_event))", 1, 3, 504); /* m: 267 -> 305,0 */
	reached3[267] = 1;
	trans[3][267]	= settr(0,0,0,0,0,"pc = 21",0,0,0);
	trans[3][272]	= settr(300,2,287,106,0,"((pc==21))", 1, 3, 504);
	T = trans[3][287] = settr(315,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(315,2,273,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(315,2,277,0,0,"IF", 1, 3, 504);
	trans[3][273]	= settr(301,2,305,107,107,"((attempt_destination!=frozen_destination))", 1, 3, 504); /* m: 274 -> 305,0 */
	reached3[274] = 1;
	trans[3][274]	= settr(0,0,0,0,0,"destination_conflict = 1",0,0,0);
	trans[3][275]	= settr(0,0,0,0,0,"terminal = Denied",0,0,0);
	trans[3][276]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][288]	= settr(316,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][277]	= settr(305,2,285,108,0,"((attempt_destination==frozen_destination))", 1, 3, 504);
	T = trans[3][285] = settr(313,2,0,0,0,"IF", 1, 3, 504);
	T = T->nxt	= settr(313,2,278,0,0,"IF", 1, 3, 504);
	    T->nxt	= settr(313,2,283,0,0,"IF", 1, 3, 504);
	trans[3][278]	= settr(306,2,305,109,109,"(((intent_state==Unknown)||(notification_state==Unknown)))", 1, 3, 504); /* m: 279 -> 305,0 */
	reached3[279] = 1;
	trans[3][279]	= settr(0,0,0,0,0,"assert((notification_calls==sealed_notification_calls))",0,0,0);
	trans[3][280]	= settr(0,0,0,0,0,"unknown_retry_blocked = 1",0,0,0);
	trans[3][281]	= settr(0,0,0,0,0,"terminal = Blocked",0,0,0);
	trans[3][282]	= settr(0,0,0,0,0,"finished = 1",0,0,0);
	trans[3][286]	= settr(314,2,305,1,0,".(goto)", 1, 3, 504);
	trans[3][283]	= settr(311,2,284,2,0,"else", 1, 3, 504);
	trans[3][284]	= settr(312,2,305,110,110,"pc = 0", 1, 3, 504);
	T = trans[ 3][305] = settr(333,0,0,0,0,"sub-sequence", 1, 3, 504);
	T->nxt	= settr(333,0,293,0,0,"sub-sequence", 1, 3, 504);
	trans[3][293]	= settr(321,0,307,111,111,"assert(((intent_calls<=1)&&(notification_calls<=1)))", 1, 3, 504); /* m: 294 -> 0,307 */
	reached3[294] = 1;
	trans[3][294]	= settr(0,0,0,0,0,"assert((route==required_route))",0,0,0);
	trans[3][295]	= settr(0,0,0,0,0,"assert(((frozen_route==0)||(frozen_route==required_route)))",0,0,0);
	trans[3][296]	= settr(0,0,0,0,0,"assert(((frozen_event==0)||(frozen_event==1)))",0,0,0);
	trans[3][297]	= settr(0,0,0,0,0,"assert(((frozen_destination==0)||(frozen_destination==1)))",0,0,0);
	trans[3][298]	= settr(0,0,0,0,0,"assert((!(intent_receipt)||(intent_state==Completed)))",0,0,0);
	trans[3][299]	= settr(0,0,0,0,0,"assert((!(notification_receipt)||(notification_state==Completed)))",0,0,0);
	trans[3][300]	= settr(0,0,0,0,0,"assert(((notification_calls==0)||(intent_receipt&&intent_exposed)))",0,0,0);
	trans[3][301]	= settr(0,0,0,0,0,"assert((!(notification_receipt)||(provider_outcome==sealed_outcome)))",0,0,0);
	trans[3][302]	= settr(0,0,0,0,0,"assert((!(notification_receipt)||(provider_outcome==observed_outcome)))",0,0,0);
	trans[3][303]	= settr(0,0,0,0,0,"assert(!(recipient_delivery_known))",0,0,0);
	trans[3][304]	= settr(0,0,0,0,0,"assert((!(replayed)||((intent_calls==sealed_intent_calls)&&(notification_calls==sealed_notification_calls))))",0,0,0);
	trans[3][309]	= settr(337,0,310,1,0,"break", 0, 2, 0);
	trans[3][310]	= settr(338,0,311,112,0,"assert(!((notification_receipt&&(provider_outcome==NotSent))))", 1, 2, 0);
	trans[3][311]	= settr(339,0,0,113,113,"-end-", 0, 3500, 0);

	/* proctype 2: Endpoint */

	trans[2] = (Trans **) emalloc(15*sizeof(Trans *));

	T = trans[2][12] = settr(26,0,0,0,0,"IF", 0, 2, 0);
	T = T->nxt	= settr(26,0,1,0,0,"IF", 0, 2, 0);
	    T->nxt	= settr(26,0,10,0,0,"IF", 0, 2, 0);
	trans[2][1]	= settr(15,0,9,114,114,"submissions?action_id", 1, 503, 0);
	T = trans[ 2][9] = settr(23,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(23,2,7,0,0,"ATOMIC", 1, 4, 0);
	T = trans[2][7] = settr(21,2,0,0,0,"IF", 1, 4, 0);
	T = T->nxt	= settr(21,2,2,0,0,"IF", 1, 4, 0);
	T = T->nxt	= settr(21,2,3,0,0,"IF", 1, 4, 0);
	T = T->nxt	= settr(21,2,4,0,0,"IF", 1, 4, 0);
	T = T->nxt	= settr(21,2,5,0,0,"IF", 1, 4, 0);
	    T->nxt	= settr(21,2,6,0,0,"IF", 1, 4, 0);
	trans[2][2]	= settr(16,0,14,115,115,"replies!Accepted", 1, 4, 0); /* m: 8 -> 14,0 */
	reached2[8] = 1;
	trans[2][8]	= settr(22,0,14,1,0,".(goto)", 1, 4, 0);
	trans[2][3]	= settr(17,0,14,116,116,"replies!Refused", 1, 4, 0); /* m: 8 -> 14,0 */
	reached2[8] = 1;
	trans[2][4]	= settr(18,0,14,117,117,"replies!Throttled", 1, 4, 0); /* m: 8 -> 14,0 */
	reached2[8] = 1;
	trans[2][5]	= settr(19,0,14,118,118,"replies!NotSent", 1, 4, 0); /* m: 8 -> 14,0 */
	reached2[8] = 1;
	trans[2][6]	= settr(20,0,14,119,119,"replies!Lost", 1, 4, 0); /* m: 8 -> 14,0 */
	reached2[8] = 1;
	trans[2][13]	= settr(27,0,14,1,0,".(goto)", 0, 2, 0);
	trans[2][10]	= settr(24,0,11,120,0,"(finished)", 1, 2, 0);
	trans[2][11]	= settr(25,0,14,1,0,"(1)", 0, 2, 0);
	trans[2][14]	= settr(28,0,0,121,121,"-end-", 0, 3500, 0);

	/* proctype 1: Crash */

	trans[1] = (Trans **) emalloc(9*sizeof(Trans *));

	T = trans[1][6] = settr(12,0,0,0,0,"IF", 0, 2, 0);
	T = T->nxt	= settr(12,0,1,0,0,"IF", 0, 2, 0);
	    T->nxt	= settr(12,0,5,0,0,"IF", 0, 2, 0);
	trans[1][1]	= settr(7,0,8,1,0,"(1)", 0, 2, 0);
	trans[1][7]	= settr(13,0,8,1,0,".(goto)", 0, 2, 0);
	T = trans[ 1][5] = settr(11,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(11,2,2,0,0,"ATOMIC", 1, 2, 0);
	trans[1][2]	= settr(8,0,8,122,122,"(!(finished))", 1, 2, 0); /* m: 3 -> 8,0 */
	reached1[3] = 1;
	trans[1][3]	= settr(0,0,0,0,0,"crash = 1",0,0,0);
	trans[1][4]	= settr(0,0,0,0,0,"crashed_once = 1",0,0,0);
	trans[1][8]	= settr(14,0,0,123,123,"-end-", 0, 3500, 0);

	/* proctype 0: Revoke */

	trans[0] = (Trans **) emalloc(8*sizeof(Trans *));

	T = trans[0][5] = settr(4,0,0,0,0,"IF", 0, 2, 0);
	T = T->nxt	= settr(4,0,1,0,0,"IF", 0, 2, 0);
	    T->nxt	= settr(4,0,4,0,0,"IF", 0, 2, 0);
	trans[0][1]	= settr(0,0,7,1,0,"(1)", 0, 2, 0);
	trans[0][6]	= settr(5,0,7,1,0,".(goto)", 0, 2, 0);
	T = trans[ 0][4] = settr(3,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(3,2,2,0,0,"ATOMIC", 1, 2, 0);
	trans[0][2]	= settr(1,0,7,124,124,"(!(finished))", 1, 2, 0); /* m: 3 -> 7,0 */
	reached0[3] = 1;
	trans[0][3]	= settr(0,0,0,0,0,"rights = 0",0,0,0);
	trans[0][7]	= settr(6,0,0,125,125,"-end-", 0, 3500, 0);
	/* np_ demon: */
	trans[_NP_] = (Trans **) emalloc(3*sizeof(Trans *));
	T = trans[_NP_][0] = settr(9997,0,1,_T5,0,"(np_)", 1,2,0);
	    T->nxt	  = settr(9998,0,0,_T2,0,"(1)",   0,2,0);
	T = trans[_NP_][1] = settr(9999,0,1,_T5,0,"(np_)", 1,2,0);
}

Trans *
settr(	int t_id, int a, int b, int c, int d,
	char *t, int g, int tpe0, int tpe1)
{	Trans *tmp = (Trans *) emalloc(sizeof(Trans));

	tmp->atom  = a&(6|32);	/* only (2|8|32) have meaning */
	if (!g) tmp->atom |= 8;	/* no global references */
	tmp->st    = b;
	tmp->tpe[0] = tpe0;
	tmp->tpe[1] = tpe1;
	tmp->tp    = t;
	tmp->t_id  = t_id;
	tmp->forw  = c;
	tmp->back  = d;
	return tmp;
}

Trans *
cpytr(Trans *a)
{	Trans *tmp = (Trans *) emalloc(sizeof(Trans));

	int i;
	tmp->atom  = a->atom;
	tmp->st    = a->st;
#ifdef HAS_UNLESS
	tmp->e_trans = a->e_trans;
	for (i = 0; i < HAS_UNLESS; i++)
		tmp->escp[i] = a->escp[i];
#endif
	tmp->tpe[0] = a->tpe[0];
	tmp->tpe[1] = a->tpe[1];
	for (i = 0; i < 6; i++)
	{	tmp->qu[i] = a->qu[i];
		tmp->ty[i] = a->ty[i];
	}
	tmp->tp    = (char *) emalloc(strlen(a->tp)+1);
	strcpy(tmp->tp, a->tp);
	tmp->t_id  = a->t_id;
	tmp->forw  = a->forw;
	tmp->back  = a->back;
	return tmp;
}

#ifndef NOREDUCE
int
srinc_set(int n)
{	if (n <= 2) return LOCAL;
	if (n <= 2+  DELTA) return Q_FULL_F; /* 's' or nfull  */
	if (n <= 2+2*DELTA) return Q_EMPT_F; /* 'r' or nempty */
	if (n <= 2+3*DELTA) return Q_EMPT_T; /* empty */
	if (n <= 2+4*DELTA) return Q_FULL_T; /* full  */
	if (n ==   5*DELTA) return GLOBAL;
	if (n ==   6*DELTA) return TIMEOUT_F;
	if (n ==   7*DELTA) return ALPHA_F;
	Uerror("cannot happen srinc_class");
	return BAD;
}
int
srunc(int n, int m)
{	switch(m) {
	case Q_FULL_F: return n-2;
	case Q_EMPT_F: return n-2-DELTA;
	case Q_EMPT_T: return n-2-2*DELTA;
	case Q_FULL_T: return n-2-3*DELTA;
	case ALPHA_F:
	case TIMEOUT_F: return 257; /* non-zero, and > MAXQ */
	}
	Uerror("cannot happen srunc");
	return 0;
}
#endif
int cnt;
#ifdef HAS_UNLESS
int
isthere(Trans *a, int b)
{	Trans *t;
	for (t = a; t; t = t->nxt)
		if (t->t_id == b)
			return 1;
	return 0;
}
#endif
#ifndef NOREDUCE
int
mark_safety(Trans *t) /* for conditional safety */
{	int g = 0, i, j, k;

	if (!t) return 0;
	if (t->qu[0])
		return (t->qu[1])?2:1;	/* marked */

	for (i = 0; i < 2; i++)
	{	j = srinc_set(t->tpe[i]);
		if (j >= GLOBAL && j != ALPHA_F)
			return -1;
		if (j != LOCAL)
		{	k = srunc(t->tpe[i], j);
			if (g == 0
			||  t->qu[0] != k
			||  t->ty[0] != j)
			{	t->qu[g] = k;
				t->ty[g] = j;
				g++;
	}	}	}
	return g;
}
#endif
void
retrans(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
	/* process n, with m states, is=initial state */
{	Trans *T0, *T1, *T2, *T3;
	Trans *T4, *T5; /* t_reverse or has_unless */
	int i;
#if defined(HAS_UNLESS) || !defined(NOREDUCE)
	int k;
#endif
#ifndef NOREDUCE
	int g, h, j, aa;
#endif
#ifdef HAS_UNLESS
	int p;
#endif
	if (state_tables >= 4)
	{	printf("STEP 1 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
	do {
		for (i = 1, cnt = 0; i < m; i++)
		{	T2 = trans[n][i];
			T1 = T2?T2->nxt:(Trans *)0;
/* prescan: */		for (T0 = T1; T0; T0 = T0->nxt)
/* choice in choice */	{	if (T0->st && trans[n][T0->st]
				&&  trans[n][T0->st]->nxt)
					break;
			}
#if 0
		if (T0)
		printf("\tstate %d / %d: choice in choice\n",
		i, T0->st);
#endif
			if (T0)
			for (T0 = T1; T0; T0 = T0->nxt)
			{	T3 = trans[n][T0->st];
				if (!T3->nxt)
				{	T2->nxt = cpytr(T0);
					T2 = T2->nxt;
					imed(T2, T0->st, n, i);
					continue;
				}
				do {	T3 = T3->nxt;
					T2->nxt = cpytr(T3);
					T2 = T2->nxt;
					imed(T2, T0->st, n, i);
				} while (T3->nxt);
				cnt++;
			}
		}
	} while (cnt);
	if (state_tables >= 3)
	{	printf("STEP 2 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
	for (i = 1; i < m; i++)
	{	if (trans[n][i] && trans[n][i]->nxt) /* optimize */
		{	T1 = trans[n][i]->nxt;
#if 0
			printf("\t\tpull %d (%d) to %d\n",
			T1->st, T1->forw, i);
#endif
			srcln[i] = srcln[T1->st];	/* Oyvind Teig, 5.2.0 */

			if (!trans[n][T1->st]) continue;
			T0 = cpytr(trans[n][T1->st]);
			trans[n][i] = T0;
			reach[T1->st] = 1;
			imed(T0, T1->st, n, i);
			for (T1 = T1->nxt; T1; T1 = T1->nxt)
			{
#if 0
			printf("\t\tpull %d (%d) to %d\n",
				T1->st, T1->forw, i);
#endif
		/*		srcln[i] = srcln[T1->st];  gh: not useful */
				if (!trans[n][T1->st]) continue;
				T0->nxt = cpytr(trans[n][T1->st]);
				T0 = T0->nxt;
				reach[T1->st] = 1;
				imed(T0, T1->st, n, i);
	}	}	}
	if (state_tables >= 2)
	{	printf("STEP 3 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
#ifdef HAS_UNLESS
	for (i = 1; i < m; i++)
	{	if (!trans[n][i]) continue;
		/* check for each state i if an
		 * escape to some state p is defined
		 * if so, copy and mark p's transitions
		 * and prepend them to the transition-
		 * list of state i
		 */
	 if (!like_java) /* the default */
	 {	for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		for (k = HAS_UNLESS-1; k >= 0; k--)
		{	if (p = T0->escp[k])
			for (T1 = trans[n][p]; T1; T1 = T1->nxt)
			{	if (isthere(trans[n][i], T1->t_id))
					continue;
				T2 = cpytr(T1);
				T2->e_trans = p;
				T2->nxt = trans[n][i];
				trans[n][i] = T2;
		}	}
	 } else /* outermost unless checked first */
	 {	T4 = T3 = (Trans *) 0;
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		for (k = HAS_UNLESS-1; k >= 0; k--)
		{	if (p = T0->escp[k])
			for (T1 = trans[n][p]; T1; T1 = T1->nxt)
			{	if (isthere(trans[n][i], T1->t_id))
					continue;
				T2 = cpytr(T1);
				T2->nxt = (Trans *) 0;
				T2->e_trans = p;
				if (T3)	T3->nxt = T2;
				else	T4 = T2;
				T3 = T2;
		}	}
		if (T4)
		{	T3->nxt = trans[n][i];
			trans[n][i] = T4;
		}
	 }
	}
#endif
#ifndef NOREDUCE
	for (i = 1; i < m; i++)
	{	if (a_cycles)
		{ /* moves through these states are visible */
	#if PROG_LAB>0 && defined(HAS_NP)
			if (progstate[n][i])
				goto degrade;
			for (T1 = trans[n][i]; T1; T1 = T1->nxt)
				if (progstate[n][T1->st])
					goto degrade;
	#endif
			if (accpstate[n][i] || visstate[n][i])
				goto degrade;
			for (T1 = trans[n][i]; T1; T1 = T1->nxt)
				if (accpstate[n][T1->st])
					goto degrade;
		}
		T1 = trans[n][i];
		if (!T1) continue;
		g = mark_safety(T1);	/* V3.3.1 */
		if (g < 0) goto degrade; /* global */
		/* check if mixing of guards preserves reduction */
		if (T1->nxt)
		{	k = 0;
			for (T0 = T1; T0; T0 = T0->nxt)
			{	if (!(T0->atom&8))
					goto degrade;
				for (aa = 0; aa < 2; aa++)
				{	j = srinc_set(T0->tpe[aa]);
					if (j >= GLOBAL && j != ALPHA_F)
						goto degrade;
					if (T0->tpe[aa]
					&&  T0->tpe[aa]
					!=  T1->tpe[0])
						k = 1;
			}	}
			/* g = 0;	V3.3.1 */
			if (k)	/* non-uniform selection */
			for (T0 = T1; T0; T0 = T0->nxt)
			for (aa = 0; aa < 2; aa++)
			{	j = srinc_set(T0->tpe[aa]);
				if (j != LOCAL)
				{	k = srunc(T0->tpe[aa], j);
					for (h = 0; h < 6; h++)
						if (T1->qu[h] == k
						&&  T1->ty[h] == j)
							break;
					if (h >= 6)
					{	T1->qu[g%6] = k;
						T1->ty[g%6] = j;
						g++;
			}	}	}
			if (g > 6)
			{	T1->qu[0] = 0;	/* turn it off */
				printf("pan: warning, line %d, ",
					srcln[i]);
			 	printf("too many stmnt types (%d)",
					g);
			  	printf(" in selection\n");
			  goto degrade;
			}
		}
		/* mark all options global if >=1 is global */
		for (T1 = trans[n][i]; T1; T1 = T1->nxt)
			if (!(T1->atom&8)) break;
		if (T1)
degrade:	for (T1 = trans[n][i]; T1; T1 = T1->nxt)
			T1->atom &= ~8;	/* mark as unsafe */
		/* can only mix 'r's or 's's if on same chan */
		/* and not mixed with other local operations */
		T1 = trans[n][i];
		if (!T1 || T1->qu[0]) continue;
		j = T1->tpe[0];
		if (T1->nxt && T1->atom&8)
		{ if (j == 5*DELTA)
		  {	printf("warning: line %d ", srcln[i]);
			printf("mixed condition ");
			printf("(defeats reduction)\n");
			goto degrade;
		  }
		  for (T0 = T1; T0; T0 = T0->nxt)
		  for (aa = 0; aa < 2; aa++)
		  if  (T0->tpe[aa] && T0->tpe[aa] != j)
		  {	printf("warning: line %d ", srcln[i]);
			printf("[%d-%d] mixed %stion ",
				T0->tpe[aa], j, 
				(j==5*DELTA)?"condi":"selec");
			printf("(defeats reduction)\n");
			printf("	'%s' <-> '%s'\n",
				T1->tp, T0->tp);
			goto degrade;
		} }
	}
#endif
	for (i = 1; i < m; i++)
	{	T2 = trans[n][i];
		if (!T2
		||  T2->nxt
		||  strncmp(T2->tp, ".(goto)", 7)
		||  !stopstate[n][i])
			continue;
		stopstate[n][T2->st] = 1;
	}
	if (state_tables && !verbose)
	{	if (dodot)
		{	char buf[256], *q = buf, *p = procname[n];
			while (*p != '\0')
			{	if (*p != ':')
				{	*q++ = *p;
				}
				p++;
			}
			*q = '\0';
			printf("digraph ");
			switch (Btypes[n]) {
			case I_PROC:  printf("init {\n"); break;
			case N_CLAIM: printf("claim_%s {\n", buf); break;
			case E_TRACE: printf("notrace {\n"); break;
			case N_TRACE: printf("trace {\n"); break;
			default:      printf("p_%s {\n", buf); break;
			}
			printf("size=\"8,10\";\n");
			printf("  GT [shape=box,style=dotted,label=\"%s\"];\n", buf);
			printf("  GT -> S%d;\n", is);
		} else
		{	switch (Btypes[n]) {
			case I_PROC:  printf("init\n"); break;
			case N_CLAIM: printf("claim %s\n", procname[n]); break;
			case E_TRACE: printf("notrace assertion\n"); break;
			case N_TRACE: printf("trace assertion\n"); break;
			default:      printf("proctype %s\n", procname[n]); break;
		}	}
		for (i = 1; i < m; i++)
		{	reach[i] = 1;
		}
		tagtable(n, m, is, srcln, reach);
		if (dodot) printf("}\n");
	} else
	for (i = 1; i < m; i++)
	{	int nrelse;
		if (Btypes[n] != N_CLAIM)
		{	for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			{	if (T0->st == i
				&& strcmp(T0->tp, "(1)") == 0)
				{	printf("error: proctype '%s' ",
						procname[n]);
		  			printf("line %d, state %d: has un",
						srcln[i], i);
					printf("conditional self-loop\n");
					pan_exit(1);
		}	}	}
		nrelse = 0;
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		{	if (strcmp(T0->tp, "else") == 0)
				nrelse++;
		}
		if (nrelse > 1)
		{	printf("error: proctype '%s' state",
				procname[n]);
		  	printf(" %d, inherits %d", i, nrelse);
		  	printf(" 'else' stmnts\n");
			pan_exit(1);
	}	}
#if !defined(LOOPSTATE) && !defined(BFS_PAR)
	if (state_tables)
#endif
	do_dfs(n, m, is, srcln, reach, lpstate);

	if (!t_reverse)
	{	return;
	}
	/* process n, with m states, is=initial state -- reverse list */
	if (!state_tables && Btypes[n] != N_CLAIM)
	{	for (i = 1; i < m; i++)
		{	Trans *Tx = (Trans *) 0; /* list of escapes */
			Trans *Ty = (Trans *) 0; /* its tail element */
			T1 = (Trans *) 0; /* reversed list */
			T2 = (Trans *) 0; /* its tail */
			T3 = (Trans *) 0; /* remembers possible 'else' */

			/* find unless-escapes, they should go first */
			T4 = T5 = T0 = trans[n][i];
	#ifdef HAS_UNLESS
			while (T4 && T4->e_trans) /* escapes are first in orig list */
			{	T5 = T4;	  /* remember predecessor */
				T4 = T4->nxt;
			}
	#endif
			/* T4 points to first non-escape, T5 to its parent, T0 to original list */
			if (T4 != T0)		 /* there was at least one escape */
			{	T3 = T5->nxt;		 /* start of non-escapes */
				T5->nxt = (Trans *) 0;	 /* separate */
				Tx = T0;		 /* start of the escapes */
				Ty = T5;		 /* its tail */
				T0 = T3;		 /* the rest, to be reversed */
			}
			/* T0 points to first non-escape, Tx to the list of escapes, Ty to its tail */

			/* first tail-add non-escape transitions, reversed */
			T3 = (Trans *) 0;
			for (T5 = T0; T5; T5 = T4)
			{	T4 = T5->nxt;
	#ifdef HAS_UNLESS
				if (T5->e_trans)
				{	printf("error: cannot happen!\n");
					continue;
				}
	#endif
				if (strcmp(T5->tp, "else") == 0)
				{	T3 = T5;
					T5->nxt = (Trans *) 0;
				} else
				{	T5->nxt = T1;
					if (!T1) { T2 = T5; }
					T1 = T5;
			}	}
			/* T3 points to a possible else, which is removed from the list */
			/* T1 points to the reversed list so far (without escapes) */
			/* T2 points to the tail element -- where the else should go */
			if (T2 && T3)
			{	T2->nxt = T3;	/* add else */
			} else
			{	if (T3) /* there was an else, but there's no tail */
				{	if (!T1)	/* and no reversed list */
					{	T1 = T3; /* odd, but possible */
					} else		/* even stranger */
					{	T1->nxt = T3;
			}	}	}

			/* add in the escapes, to that they appear at the front */
			if (Tx && Ty) { Ty->nxt = T1; T1 = Tx; }

			trans[n][i] = T1;
			/* reversed, with escapes first and else last */
	}	}
	if (state_tables && verbose)
	{	printf("FINAL proctype %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
	}
}
void
imed(Trans *T, int v, int n, int j)	/* set intermediate state */
{	progstate[n][T->st] |= progstate[n][v];
	accpstate[n][T->st] |= accpstate[n][v];
	stopstate[n][T->st] |= stopstate[n][v];
	mapstate[n][j] = T->st;
}
void
tagtable(int n, int m, int is, short srcln[], uchar reach[])
{	Trans *z;

	if (is >= m || !trans[n][is]
	||  is <= 0 || reach[is] == 0)
		return;
	reach[is] = 0;
	if (state_tables)
	for (z = trans[n][is]; z; z = z->nxt)
	{	if (dodot)
			dot_crack(n, is, z);
		else
			crack(n, is, z, srcln);
	}

	for (z = trans[n][is]; z; z = z->nxt)
	{
#ifdef HAS_UNLESS
		int i, j;
#endif
		tagtable(n, m, z->st, srcln, reach);
#ifdef HAS_UNLESS
		for (i = 0; i < HAS_UNLESS; i++)
		{	j = trans[n][is]->escp[i];
			if (!j) break;
			tagtable(n, m, j, srcln, reach);
		}
#endif
	}
}

extern Trans *t_id_lkup[];

void
dfs_table(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
{	Trans *z;

	if (is >= m || is <= 0 || !trans[n][is])
		return;
	if ((reach[is] & (4|8|16)) != 0)
	{	if ((reach[is] & (8|16)) == 16)	/* on stack, not yet recorded */
		{	lpstate[is] = 1;
			reach[is] |= 8; /* recorded */
			if (state_tables && verbose)
			{	printf("state %d line %d is a loopstate\n", is, srcln[is]);
		}	}
		return;
	}
	reach[is] |= (4|16);	/* visited | onstack */
	for (z = trans[n][is]; z; z = z->nxt)
	{	t_id_lkup[z->t_id] = z;
#ifdef HAS_UNLESS
		int i, j;
#endif
		dfs_table(n, m, z->st, srcln, reach, lpstate);
#ifdef HAS_UNLESS
		for (i = 0; i < HAS_UNLESS; i++)
		{	j = trans[n][is]->escp[i];
			if (!j) break;
			dfs_table(n, m, j, srcln, reach, lpstate);
		}
#endif
	}
	reach[is] &= ~16; /* no longer on stack */
}
void
do_dfs(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
{	int i;
	dfs_table(n, m, is, srcln, reach, lpstate);
	for (i = 0; i < m; i++)
		reach[i] &= ~(4|8|16);
}
void
crack(int n, int j, Trans *z, short srcln[])
{	int i;

	if (!z) return;
	printf("	state %3d -(tr %3d)-> state %3d  ",
		j, z->forw, z->st);
	printf("[id %3d tp %3d", z->t_id, z->tpe[0]);
	if (z->tpe[1]) printf(",%d", z->tpe[1]);
#ifdef HAS_UNLESS
	if (z->e_trans)
		printf(" org %3d", z->e_trans);
	else if (state_tables >= 2)
	for (i = 0; i < HAS_UNLESS; i++)
	{	if (!z->escp[i]) break;
		printf(" esc %d", z->escp[i]);
	}
#endif
	printf("]");
	printf(" [%s%s%s%s%s] %s:%d => ",
		z->atom&6?"A":z->atom&32?"D":"-",
		accpstate[n][j]?"a" :"-",
		stopstate[n][j]?"e" : "-",
		progstate[n][j]?"p" : "-",
		z->atom & 8 ?"L":"G",
		PanSource, srcln[j]);
	for (i = 0; z->tp[i]; i++)
		if (z->tp[i] == '\n')
			printf("\\n");
		else
			putchar(z->tp[i]);
	if (verbose && z->qu[0])
	{	printf("\t[");
		for (i = 0; i < 6; i++)
			if (z->qu[i])
				printf("(%d,%d)",
				z->qu[i], z->ty[i]);
		printf("]");
	}
	printf("\n");
	fflush(stdout);
}
/* spin -a m.pml; cc -o pan pan.c; ./pan -D | dot -Tps > foo.ps; ps2pdf foo.ps */
void
dot_crack(int n, int j, Trans *z)
{	int i;

	if (!z) return;
	printf("	S%d -> S%d  [color=black", j, z->st);

	if (z->atom&6) printf(",style=dashed");
	else if (z->atom&32) printf(",style=dotted");
	else if (z->atom&8) printf(",style=solid");
	else printf(",style=bold");

	printf(",label=\"");
	for (i = 0; z->tp[i]; i++)
	{	if (z->tp[i] == '\\'
		&&  z->tp[i+1] == 'n')
		{	i++; printf(" ");
		} else
		{	putchar(z->tp[i]);
	}	}
	printf("\"];\n");
	if (accpstate[n][j]) printf("  S%d [color=red,style=bold];\n", j);
	else if (progstate[n][j]) printf("  S%d [color=green,style=bold];\n", j);
	if (stopstate[n][j]) printf("  S%d [color=blue,style=bold,shape=box];\n", j);
}

#ifdef VAR_RANGES
#define BYTESIZE	32	/* 2^8 : 2^3 = 256:8 = 32 */

typedef struct Vr_Ptr {
	char	*nm;
	uchar	vals[BYTESIZE];
	struct Vr_Ptr *nxt;
} Vr_Ptr;
Vr_Ptr *ranges = (Vr_Ptr *) 0;

void
logval(char *s, int v)
{	Vr_Ptr *tmp;

	if (v<0 || v > 255) return;
	for (tmp = ranges; tmp; tmp = tmp->nxt)
		if (!strcmp(tmp->nm, s))
			goto found;
	tmp = (Vr_Ptr *) emalloc(sizeof(Vr_Ptr));
	tmp->nxt = ranges;
	ranges = tmp;
	tmp->nm = s;
found:
	tmp->vals[(v)/8] |= 1<<((v)%8);
}

void
dumpval(uchar X[], int range)
{	int w, x, i, j = -1;

	for (w = i = 0; w < range; w++)
	for (x = 0; x < 8; x++, i++)
	{
from:		if ((X[w] & (1<<x)))
		{	printf("%d", i);
			j = i;
			goto upto;
	}	}
	return;
	for (w = 0; w < range; w++)
	for (x = 0; x < 8; x++, i++)
	{
upto:		if (!(X[w] & (1<<x)))
		{	if (i-1 == j)
				printf(", ");
			else
				printf("-%d, ", i-1);
			goto from;
	}	}
	if (j >= 0 && j != 255)
		printf("-255");
}

void
dumpranges(void)
{	Vr_Ptr *tmp;
	printf("\nValues assigned within ");
	printf("interval [0..255]:\n");
	for (tmp = ranges; tmp; tmp = tmp->nxt)
	{	printf("\t%s\t: ", tmp->nm);
		dumpval(tmp->vals, BYTESIZE);
		printf("\n");
	}
}
#endif
