#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM privacy_response_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(finished))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[5][1] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[5][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - privacy-response.pml:338 - [(run Handler())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][1] = 1;
		if (!(addproc(II, 1, 3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - privacy-response.pml:338 - [(run Endpoint())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][2] = 1;
		if (!(addproc(II, 1, 2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 3 - privacy-response.pml:338 - [(run Revoke())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][3] = 1;
		if (!(addproc(II, 1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 4 - privacy-response.pml:338 - [(run Crash())] (0:0:0 - 1)
		IfNotBlocked
		reached[4][4] = 1;
		if (!(addproc(II, 1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 6 - privacy-response.pml:339 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[4][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Handler */
	case 10: // STATE 1 - privacy-response.pml:117 - [reason = Privacy] (0:22:3 - 1)
		IfNotBlocked
		reached[3][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = reason;
		reason = 14;
#ifdef VAR_RANGES
		logval("reason", reason);
#endif
		;
		/* merge: required_route = 1(22, 2, 22) */
		reached[3][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.required_route);
		now.required_route = 1;
#ifdef VAR_RANGES
		logval("required_route", ((int)now.required_route));
#endif
		;
		/* merge: .(goto)(22, 8, 22) */
		reached[3][8] = 1;
		;
		/* merge: route = required_route(22, 9, 22) */
		reached[3][9] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.route);
		now.route = ((int)now.required_route);
#ifdef VAR_RANGES
		logval("route", ((int)now.route));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 11: // STATE 3 - privacy-response.pml:118 - [reason = Secret] (0:22:3 - 1)
		IfNotBlocked
		reached[3][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = reason;
		reason = 13;
#ifdef VAR_RANGES
		logval("reason", reason);
#endif
		;
		/* merge: required_route = 2(22, 4, 22) */
		reached[3][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.required_route);
		now.required_route = 2;
#ifdef VAR_RANGES
		logval("required_route", ((int)now.required_route));
#endif
		;
		/* merge: .(goto)(22, 8, 22) */
		reached[3][8] = 1;
		;
		/* merge: route = required_route(22, 9, 22) */
		reached[3][9] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.route);
		now.route = ((int)now.required_route);
#ifdef VAR_RANGES
		logval("route", ((int)now.route));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 12: // STATE 5 - privacy-response.pml:119 - [reason = Coverage] (0:22:3 - 1)
		IfNotBlocked
		reached[3][5] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = reason;
		reason = 12;
#ifdef VAR_RANGES
		logval("reason", reason);
#endif
		;
		/* merge: required_route = 3(22, 6, 22) */
		reached[3][6] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.required_route);
		now.required_route = 3;
#ifdef VAR_RANGES
		logval("required_route", ((int)now.required_route));
#endif
		;
		/* merge: .(goto)(22, 8, 22) */
		reached[3][8] = 1;
		;
		/* merge: route = required_route(22, 9, 22) */
		reached[3][9] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.route);
		now.route = ((int)now.required_route);
#ifdef VAR_RANGES
		logval("route", ((int)now.route));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 13: // STATE 9 - privacy-response.pml:121 - [route = required_route] (0:22:1 - 4)
		IfNotBlocked
		reached[3][9] = 1;
		(trpt+1)->bup.oval = ((int)now.route);
		now.route = ((int)now.required_route);
#ifdef VAR_RANGES
		logval("route", ((int)now.route));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 10 - privacy-response.pml:56 - [assert(((intent_calls<=1)&&(notification_calls<=1)))] (0:307:0 - 1)
		IfNotBlocked
		reached[3][10] = 1;
		spin_assert(((((int)now.intent_calls)<=1)&&(((int)now.notification_calls)<=1)), "((intent_calls<=1)&&(notification_calls<=1))", II, tt, t);
		/* merge: assert((route==required_route))(307, 11, 307) */
		reached[3][11] = 1;
		spin_assert((((int)now.route)==((int)now.required_route)), "(route==required_route)", II, tt, t);
		/* merge: assert(((frozen_route==0)||(frozen_route==required_route)))(307, 12, 307) */
		reached[3][12] = 1;
		spin_assert(((((int)now.frozen_route)==0)||(((int)now.frozen_route)==((int)now.required_route))), "((frozen_route==0)||(frozen_route==required_route))", II, tt, t);
		/* merge: assert(((frozen_event==0)||(frozen_event==1)))(307, 13, 307) */
		reached[3][13] = 1;
		spin_assert(((((int)now.frozen_event)==0)||(((int)now.frozen_event)==1)), "((frozen_event==0)||(frozen_event==1))", II, tt, t);
		/* merge: assert(((frozen_destination==0)||(frozen_destination==1)))(307, 14, 307) */
		reached[3][14] = 1;
		spin_assert(((((int)now.frozen_destination)==0)||(((int)now.frozen_destination)==1)), "((frozen_destination==0)||(frozen_destination==1))", II, tt, t);
		/* merge: assert((!(intent_receipt)||(intent_state==Completed)))(307, 15, 307) */
		reached[3][15] = 1;
		spin_assert(( !(((int)now.intent_receipt))||(now.intent_state==16)), "( !(intent_receipt)||(intent_state==16))", II, tt, t);
		/* merge: assert((!(notification_receipt)||(notification_state==Completed)))(307, 16, 307) */
		reached[3][16] = 1;
		spin_assert(( !(((int)now.notification_receipt))||(now.notification_state==16)), "( !(notification_receipt)||(notification_state==16))", II, tt, t);
		/* merge: assert(((notification_calls==0)||(intent_receipt&&intent_exposed)))(307, 17, 307) */
		reached[3][17] = 1;
		spin_assert(((((int)now.notification_calls)==0)||(((int)now.intent_receipt)&&((int)now.intent_exposed))), "((notification_calls==0)||(intent_receipt&&intent_exposed))", II, tt, t);
		/* merge: assert((!(notification_receipt)||(provider_outcome==sealed_outcome)))(307, 18, 307) */
		reached[3][18] = 1;
		spin_assert(( !(((int)now.notification_receipt))||(now.provider_outcome==now.sealed_outcome)), "( !(notification_receipt)||(provider_outcome==sealed_outcome))", II, tt, t);
		/* merge: assert((!(notification_receipt)||(provider_outcome==observed_outcome)))(307, 19, 307) */
		reached[3][19] = 1;
		spin_assert(( !(((int)now.notification_receipt))||(now.provider_outcome==now.observed_outcome)), "( !(notification_receipt)||(provider_outcome==observed_outcome))", II, tt, t);
		/* merge: assert(!(recipient_delivery_known))(307, 20, 307) */
		reached[3][20] = 1;
		spin_assert( !(((int)now.recipient_delivery_known)), " !(recipient_delivery_known)", II, tt, t);
		/* merge: assert((!(replayed)||((intent_calls==sealed_intent_calls)&&(notification_calls==sealed_notification_calls))))(307, 21, 307) */
		reached[3][21] = 1;
		spin_assert(( !(((int)now.replayed))||((((int)now.intent_calls)==((int)now.sealed_intent_calls))&&(((int)now.notification_calls)==((int)now.sealed_notification_calls)))), "( !(replayed)||((intent_calls==sealed_intent_calls)&&(notification_calls==sealed_notification_calls)))", II, tt, t);
		/* merge: .(goto)(0, 308, 307) */
		reached[3][308] = 1;
		;
		_m = 3; goto P999; /* 12 */
	case 15: // STATE 24 - privacy-response.pml:128 - [(finished)] (0:0:0 - 1)
		IfNotBlocked
		reached[3][24] = 1;
		if (!(((int)now.finished)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 26 - privacy-response.pml:129 - [(!(finished))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][26] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 27 - privacy-response.pml:131 - [(crash)] (98:0:2 - 1)
		IfNotBlocked
		reached[3][27] = 1;
		if (!(((int)now.crash)))
			continue;
		/* merge: crash = 0(98, 28, 98) */
		reached[3][28] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.crash);
		now.crash = 0;
#ifdef VAR_RANGES
		logval("crash", ((int)now.crash));
#endif
		;
		/* merge: restarted = 1(98, 29, 98) */
		reached[3][29] = 1;
		(trpt+1)->bup.ovals[1] = ((int)restarted);
		restarted = 1;
#ifdef VAR_RANGES
		logval("restarted", ((int)restarted));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 18: // STATE 30 - privacy-response.pml:134 - [((intent_state==Executing))] (55:0:2 - 1)
		IfNotBlocked
		reached[3][30] = 1;
		if (!((now.intent_state==17)))
			continue;
		/* merge: intent_state = Unknown(55, 31, 55) */
		reached[3][31] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.intent_state;
		now.intent_state = 15;
#ifdef VAR_RANGES
		logval("intent_state", now.intent_state);
#endif
		;
		/* merge: terminal = Blocked(55, 32, 55) */
		reached[3][32] = 1;
		(trpt+1)->bup.ovals[1] = terminal;
		terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 19: // STATE 33 - privacy-response.pml:103 - [(replayed)] (305:0:1 - 1)
		IfNotBlocked
		reached[3][33] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 34, 305) */
		reached[3][34] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 54, 305) */
		reached[3][54] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 20: // STATE 35 - privacy-response.pml:104 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][35] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 36 - privacy-response.pml:105 - [attempt_event = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][36] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 1;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 37 - privacy-response.pml:105 - [attempt_event = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][37] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 2;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 40 - privacy-response.pml:106 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][40] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 41 - privacy-response.pml:106 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][41] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 44 - privacy-response.pml:107 - [attempt_destination = 1] (0:305:6 - 1)
		IfNotBlocked
		reached[3][44] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 1;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 47, 305) */
		reached[3][47] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 48, 305) */
		reached[3][48] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 49, 305) */
		reached[3][49] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 50, 305) */
		reached[3][50] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 51, 305) */
		reached[3][51] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 52, 305) */
		reached[3][52] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 54, 305) */
		reached[3][54] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 26: // STATE 45 - privacy-response.pml:107 - [attempt_destination = 2] (0:305:6 - 1)
		IfNotBlocked
		reached[3][45] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 2;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 47, 305) */
		reached[3][47] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 48, 305) */
		reached[3][48] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 49, 305) */
		reached[3][49] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 50, 305) */
		reached[3][50] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 51, 305) */
		reached[3][51] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 52, 305) */
		reached[3][52] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 54, 305) */
		reached[3][54] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 27: // STATE 48 - privacy-response.pml:108 - [sealed_intent_calls = intent_calls] (0:305:5 - 3)
		IfNotBlocked
		reached[3][48] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 49, 305) */
		reached[3][49] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 50, 305) */
		reached[3][50] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 51, 305) */
		reached[3][51] = 1;
		(trpt+1)->bup.ovals[3] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 52, 305) */
		reached[3][52] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 54, 305) */
		reached[3][54] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 28: // STATE 56 - privacy-response.pml:136 - [((notification_state==Executing))] (81:0:2 - 1)
		IfNotBlocked
		reached[3][56] = 1;
		if (!((now.notification_state==17)))
			continue;
		/* merge: notification_state = Unknown(81, 57, 81) */
		reached[3][57] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.notification_state;
		now.notification_state = 15;
#ifdef VAR_RANGES
		logval("notification_state", now.notification_state);
#endif
		;
		/* merge: terminal = Blocked(81, 58, 81) */
		reached[3][58] = 1;
		(trpt+1)->bup.ovals[1] = terminal;
		terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 29: // STATE 59 - privacy-response.pml:103 - [(replayed)] (305:0:1 - 1)
		IfNotBlocked
		reached[3][59] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 60, 305) */
		reached[3][60] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 80, 305) */
		reached[3][80] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 30: // STATE 61 - privacy-response.pml:104 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][61] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 62 - privacy-response.pml:105 - [attempt_event = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][62] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 1;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 63 - privacy-response.pml:105 - [attempt_event = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][63] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 2;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 66 - privacy-response.pml:106 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][66] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 34: // STATE 67 - privacy-response.pml:106 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][67] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 35: // STATE 70 - privacy-response.pml:107 - [attempt_destination = 1] (0:305:6 - 1)
		IfNotBlocked
		reached[3][70] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 1;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 73, 305) */
		reached[3][73] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 74, 305) */
		reached[3][74] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 75, 305) */
		reached[3][75] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 76, 305) */
		reached[3][76] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 77, 305) */
		reached[3][77] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 78, 305) */
		reached[3][78] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 80, 305) */
		reached[3][80] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 36: // STATE 71 - privacy-response.pml:107 - [attempt_destination = 2] (0:305:6 - 1)
		IfNotBlocked
		reached[3][71] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 2;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 73, 305) */
		reached[3][73] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 74, 305) */
		reached[3][74] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 75, 305) */
		reached[3][75] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 76, 305) */
		reached[3][76] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 77, 305) */
		reached[3][77] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 78, 305) */
		reached[3][78] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 80, 305) */
		reached[3][80] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 37: // STATE 74 - privacy-response.pml:108 - [sealed_intent_calls = intent_calls] (0:305:5 - 3)
		IfNotBlocked
		reached[3][74] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 75, 305) */
		reached[3][75] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 76, 305) */
		reached[3][76] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 77, 305) */
		reached[3][77] = 1;
		(trpt+1)->bup.ovals[3] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 78, 305) */
		reached[3][78] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 80, 305) */
		reached[3][80] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 38: // STATE 82 - privacy-response.pml:139 - [(((intent_state==Unknown)||(notification_state==Unknown)))] (305:0:2 - 1)
		IfNotBlocked
		reached[3][82] = 1;
		if (!(((now.intent_state==15)||(now.notification_state==15))))
			continue;
		/* merge: terminal = Blocked(305, 83, 305) */
		reached[3][83] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = terminal;
		terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: finished = 1(305, 84, 305) */
		reached[3][84] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 39: // STATE 86 - privacy-response.pml:143 - [(((intent_state==Completed)&&(notification_state==Empty)))] (96:0:1 - 1)
		IfNotBlocked
		reached[3][86] = 1;
		if (!(((now.intent_state==16)&&(now.notification_state==18))))
			continue;
		/* merge: crashed_between_effects = 1(0, 87, 96) */
		reached[3][87] = 1;
		(trpt+1)->bup.oval = ((int)crashed_between_effects);
		crashed_between_effects = 1;
#ifdef VAR_RANGES
		logval("crashed_between_effects", ((int)crashed_between_effects));
#endif
		;
		/* merge: .(goto)(0, 91, 96) */
		reached[3][91] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 40: // STATE 92 - privacy-response.pml:149 - [(replayed)] (305:0:1 - 1)
		IfNotBlocked
		reached[3][92] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: pc = 20(0, 93, 305) */
		reached[3][93] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 97, 305) */
		reached[3][97] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 41: // STATE 94 - privacy-response.pml:149 - [(!(replayed))] (305:0:1 - 1)
		IfNotBlocked
		reached[3][94] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		/* merge: pc = 0(0, 95, 305) */
		reached[3][95] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 97, 305) */
		reached[3][97] = 1;
		;
		/* merge: .(goto)(0, 99, 305) */
		reached[3][99] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 42: // STATE 100 - privacy-response.pml:152 - [(!(crash))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][100] = 1;
		if (!( !(((int)now.crash))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 43: // STATE 101 - privacy-response.pml:154 - [((pc==0))] (113:0:1 - 1)
		IfNotBlocked
		reached[3][101] = 1;
		if (!((((int)now.pc)==0)))
			continue;
		/* merge: admission_check = rights(0, 102, 113) */
		reached[3][102] = 1;
		(trpt+1)->bup.oval = ((int)now.admission_check);
		now.admission_check = ((int)now.rights);
#ifdef VAR_RANGES
		logval("admission_check", ((int)now.admission_check));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 44: // STATE 103 - privacy-response.pml:157 - [(!(admission_check))] (305:0:2 - 1)
		IfNotBlocked
		reached[3][103] = 1;
		if (!( !(((int)now.admission_check))))
			continue;
		/* merge: terminal = Denied(305, 104, 305) */
		reached[3][104] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = terminal;
		terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: finished = 1(305, 105, 305) */
		reached[3][105] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 114, 305) */
		reached[3][114] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 45: // STATE 106 - privacy-response.pml:158 - [(admission_check)] (0:0:0 - 1)
		IfNotBlocked
		reached[3][106] = 1;
		if (!(((int)now.admission_check)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 46: // STATE 107 - privacy-response.pml:160 - [((intent_state==Completed))] (305:0:1 - 1)
		IfNotBlocked
		reached[3][107] = 1;
		if (!((now.intent_state==16)))
			continue;
		/* merge: pc = 4(0, 108, 305) */
		reached[3][108] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 112, 305) */
		reached[3][112] = 1;
		;
		/* merge: .(goto)(0, 114, 305) */
		reached[3][114] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 47: // STATE 109 - privacy-response.pml:161 - [((intent_state==Empty))] (305:0:1 - 1)
		IfNotBlocked
		reached[3][109] = 1;
		if (!((now.intent_state==18)))
			continue;
		/* merge: pc = 1(0, 110, 305) */
		reached[3][110] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 112, 305) */
		reached[3][112] = 1;
		;
		/* merge: .(goto)(0, 114, 305) */
		reached[3][114] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 48: // STATE 115 - privacy-response.pml:169 - [((pc==1))] (305:0:5 - 1)
		IfNotBlocked
		reached[3][115] = 1;
		if (!((((int)now.pc)==1)))
			continue;
		/* merge: assert(admission_check)(305, 116, 305) */
		reached[3][116] = 1;
		spin_assert(((int)now.admission_check), "admission_check", II, tt, t);
		/* merge: frozen_event = 1(305, 117, 305) */
		reached[3][117] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)now.frozen_event);
		now.frozen_event = 1;
#ifdef VAR_RANGES
		logval("frozen_event", ((int)now.frozen_event));
#endif
		;
		/* merge: frozen_route = route(305, 118, 305) */
		reached[3][118] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.frozen_route);
		now.frozen_route = ((int)now.route);
#ifdef VAR_RANGES
		logval("frozen_route", ((int)now.frozen_route));
#endif
		;
		/* merge: frozen_destination = 1(305, 119, 305) */
		reached[3][119] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.frozen_destination);
		now.frozen_destination = 1;
#ifdef VAR_RANGES
		logval("frozen_destination", ((int)now.frozen_destination));
#endif
		;
		/* merge: intent_state = Executing(305, 120, 305) */
		reached[3][120] = 1;
		(trpt+1)->bup.ovals[3] = now.intent_state;
		now.intent_state = 17;
#ifdef VAR_RANGES
		logval("intent_state", now.intent_state);
#endif
		;
		/* merge: pc = 2(305, 121, 305) */
		reached[3][121] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.pc);
		now.pc = 2;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 49: // STATE 122 - privacy-response.pml:174 - [((pc==2))] (305:0:2 - 1)
		IfNotBlocked
		reached[3][122] = 1;
		if (!((((int)now.pc)==2)))
			continue;
		/* merge: intent_calls = (intent_calls+1)(305, 123, 305) */
		reached[3][123] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.intent_calls);
		now.intent_calls = (((int)now.intent_calls)+1);
#ifdef VAR_RANGES
		logval("intent_calls", ((int)now.intent_calls));
#endif
		;
		/* merge: pc = 3(305, 124, 305) */
		reached[3][124] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 50: // STATE 125 - privacy-response.pml:176 - [((pc==3))] (130:0:2 - 1)
		IfNotBlocked
		reached[3][125] = 1;
		if (!((((int)now.pc)==3)))
			continue;
		/* merge: intent_state = Completed(130, 126, 130) */
		reached[3][126] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.intent_state;
		now.intent_state = 16;
#ifdef VAR_RANGES
		logval("intent_state", now.intent_state);
#endif
		;
		/* merge: intent_receipt = 1(130, 127, 130) */
		reached[3][127] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.intent_receipt);
		now.intent_receipt = 1;
#ifdef VAR_RANGES
		logval("intent_receipt", ((int)now.intent_receipt));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 51: // STATE 128 - privacy-response.pml:180 - [intent_exposed = 1] (0:305:2 - 1)
		IfNotBlocked
		reached[3][128] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.intent_exposed);
		now.intent_exposed = 1;
#ifdef VAR_RANGES
		logval("intent_exposed", ((int)now.intent_exposed));
#endif
		;
		/* merge: .(goto)(305, 131, 305) */
		reached[3][131] = 1;
		;
		/* merge: pc = 4(305, 132, 305) */
		reached[3][132] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 52: // STATE 129 - privacy-response.pml:180 - [intent_exposed = 0] (0:305:2 - 1)
		IfNotBlocked
		reached[3][129] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.intent_exposed);
		now.intent_exposed = 0;
#ifdef VAR_RANGES
		logval("intent_exposed", ((int)now.intent_exposed));
#endif
		;
		/* merge: .(goto)(305, 131, 305) */
		reached[3][131] = 1;
		;
		/* merge: pc = 4(305, 132, 305) */
		reached[3][132] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 53: // STATE 132 - privacy-response.pml:181 - [pc = 4] (0:305:1 - 3)
		IfNotBlocked
		reached[3][132] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 54: // STATE 133 - privacy-response.pml:182 - [((pc==4))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][133] = 1;
		if (!((((int)now.pc)==4)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 55: // STATE 134 - privacy-response.pml:184 - [(intent_exposed)] (305:0:1 - 1)
		IfNotBlocked
		reached[3][134] = 1;
		if (!(((int)now.intent_exposed)))
			continue;
		/* merge: pc = 5(0, 135, 305) */
		reached[3][135] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 5;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 162, 305) */
		reached[3][162] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 56: // STATE 136 - privacy-response.pml:185 - [(!(intent_exposed))] (160:0:1 - 1)
		IfNotBlocked
		reached[3][136] = 1;
		if (!( !(((int)now.intent_exposed))))
			continue;
		/* merge: terminal = Held(0, 137, 160) */
		reached[3][137] = 1;
		(trpt+1)->bup.oval = terminal;
		terminal = 3;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 57: // STATE 138 - privacy-response.pml:103 - [(replayed)] (305:0:1 - 1)
		IfNotBlocked
		reached[3][138] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 139, 305) */
		reached[3][139] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 159, 305) */
		reached[3][159] = 1;
		;
		/* merge: .(goto)(0, 162, 305) */
		reached[3][162] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 58: // STATE 140 - privacy-response.pml:104 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][140] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 59: // STATE 141 - privacy-response.pml:105 - [attempt_event = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][141] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 1;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 60: // STATE 142 - privacy-response.pml:105 - [attempt_event = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][142] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 2;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 61: // STATE 145 - privacy-response.pml:106 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][145] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 62: // STATE 146 - privacy-response.pml:106 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][146] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 63: // STATE 149 - privacy-response.pml:107 - [attempt_destination = 1] (0:305:6 - 1)
		IfNotBlocked
		reached[3][149] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 1;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 152, 305) */
		reached[3][152] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 153, 305) */
		reached[3][153] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 154, 305) */
		reached[3][154] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 155, 305) */
		reached[3][155] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 156, 305) */
		reached[3][156] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 157, 305) */
		reached[3][157] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 159, 305) */
		reached[3][159] = 1;
		;
		/* merge: .(goto)(0, 162, 305) */
		reached[3][162] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 10 */
	case 64: // STATE 150 - privacy-response.pml:107 - [attempt_destination = 2] (0:305:6 - 1)
		IfNotBlocked
		reached[3][150] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 2;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 152, 305) */
		reached[3][152] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 153, 305) */
		reached[3][153] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 154, 305) */
		reached[3][154] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 155, 305) */
		reached[3][155] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 156, 305) */
		reached[3][156] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 157, 305) */
		reached[3][157] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 159, 305) */
		reached[3][159] = 1;
		;
		/* merge: .(goto)(0, 162, 305) */
		reached[3][162] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 10 */
	case 65: // STATE 153 - privacy-response.pml:108 - [sealed_intent_calls = intent_calls] (0:305:5 - 3)
		IfNotBlocked
		reached[3][153] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 154, 305) */
		reached[3][154] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 155, 305) */
		reached[3][155] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 156, 305) */
		reached[3][156] = 1;
		(trpt+1)->bup.ovals[3] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 157, 305) */
		reached[3][157] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 159, 305) */
		reached[3][159] = 1;
		;
		/* merge: .(goto)(0, 162, 305) */
		reached[3][162] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 66: // STATE 163 - privacy-response.pml:192 - [((pc==5))] (172:0:1 - 1)
		IfNotBlocked
		reached[3][163] = 1;
		if (!((((int)now.pc)==5)))
			continue;
		/* merge: admission_check = rights(172, 164, 172) */
		reached[3][164] = 1;
		(trpt+1)->bup.oval = ((int)now.admission_check);
		now.admission_check = ((int)now.rights);
#ifdef VAR_RANGES
		logval("admission_check", ((int)now.admission_check));
#endif
		;
		/* merge: assert((!(admission_check)||rights))(172, 165, 172) */
		reached[3][165] = 1;
		spin_assert(( !(((int)now.admission_check))||((int)now.rights)), "( !(admission_check)||rights)", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 67: // STATE 166 - privacy-response.pml:201 - [(admission_check)] (305:0:1 - 1)
		IfNotBlocked
		reached[3][166] = 1;
		if (!(((int)now.admission_check)))
			continue;
		/* merge: pc = 6(0, 167, 305) */
		reached[3][167] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 6;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 173, 305) */
		reached[3][173] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 68: // STATE 168 - privacy-response.pml:202 - [(!(admission_check))] (305:0:3 - 1)
		IfNotBlocked
		reached[3][168] = 1;
		if (!( !(((int)now.admission_check))))
			continue;
		/* merge: revoked_before_notification = 1(305, 169, 305) */
		reached[3][169] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)revoked_before_notification);
		revoked_before_notification = 1;
#ifdef VAR_RANGES
		logval("revoked_before_notification", ((int)revoked_before_notification));
#endif
		;
		/* merge: terminal = Denied(305, 170, 305) */
		reached[3][170] = 1;
		(trpt+1)->bup.ovals[1] = terminal;
		terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: finished = 1(305, 171, 305) */
		reached[3][171] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 173, 305) */
		reached[3][173] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 69: // STATE 174 - privacy-response.pml:205 - [((pc==6))] (182:0:0 - 1)
		IfNotBlocked
		reached[3][174] = 1;
		if (!((((int)now.pc)==6)))
			continue;
		/* merge: assert((intent_receipt&&intent_exposed))(182, 175, 182) */
		reached[3][175] = 1;
		spin_assert((((int)now.intent_receipt)&&((int)now.intent_exposed)), "(intent_receipt&&intent_exposed)", II, tt, t);
		/* merge: assert(admission_check)(182, 176, 182) */
		reached[3][176] = 1;
		spin_assert(((int)now.admission_check), "admission_check", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 70: // STATE 177 - privacy-response.pml:209 - [((notification_state==Completed))] (305:0:1 - 1)
		IfNotBlocked
		reached[3][177] = 1;
		if (!((now.notification_state==16)))
			continue;
		/* merge: pc = 10(0, 178, 305) */
		reached[3][178] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 183, 305) */
		reached[3][183] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 71: // STATE 179 - privacy-response.pml:214 - [((notification_state==Empty))] (305:0:2 - 1)
		IfNotBlocked
		reached[3][179] = 1;
		if (!((now.notification_state==18)))
			continue;
		/* merge: notification_state = Executing(305, 180, 305) */
		reached[3][180] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.notification_state;
		now.notification_state = 17;
#ifdef VAR_RANGES
		logval("notification_state", now.notification_state);
#endif
		;
		/* merge: pc = 7(305, 181, 305) */
		reached[3][181] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 7;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 183, 305) */
		reached[3][183] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 72: // STATE 184 - privacy-response.pml:216 - [((pc==7))] (186:0:1 - 1)
		IfNotBlocked
		reached[3][184] = 1;
		if (!((((int)now.pc)==7)))
			continue;
		/* merge: notification_calls = (notification_calls+1)(0, 185, 186) */
		reached[3][185] = 1;
		(trpt+1)->bup.oval = ((int)now.notification_calls);
		now.notification_calls = (((int)now.notification_calls)+1);
#ifdef VAR_RANGES
		logval("notification_calls", ((int)now.notification_calls));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 73: // STATE 186 - privacy-response.pml:217 - [submissions!1] (305:0:1 - 1)
		IfNotBlocked
		reached[3][186] = 1;
		if (q_full(now.submissions))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.submissions);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.submissions, 0, 1, 1);
		/* merge: pc = 8(0, 187, 305) */
		reached[3][187] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 8;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 2; goto P999; /* 3 */
	case 74: // STATE 188 - privacy-response.pml:218 - [((pc==8))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][188] = 1;
		if (!((((int)now.pc)==8)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 75: // STATE 189 - privacy-response.pml:225 - [replies?observed_outcome] (305:0:2 - 1)
		reached[3][189] = 1;
		if (q_len(now.replies) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.observed_outcome;
		;
		now.observed_outcome = qrecv(now.replies, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("observed_outcome", now.observed_outcome);
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.replies);
			sprintf(simtmp, "%d", now.observed_outcome); strcat(simvals, simtmp);
		}
#endif
		;
		/* merge: pc = 9(0, 190, 305) */
		reached[3][190] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 9;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 4; goto P999; /* 3 */
	case 76: // STATE 191 - privacy-response.pml:227 - [((pc==9))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][191] = 1;
		if (!((((int)now.pc)==9)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 77: // STATE 192 - privacy-response.pml:229 - [((observed_outcome==Lost))] (217:0:2 - 1)
		IfNotBlocked
		reached[3][192] = 1;
		if (!((now.observed_outcome==7)))
			continue;
		/* merge: notification_state = Unknown(217, 193, 217) */
		reached[3][193] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.notification_state;
		now.notification_state = 15;
#ifdef VAR_RANGES
		logval("notification_state", now.notification_state);
#endif
		;
		/* merge: terminal = Blocked(217, 194, 217) */
		reached[3][194] = 1;
		(trpt+1)->bup.ovals[1] = terminal;
		terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 78: // STATE 195 - privacy-response.pml:103 - [(replayed)] (305:0:1 - 1)
		IfNotBlocked
		reached[3][195] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 196, 305) */
		reached[3][196] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 216, 305) */
		reached[3][216] = 1;
		;
		/* merge: .(goto)(0, 229, 305) */
		reached[3][229] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 79: // STATE 197 - privacy-response.pml:104 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][197] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 80: // STATE 198 - privacy-response.pml:105 - [attempt_event = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][198] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 1;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 81: // STATE 199 - privacy-response.pml:105 - [attempt_event = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][199] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 2;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 82: // STATE 202 - privacy-response.pml:106 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][202] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 83: // STATE 203 - privacy-response.pml:106 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][203] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 84: // STATE 206 - privacy-response.pml:107 - [attempt_destination = 1] (0:305:6 - 1)
		IfNotBlocked
		reached[3][206] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 1;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 209, 305) */
		reached[3][209] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 210, 305) */
		reached[3][210] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 211, 305) */
		reached[3][211] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 212, 305) */
		reached[3][212] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 213, 305) */
		reached[3][213] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 214, 305) */
		reached[3][214] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 216, 305) */
		reached[3][216] = 1;
		;
		/* merge: .(goto)(0, 229, 305) */
		reached[3][229] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 10 */
	case 85: // STATE 207 - privacy-response.pml:107 - [attempt_destination = 2] (0:305:6 - 1)
		IfNotBlocked
		reached[3][207] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 2;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 209, 305) */
		reached[3][209] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 210, 305) */
		reached[3][210] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 211, 305) */
		reached[3][211] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 212, 305) */
		reached[3][212] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 213, 305) */
		reached[3][213] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 214, 305) */
		reached[3][214] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 216, 305) */
		reached[3][216] = 1;
		;
		/* merge: .(goto)(0, 229, 305) */
		reached[3][229] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 10 */
	case 86: // STATE 210 - privacy-response.pml:108 - [sealed_intent_calls = intent_calls] (0:305:5 - 3)
		IfNotBlocked
		reached[3][210] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 211, 305) */
		reached[3][211] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 212, 305) */
		reached[3][212] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 213, 305) */
		reached[3][213] = 1;
		(trpt+1)->bup.ovals[3] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 214, 305) */
		reached[3][214] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 216, 305) */
		reached[3][216] = 1;
		;
		/* merge: .(goto)(0, 229, 305) */
		reached[3][229] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 87: // STATE 218 - privacy-response.pml:232 - [((observed_outcome!=Lost))] (225:0:4 - 1)
		IfNotBlocked
		reached[3][218] = 1;
		if (!((now.observed_outcome!=7)))
			continue;
		/* merge: provider_outcome = observed_outcome(225, 219, 225) */
		reached[3][219] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.provider_outcome;
		now.provider_outcome = now.observed_outcome;
#ifdef VAR_RANGES
		logval("provider_outcome", now.provider_outcome);
#endif
		;
		/* merge: sealed_outcome = observed_outcome(225, 220, 225) */
		reached[3][220] = 1;
		(trpt+1)->bup.ovals[1] = now.sealed_outcome;
		now.sealed_outcome = now.observed_outcome;
#ifdef VAR_RANGES
		logval("sealed_outcome", now.sealed_outcome);
#endif
		;
		/* merge: notification_state = Completed(225, 221, 225) */
		reached[3][221] = 1;
		(trpt+1)->bup.ovals[2] = now.notification_state;
		now.notification_state = 16;
#ifdef VAR_RANGES
		logval("notification_state", now.notification_state);
#endif
		;
		/* merge: notification_receipt = 1(225, 222, 225) */
		reached[3][222] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.notification_receipt);
		now.notification_receipt = 1;
#ifdef VAR_RANGES
		logval("notification_receipt", ((int)now.notification_receipt));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 88: // STATE 223 - privacy-response.pml:241 - [payload_withheld = 1] (0:305:2 - 1)
		IfNotBlocked
		reached[3][223] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)payload_withheld);
		payload_withheld = 1;
#ifdef VAR_RANGES
		logval("payload_withheld", ((int)payload_withheld));
#endif
		;
		/* merge: .(goto)(305, 226, 305) */
		reached[3][226] = 1;
		;
		/* merge: pc = 10(305, 227, 305) */
		reached[3][227] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 229, 305) */
		reached[3][229] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 89: // STATE 224 - privacy-response.pml:241 - [payload_withheld = 0] (0:305:2 - 1)
		IfNotBlocked
		reached[3][224] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)payload_withheld);
		payload_withheld = 0;
#ifdef VAR_RANGES
		logval("payload_withheld", ((int)payload_withheld));
#endif
		;
		/* merge: .(goto)(305, 226, 305) */
		reached[3][226] = 1;
		;
		/* merge: pc = 10(305, 227, 305) */
		reached[3][227] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 229, 305) */
		reached[3][229] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 90: // STATE 227 - privacy-response.pml:245 - [pc = 10] (0:305:1 - 3)
		IfNotBlocked
		reached[3][227] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 229, 305) */
		reached[3][229] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 91: // STATE 230 - privacy-response.pml:247 - [((pc==10))] (255:0:1 - 1)
		IfNotBlocked
		reached[3][230] = 1;
		if (!((((int)now.pc)==10)))
			continue;
		/* merge: assert((((attempt_tenant==1)&&(attempt_event==frozen_event))&&(attempt_destination==frozen_destination)))(255, 231, 255) */
		reached[3][231] = 1;
		spin_assert((((((int)now.attempt_tenant)==1)&&(((int)now.attempt_event)==((int)now.frozen_event)))&&(((int)now.attempt_destination)==((int)now.frozen_destination))), "(((attempt_tenant==1)&&(attempt_event==frozen_event))&&(attempt_destination==frozen_destination))", II, tt, t);
		/* merge: terminal = Settled(255, 232, 255) */
		reached[3][232] = 1;
		(trpt+1)->bup.oval = terminal;
		terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 92: // STATE 233 - privacy-response.pml:103 - [(replayed)] (305:0:1 - 1)
		IfNotBlocked
		reached[3][233] = 1;
		if (!(((int)now.replayed)))
			continue;
		/* merge: finished = 1(0, 234, 305) */
		reached[3][234] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 254, 305) */
		reached[3][254] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 93: // STATE 235 - privacy-response.pml:104 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][235] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 94: // STATE 236 - privacy-response.pml:105 - [attempt_event = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][236] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 1;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 95: // STATE 237 - privacy-response.pml:105 - [attempt_event = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][237] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_event);
		now.attempt_event = 2;
#ifdef VAR_RANGES
		logval("attempt_event", ((int)now.attempt_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 96: // STATE 240 - privacy-response.pml:106 - [attempt_tenant = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][240] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 1;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 97: // STATE 241 - privacy-response.pml:106 - [attempt_tenant = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][241] = 1;
		(trpt+1)->bup.oval = ((int)now.attempt_tenant);
		now.attempt_tenant = 2;
#ifdef VAR_RANGES
		logval("attempt_tenant", ((int)now.attempt_tenant));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 98: // STATE 244 - privacy-response.pml:107 - [attempt_destination = 1] (0:305:6 - 1)
		IfNotBlocked
		reached[3][244] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 1;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 247, 305) */
		reached[3][247] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 248, 305) */
		reached[3][248] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 249, 305) */
		reached[3][249] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 250, 305) */
		reached[3][250] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 251, 305) */
		reached[3][251] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 252, 305) */
		reached[3][252] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 254, 305) */
		reached[3][254] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 99: // STATE 245 - privacy-response.pml:107 - [attempt_destination = 2] (0:305:6 - 1)
		IfNotBlocked
		reached[3][245] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.attempt_destination);
		now.attempt_destination = 2;
#ifdef VAR_RANGES
		logval("attempt_destination", ((int)now.attempt_destination));
#endif
		;
		/* merge: .(goto)(305, 247, 305) */
		reached[3][247] = 1;
		;
		/* merge: sealed_intent_calls = intent_calls(305, 248, 305) */
		reached[3][248] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 249, 305) */
		reached[3][249] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 250, 305) */
		reached[3][250] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 251, 305) */
		reached[3][251] = 1;
		(trpt+1)->bup.ovals[4] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 252, 305) */
		reached[3][252] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 254, 305) */
		reached[3][254] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 100: // STATE 248 - privacy-response.pml:108 - [sealed_intent_calls = intent_calls] (0:305:5 - 3)
		IfNotBlocked
		reached[3][248] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)now.sealed_intent_calls);
		now.sealed_intent_calls = ((int)now.intent_calls);
#ifdef VAR_RANGES
		logval("sealed_intent_calls", ((int)now.sealed_intent_calls));
#endif
		;
		/* merge: sealed_notification_calls = notification_calls(305, 249, 305) */
		reached[3][249] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.sealed_notification_calls);
		now.sealed_notification_calls = ((int)now.notification_calls);
#ifdef VAR_RANGES
		logval("sealed_notification_calls", ((int)now.sealed_notification_calls));
#endif
		;
		/* merge: replayed = 1(305, 250, 305) */
		reached[3][250] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		/* merge: terminal = Running(305, 251, 305) */
		reached[3][251] = 1;
		(trpt+1)->bup.ovals[3] = terminal;
		terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: pc = 20(305, 252, 305) */
		reached[3][252] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.pc);
		now.pc = 20;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 254, 305) */
		reached[3][254] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 101: // STATE 256 - privacy-response.pml:253 - [((pc==20))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][256] = 1;
		if (!((((int)now.pc)==20)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 102: // STATE 257 - privacy-response.pml:255 - [((attempt_tenant!=1))] (305:0:3 - 1)
		IfNotBlocked
		reached[3][257] = 1;
		if (!((((int)now.attempt_tenant)!=1)))
			continue;
		/* merge: foreign_rejected = 1(305, 258, 305) */
		reached[3][258] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.foreign_rejected);
		now.foreign_rejected = 1;
#ifdef VAR_RANGES
		logval("foreign_rejected", ((int)now.foreign_rejected));
#endif
		;
		/* merge: terminal = Denied(305, 259, 305) */
		reached[3][259] = 1;
		(trpt+1)->bup.ovals[1] = terminal;
		terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: finished = 1(305, 260, 305) */
		reached[3][260] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 271, 305) */
		reached[3][271] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 103: // STATE 261 - privacy-response.pml:256 - [((attempt_tenant==1))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][261] = 1;
		if (!((((int)now.attempt_tenant)==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 104: // STATE 262 - privacy-response.pml:258 - [((attempt_event!=frozen_event))] (305:0:3 - 1)
		IfNotBlocked
		reached[3][262] = 1;
		if (!((((int)now.attempt_event)!=((int)now.frozen_event))))
			continue;
		/* merge: conflict_rejected = 1(305, 263, 305) */
		reached[3][263] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)conflict_rejected);
		conflict_rejected = 1;
#ifdef VAR_RANGES
		logval("conflict_rejected", ((int)conflict_rejected));
#endif
		;
		/* merge: terminal = Denied(305, 264, 305) */
		reached[3][264] = 1;
		(trpt+1)->bup.ovals[1] = terminal;
		terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: finished = 1(305, 265, 305) */
		reached[3][265] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 269, 305) */
		reached[3][269] = 1;
		;
		/* merge: .(goto)(0, 271, 305) */
		reached[3][271] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 105: // STATE 266 - privacy-response.pml:265 - [((attempt_event==frozen_event))] (305:0:1 - 1)
		IfNotBlocked
		reached[3][266] = 1;
		if (!((((int)now.attempt_event)==((int)now.frozen_event))))
			continue;
		/* merge: pc = 21(0, 267, 305) */
		reached[3][267] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 21;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 269, 305) */
		reached[3][269] = 1;
		;
		/* merge: .(goto)(0, 271, 305) */
		reached[3][271] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 106: // STATE 272 - privacy-response.pml:268 - [((pc==21))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][272] = 1;
		if (!((((int)now.pc)==21)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 107: // STATE 273 - privacy-response.pml:270 - [((attempt_destination!=frozen_destination))] (305:0:3 - 1)
		IfNotBlocked
		reached[3][273] = 1;
		if (!((((int)now.attempt_destination)!=((int)now.frozen_destination))))
			continue;
		/* merge: destination_conflict = 1(305, 274, 305) */
		reached[3][274] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)destination_conflict);
		destination_conflict = 1;
#ifdef VAR_RANGES
		logval("destination_conflict", ((int)destination_conflict));
#endif
		;
		/* merge: terminal = Denied(305, 275, 305) */
		reached[3][275] = 1;
		(trpt+1)->bup.ovals[1] = terminal;
		terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: finished = 1(305, 276, 305) */
		reached[3][276] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 288, 305) */
		reached[3][288] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 108: // STATE 277 - privacy-response.pml:277 - [((attempt_destination==frozen_destination))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][277] = 1;
		if (!((((int)now.attempt_destination)==((int)now.frozen_destination))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 109: // STATE 278 - privacy-response.pml:279 - [(((intent_state==Unknown)||(notification_state==Unknown)))] (305:0:3 - 1)
		IfNotBlocked
		reached[3][278] = 1;
		if (!(((now.intent_state==15)||(now.notification_state==15))))
			continue;
		/* merge: assert((notification_calls==sealed_notification_calls))(305, 279, 305) */
		reached[3][279] = 1;
		spin_assert((((int)now.notification_calls)==((int)now.sealed_notification_calls)), "(notification_calls==sealed_notification_calls)", II, tt, t);
		/* merge: unknown_retry_blocked = 1(305, 280, 305) */
		reached[3][280] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)unknown_retry_blocked);
		unknown_retry_blocked = 1;
#ifdef VAR_RANGES
		logval("unknown_retry_blocked", ((int)unknown_retry_blocked));
#endif
		;
		/* merge: terminal = Blocked(305, 281, 305) */
		reached[3][281] = 1;
		(trpt+1)->bup.ovals[1] = terminal;
		terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", terminal);
#endif
		;
		/* merge: finished = 1(305, 282, 305) */
		reached[3][282] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 286, 305) */
		reached[3][286] = 1;
		;
		/* merge: .(goto)(0, 288, 305) */
		reached[3][288] = 1;
		;
		/* merge: .(goto)(0, 290, 305) */
		reached[3][290] = 1;
		;
		/* merge: .(goto)(0, 292, 305) */
		reached[3][292] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 110: // STATE 284 - privacy-response.pml:285 - [pc = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[3][284] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 111: // STATE 293 - privacy-response.pml:56 - [assert(((intent_calls<=1)&&(notification_calls<=1)))] (0:307:0 - 1)
		IfNotBlocked
		reached[3][293] = 1;
		spin_assert(((((int)now.intent_calls)<=1)&&(((int)now.notification_calls)<=1)), "((intent_calls<=1)&&(notification_calls<=1))", II, tt, t);
		/* merge: assert((route==required_route))(307, 294, 307) */
		reached[3][294] = 1;
		spin_assert((((int)now.route)==((int)now.required_route)), "(route==required_route)", II, tt, t);
		/* merge: assert(((frozen_route==0)||(frozen_route==required_route)))(307, 295, 307) */
		reached[3][295] = 1;
		spin_assert(((((int)now.frozen_route)==0)||(((int)now.frozen_route)==((int)now.required_route))), "((frozen_route==0)||(frozen_route==required_route))", II, tt, t);
		/* merge: assert(((frozen_event==0)||(frozen_event==1)))(307, 296, 307) */
		reached[3][296] = 1;
		spin_assert(((((int)now.frozen_event)==0)||(((int)now.frozen_event)==1)), "((frozen_event==0)||(frozen_event==1))", II, tt, t);
		/* merge: assert(((frozen_destination==0)||(frozen_destination==1)))(307, 297, 307) */
		reached[3][297] = 1;
		spin_assert(((((int)now.frozen_destination)==0)||(((int)now.frozen_destination)==1)), "((frozen_destination==0)||(frozen_destination==1))", II, tt, t);
		/* merge: assert((!(intent_receipt)||(intent_state==Completed)))(307, 298, 307) */
		reached[3][298] = 1;
		spin_assert(( !(((int)now.intent_receipt))||(now.intent_state==16)), "( !(intent_receipt)||(intent_state==16))", II, tt, t);
		/* merge: assert((!(notification_receipt)||(notification_state==Completed)))(307, 299, 307) */
		reached[3][299] = 1;
		spin_assert(( !(((int)now.notification_receipt))||(now.notification_state==16)), "( !(notification_receipt)||(notification_state==16))", II, tt, t);
		/* merge: assert(((notification_calls==0)||(intent_receipt&&intent_exposed)))(307, 300, 307) */
		reached[3][300] = 1;
		spin_assert(((((int)now.notification_calls)==0)||(((int)now.intent_receipt)&&((int)now.intent_exposed))), "((notification_calls==0)||(intent_receipt&&intent_exposed))", II, tt, t);
		/* merge: assert((!(notification_receipt)||(provider_outcome==sealed_outcome)))(307, 301, 307) */
		reached[3][301] = 1;
		spin_assert(( !(((int)now.notification_receipt))||(now.provider_outcome==now.sealed_outcome)), "( !(notification_receipt)||(provider_outcome==sealed_outcome))", II, tt, t);
		/* merge: assert((!(notification_receipt)||(provider_outcome==observed_outcome)))(307, 302, 307) */
		reached[3][302] = 1;
		spin_assert(( !(((int)now.notification_receipt))||(now.provider_outcome==now.observed_outcome)), "( !(notification_receipt)||(provider_outcome==observed_outcome))", II, tt, t);
		/* merge: assert(!(recipient_delivery_known))(307, 303, 307) */
		reached[3][303] = 1;
		spin_assert( !(((int)now.recipient_delivery_known)), " !(recipient_delivery_known)", II, tt, t);
		/* merge: assert((!(replayed)||((intent_calls==sealed_intent_calls)&&(notification_calls==sealed_notification_calls))))(307, 304, 307) */
		reached[3][304] = 1;
		spin_assert(( !(((int)now.replayed))||((((int)now.intent_calls)==((int)now.sealed_intent_calls))&&(((int)now.notification_calls)==((int)now.sealed_notification_calls)))), "( !(replayed)||((intent_calls==sealed_intent_calls)&&(notification_calls==sealed_notification_calls)))", II, tt, t);
		/* merge: .(goto)(0, 308, 307) */
		reached[3][308] = 1;
		;
		_m = 3; goto P999; /* 12 */
	case 112: // STATE 310 - privacy-response.pml:324 - [assert(!(foreign_rejected))] (0:0:0 - 3)
		IfNotBlocked
		reached[3][310] = 1;
		spin_assert( !(((int)now.foreign_rejected)), " !(foreign_rejected)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 113: // STATE 311 - privacy-response.pml:335 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[3][311] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Endpoint */
	case 114: // STATE 1 - privacy-response.pml:87 - [submissions?action_id] (0:0:2 - 1)
		reached[2][1] = 1;
		if (q_len(now.submissions) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P2 *)_this)->action_id);
		;
		((P2 *)_this)->action_id = qrecv(now.submissions, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("Endpoint:action_id", ((int)((P2 *)_this)->action_id));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.submissions);
			sprintf(simtmp, "%d", ((int)((P2 *)_this)->action_id)); strcat(simvals, simtmp);
		}
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: action_id */  (trpt+1)->bup.ovals[1] = ((P2 *)_this)->action_id;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->action_id = 0;
		_m = 4; goto P999; /* 0 */
	case 115: // STATE 2 - privacy-response.pml:90 - [replies!Accepted] (14:0:0 - 1)
		IfNotBlocked
		reached[2][2] = 1;
		if (q_full(now.replies))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.replies);
		sprintf(simtmp, "%d", 11); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.replies, 0, 11, 1);
		/* merge: .(goto)(0, 8, 14) */
		reached[2][8] = 1;
		;
		/* merge: .(goto)(0, 13, 14) */
		reached[2][13] = 1;
		;
		_m = 2; goto P999; /* 2 */
	case 116: // STATE 3 - privacy-response.pml:91 - [replies!Refused] (14:0:0 - 1)
		IfNotBlocked
		reached[2][3] = 1;
		if (q_full(now.replies))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.replies);
		sprintf(simtmp, "%d", 10); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.replies, 0, 10, 1);
		/* merge: .(goto)(0, 8, 14) */
		reached[2][8] = 1;
		;
		/* merge: .(goto)(0, 13, 14) */
		reached[2][13] = 1;
		;
		_m = 2; goto P999; /* 2 */
	case 117: // STATE 4 - privacy-response.pml:92 - [replies!Throttled] (14:0:0 - 1)
		IfNotBlocked
		reached[2][4] = 1;
		if (q_full(now.replies))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.replies);
		sprintf(simtmp, "%d", 9); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.replies, 0, 9, 1);
		/* merge: .(goto)(0, 8, 14) */
		reached[2][8] = 1;
		;
		/* merge: .(goto)(0, 13, 14) */
		reached[2][13] = 1;
		;
		_m = 2; goto P999; /* 2 */
	case 118: // STATE 5 - privacy-response.pml:93 - [replies!NotSent] (14:0:0 - 1)
		IfNotBlocked
		reached[2][5] = 1;
		if (q_full(now.replies))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.replies);
		sprintf(simtmp, "%d", 8); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.replies, 0, 8, 1);
		/* merge: .(goto)(0, 8, 14) */
		reached[2][8] = 1;
		;
		/* merge: .(goto)(0, 13, 14) */
		reached[2][13] = 1;
		;
		_m = 2; goto P999; /* 2 */
	case 119: // STATE 6 - privacy-response.pml:94 - [replies!Lost] (14:0:0 - 1)
		IfNotBlocked
		reached[2][6] = 1;
		if (q_full(now.replies))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.replies);
		sprintf(simtmp, "%d", 7); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.replies, 0, 7, 1);
		/* merge: .(goto)(0, 8, 14) */
		reached[2][8] = 1;
		;
		/* merge: .(goto)(0, 13, 14) */
		reached[2][13] = 1;
		;
		_m = 2; goto P999; /* 2 */
	case 120: // STATE 10 - privacy-response.pml:97 - [(finished)] (0:0:0 - 1)
		IfNotBlocked
		reached[2][10] = 1;
		if (!(((int)now.finished)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 121: // STATE 14 - privacy-response.pml:99 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[2][14] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Crash */
	case 122: // STATE 2 - privacy-response.pml:80 - [(!(finished))] (8:0:2 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!( !(((int)now.finished))))
			continue;
		/* merge: crash = 1(8, 3, 8) */
		reached[1][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.crash);
		now.crash = 1;
#ifdef VAR_RANGES
		logval("crash", ((int)now.crash));
#endif
		;
		/* merge: crashed_once = 1(8, 4, 8) */
		reached[1][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)crashed_once);
		crashed_once = 1;
#ifdef VAR_RANGES
		logval("crashed_once", ((int)crashed_once));
#endif
		;
		/* merge: .(goto)(0, 7, 8) */
		reached[1][7] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 123: // STATE 8 - privacy-response.pml:82 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[1][8] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Revoke */
	case 124: // STATE 2 - privacy-response.pml:73 - [(!(finished))] (7:0:1 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		if (!( !(((int)now.finished))))
			continue;
		/* merge: rights = 0(0, 3, 7) */
		reached[0][3] = 1;
		(trpt+1)->bup.oval = ((int)now.rights);
		now.rights = 0;
#ifdef VAR_RANGES
		logval("rights", ((int)now.rights));
#endif
		;
		/* merge: .(goto)(0, 6, 7) */
		reached[0][6] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 125: // STATE 7 - privacy-response.pml:75 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[0][7] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

