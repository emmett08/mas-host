	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM governed_local_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 5: // STATE 1
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 6: // STATE 2
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 7: // STATE 3
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 8: // STATE 4
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 9: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Host */

	case 10: // STATE 1
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 2
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 14: // STATE 8
		;
		restarted = trpt->bup.ovals[1];
		now.crash = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 15: // STATE 12
		;
		now.terminal = trpt->bup.ovals[2];
		unknown_seen = trpt->bup.ovals[1];
		now.effect_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 16: // STATE 13
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 14
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 18: // STATE 15
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 18
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 20: // STATE 19
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 21: // STATE 34
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 22: // STATE 24
		;
		now.session_grant_epoch = trpt->bup.ovals[1];
		now.lease_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 23: // STATE 34
		;
		now.pc = trpt->bup.ovals[2];
		now.sealed_calls = trpt->bup.ovals[1];
		epoch_refreshed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 24: // STATE 34
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 25: // STATE 34
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 27: // STATE 38
		;
		completion_gap_crash = trpt->bup.oval;
		;
		goto R999;

	case 28: // STATE 43
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 29: // STATE 44
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 30: // STATE 45
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 31: // STATE 48
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 32: // STATE 49
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 33: // STATE 64
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 34: // STATE 54
		;
		now.session_grant_epoch = trpt->bup.ovals[1];
		now.lease_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 35: // STATE 64
		;
		now.pc = trpt->bup.ovals[2];
		now.sealed_calls = trpt->bup.ovals[1];
		epoch_refreshed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 36: // STATE 64
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 37: // STATE 64
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 38: // STATE 67
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 39: // STATE 68
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 40: // STATE 69
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 41: // STATE 70
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 42: // STATE 73
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 43: // STATE 74
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 44: // STATE 89
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 45: // STATE 79
		;
		now.session_grant_epoch = trpt->bup.ovals[1];
		now.lease_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 46: // STATE 89
		;
		now.pc = trpt->bup.ovals[2];
		now.sealed_calls = trpt->bup.ovals[1];
		epoch_refreshed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 47: // STATE 89
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 48: // STATE 89
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 49: // STATE 92
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 51: // STATE 97
		;
		now.request_check = trpt->bup.oval;
		;
		goto R999;

	case 52: // STATE 99
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 53: // STATE 102
		;
		now.finished = trpt->bup.ovals[1];
		now.terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 54: // STATE 110
		;
		now.pc = trpt->bup.ovals[2];
		now.journal_input = trpt->bup.ovals[1];
		now.bound_original = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 55: // STATE 112
		;
		now.protocol_check = trpt->bup.oval;
		;
		goto R999;

	case 56: // STATE 114
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 57: // STATE 117
		;
		now.finished = trpt->bup.ovals[1];
		now.terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 58: // STATE 123
		;
		now.pc = trpt->bup.ovals[1];
		now.protocol_input = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 59: // STATE 126
		;
		now.effect_check = trpt->bup.ovals[1];
		now.effect_check = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 60: // STATE 129
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 61: // STATE 132
		;
		now.finished = trpt->bup.ovals[1];
		now.terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 62: // STATE 139
		;
		now.pc = trpt->bup.ovals[2];
		now.reservation = trpt->bup.ovals[1];
		now.effect_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 63: // STATE 141
		;
		now.effect_check = trpt->bup.oval;
		;
		goto R999;

	case 64: // STATE 143
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 65: // STATE 146
		;
		now.finished = trpt->bup.ovals[1];
		now.terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 66: // STATE 149
		goto R999;

	case 67: // STATE 158
		;
		now.pc = trpt->bup.ovals[2];
		now.effect_state = trpt->bup.ovals[1];
		check_action_race = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 68: // STATE 158
		;
		now.pc = trpt->bup.ovals[1];
		now.effect_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 69: // STATE 158
		;
		now.pc = trpt->bup.ovals[1];
		now.effect_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 70: // STATE 160
		;
		now.calls = trpt->bup.oval;
		;
		goto R999;

	case 71: // STATE 162
		;
		now.pc = trpt->bup.oval;
		_m = unsend(now.requests);
		;
		goto R999;
;
		;
		
	case 73: // STATE 165
		;
		now.pc = trpt->bup.ovals[2];
		XX = 1;
		unrecv(now.results, XX-1, 0, now.observed, 1);
		unrecv(now.results, XX-1, 1, ((int)now.observed_certainty), 0);
		now.observed = trpt->bup.ovals[0];
		now.observed_certainty = trpt->bup.ovals[1];
		;
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;
;
		;
		
	case 75: // STATE 170
		;
		now.terminal = trpt->bup.ovals[2];
		unknown_seen = trpt->bup.ovals[1];
		now.effect_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 76: // STATE 171
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 77: // STATE 172
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 78: // STATE 173
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 79: // STATE 176
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 80: // STATE 177
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 81: // STATE 192
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 82: // STATE 182
		;
		now.session_grant_epoch = trpt->bup.ovals[1];
		now.lease_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 83: // STATE 192
		;
		now.pc = trpt->bup.ovals[2];
		now.sealed_calls = trpt->bup.ovals[1];
		epoch_refreshed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 84: // STATE 192
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 85: // STATE 192
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 86: // STATE 195
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 87: // STATE 199
		;
		now.inspection_precheck = trpt->bup.oval;
		;
		goto R999;

	case 88: // STATE 201
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 89: // STATE 205
		;
		now.pc = trpt->bup.ovals[2];
		now.local_output = trpt->bup.ovals[1];
		now.local_withheld = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;
;
		;
		
	case 91: // STATE 212
		;
		now.inspection_original_positive = trpt->bup.ovals[3];
		now.inspection_clean = trpt->bup.ovals[2];
		now.inspection_exact = trpt->bup.ovals[1];
		now.inspection_complete = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 92: // STATE 223
		;
		now.pc = trpt->bup.ovals[1];
		now.inspection_accepted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 93: // STATE 223
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_original_positive = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 94: // STATE 223
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_complete = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 95: // STATE 223
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_exact = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 96: // STATE 223
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_clean = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 97: // STATE 223
		;
		now.pc = trpt->bup.ovals[1];
		now.inspection_accepted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 99: // STATE 225
		;
		now.inspection_postcheck = trpt->bup.oval;
		;
		goto R999;

	case 100: // STATE 233
		;
		now.local_withheld = trpt->bup.ovals[2];
		now.result_projected = trpt->bup.ovals[1];
		now.envelope_valid = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 101: // STATE 233
		;
		now.local_withheld = trpt->bup.ovals[2];
		now.result_projected = trpt->bup.ovals[1];
		now.envelope_valid = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 102: // STATE 233
		;
		now.local_withheld = trpt->bup.ovals[1];
		now.result_projected = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 103: // STATE 235
		;
		now.local_output = trpt->bup.oval;
		;
		goto R999;

	case 104: // STATE 237
		;
		now.local_output = trpt->bup.oval;
		;
		goto R999;

	case 105: // STATE 246
		;
		now.pc = trpt->bup.ovals[1];
		inspection_withheld = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 106: // STATE 246
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 107: // STATE 246
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 108: // STATE 255
		;
		now.sealed_certainty = trpt->bup.ovals[7];
		now.retained_certainty = trpt->bup.ovals[6];
		now.sealed_withheld = trpt->bup.ovals[5];
		now.retained_withheld = trpt->bup.ovals[4];
		now.receipt_payload = trpt->bup.ovals[3];
		now.journal_output = trpt->bup.ovals[2];
		now.effect_state = trpt->bup.ovals[1];
		now.receipt = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 8);
		goto R999;

	case 109: // STATE 263
		;
		now.pc = trpt->bup.ovals[1];
		completed_while_revoked = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 110: // STATE 263
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 111: // STATE 263
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 112: // STATE 267
		;
		now.pc = trpt->bup.ovals[2];
		now.protocol_completed = trpt->bup.ovals[1];
		now.protocol_output = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;
;
		;
		
	case 114: // STATE 269
		;
		now.forwarded_parent = trpt->bup.oval;
		;
		goto R999;

	case 115: // STATE 270
		;
		now.forwarded_parent = trpt->bup.oval;
		;
		goto R999;

	case 116: // STATE 273
		;
		now.forwarded_actor = trpt->bup.oval;
		;
		goto R999;

	case 117: // STATE 274
		;
		now.forwarded_actor = trpt->bup.oval;
		;
		goto R999;

	case 118: // STATE 284
		;
		now.pc = trpt->bup.ovals[1];
		now.forwarded_certainty = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 119: // STATE 284
		;
		now.pc = trpt->bup.ovals[1];
		now.forwarded_certainty = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 120: // STATE 284
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 121: // STATE 286
		;
		now.delivery_check = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 123: // STATE 290
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 124: // STATE 293
		;
		now.pc = trpt->bup.ovals[1];
		now.inspection_precheck = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 125: // STATE 297
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 126: // STATE 299
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 128: // STATE 301
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 129: // STATE 302
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 130: // STATE 303
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 131: // STATE 306
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 132: // STATE 307
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 133: // STATE 322
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 134: // STATE 312
		;
		now.session_grant_epoch = trpt->bup.ovals[1];
		now.lease_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 135: // STATE 322
		;
		now.pc = trpt->bup.ovals[2];
		now.sealed_calls = trpt->bup.ovals[1];
		epoch_refreshed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 136: // STATE 322
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 137: // STATE 322
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 139: // STATE 333
		;
		now.inspection_original_positive = trpt->bup.ovals[3];
		now.inspection_clean = trpt->bup.ovals[2];
		now.inspection_exact = trpt->bup.ovals[1];
		now.inspection_complete = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 140: // STATE 344
		;
		now.pc = trpt->bup.ovals[1];
		now.inspection_accepted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 141: // STATE 344
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_original_positive = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 142: // STATE 344
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_complete = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 143: // STATE 344
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_exact = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 144: // STATE 344
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_clean = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 145: // STATE 344
		;
		now.pc = trpt->bup.ovals[1];
		now.inspection_accepted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 147: // STATE 349
		;
		now.delivery_check = trpt->bup.ovals[1];
		now.inspection_postcheck = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 148: // STATE 351
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 149: // STATE 353
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 150: // STATE 355
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 152: // STATE 357
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 153: // STATE 358
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 154: // STATE 359
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 155: // STATE 362
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 156: // STATE 363
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 157: // STATE 378
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 158: // STATE 368
		;
		now.session_grant_epoch = trpt->bup.ovals[1];
		now.lease_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 159: // STATE 378
		;
		now.pc = trpt->bup.ovals[2];
		now.sealed_calls = trpt->bup.ovals[1];
		epoch_refreshed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 160: // STATE 378
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 161: // STATE 378
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 162: // STATE 388
		;
		now.terminal = trpt->bup.ovals[1];
		delivered_once = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 163: // STATE 390
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 165: // STATE 392
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 166: // STATE 393
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 167: // STATE 394
		;
		now.attempt_tenant = trpt->bup.oval;
		;
		goto R999;

	case 168: // STATE 397
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 169: // STATE 398
		;
		now.attempt_original = trpt->bup.oval;
		;
		goto R999;

	case 170: // STATE 413
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 171: // STATE 403
		;
		now.session_grant_epoch = trpt->bup.ovals[1];
		now.lease_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 172: // STATE 413
		;
		now.pc = trpt->bup.ovals[2];
		now.sealed_calls = trpt->bup.ovals[1];
		epoch_refreshed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 173: // STATE 413
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 174: // STATE 413
		;
		now.pc = trpt->bup.ovals[1];
		now.sealed_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 175: // STATE 419
		;
		now.inspection_precheck = trpt->bup.oval;
		;
		goto R999;

	case 176: // STATE 421
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 177: // STATE 424
		;
		now.finished = trpt->bup.ovals[1];
		now.terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 179: // STATE 431
		;
		now.inspection_original_positive = trpt->bup.ovals[3];
		now.inspection_clean = trpt->bup.ovals[2];
		now.inspection_exact = trpt->bup.ovals[1];
		now.inspection_complete = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 180: // STATE 442
		;
		now.pc = trpt->bup.ovals[1];
		now.inspection_accepted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 181: // STATE 442
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_original_positive = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 182: // STATE 442
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_complete = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 183: // STATE 442
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_exact = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 184: // STATE 442
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_clean = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 185: // STATE 442
		;
		now.pc = trpt->bup.ovals[1];
		now.inspection_accepted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 187: // STATE 444
		;
		now.inspection_postcheck = trpt->bup.oval;
		;
		goto R999;

	case 188: // STATE 448
		;
		now.input_inspected = trpt->bup.oval;
		;
		goto R999;

	case 189: // STATE 455
		;
		now.pc = trpt->bup.ovals[1];
		positive_original_projected = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 190: // STATE 455
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 191: // STATE 455
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 192: // STATE 459
		;
		now.finished = trpt->bup.ovals[2];
		now.terminal = trpt->bup.ovals[1];
		inspection_denied = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 193: // STATE 463
		;
		now.inspection_precheck = trpt->bup.oval;
		;
		goto R999;

	case 194: // STATE 465
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 195: // STATE 468
		;
		now.finished = trpt->bup.ovals[1];
		now.terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 197: // STATE 475
		;
		now.inspection_original_positive = trpt->bup.ovals[3];
		now.inspection_clean = trpt->bup.ovals[2];
		now.inspection_exact = trpt->bup.ovals[1];
		now.inspection_complete = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 198: // STATE 486
		;
		now.pc = trpt->bup.ovals[1];
		now.inspection_accepted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 199: // STATE 486
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_original_positive = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 200: // STATE 486
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_complete = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 201: // STATE 486
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_exact = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 202: // STATE 486
		;
		now.pc = trpt->bup.ovals[2];
		now.inspection_accepted = trpt->bup.ovals[1];
		now.inspection_clean = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 203: // STATE 486
		;
		now.pc = trpt->bup.ovals[1];
		now.inspection_accepted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 205: // STATE 488
		;
		now.inspection_postcheck = trpt->bup.oval;
		;
		goto R999;

	case 206: // STATE 493
		;
		now.pc = trpt->bup.ovals[1];
		now.outbound_inspected = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 207: // STATE 497
		;
		now.finished = trpt->bup.ovals[2];
		now.terminal = trpt->bup.ovals[1];
		inspection_denied = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;
;
		;
		
	case 209: // STATE 504
		;
		now.finished = trpt->bup.ovals[2];
		now.terminal = trpt->bup.ovals[1];
		foreign_denied = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;
;
		;
		
	case 211: // STATE 509
		;
		now.finished = trpt->bup.ovals[2];
		now.terminal = trpt->bup.ovals[1];
		input_conflict = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 212: // STATE 511
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 214: // STATE 521
		;
		now.finished = trpt->bup.ovals[2];
		now.terminal = trpt->bup.ovals[1];
		unknown_retry_blocked = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 215: // STATE 527
		;
		now.pc = trpt->bup.ovals[3];
		now.protocol_completed = trpt->bup.ovals[2];
		now.protocol_output = trpt->bup.ovals[1];
		now.replayed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;
;
		
	case 216: // STATE 534
		goto R999;

	case 217: // STATE 550
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC External */

	case 218: // STATE 1
		;
	/* 0 */	((P2 *)_this)->request_id = trpt->bup.ovals[1];
		XX = 1;
		unrecv(now.requests, XX-1, 0, ((int)((P2 *)_this)->request_id), 1);
		((P2 *)_this)->request_id = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 219: // STATE 2
		;
		((P2 *)_this)->output = trpt->bup.oval;
		;
		goto R999;

	case 220: // STATE 3
		;
		((P2 *)_this)->output = trpt->bup.oval;
		;
		goto R999;

	case 221: // STATE 4
		;
		((P2 *)_this)->output = trpt->bup.oval;
		;
		goto R999;

	case 222: // STATE 7
		;
		((P2 *)_this)->certainty = trpt->bup.oval;
		;
		goto R999;
;
		
	case 223: // STATE 12
		goto R999;

	case 224: // STATE 8
		;
		((P2 *)_this)->certainty = trpt->bup.oval;
		;
		goto R999;

	case 225: // STATE 9
		;
		((P2 *)_this)->certainty = trpt->bup.oval;
		;
		goto R999;

	case 226: // STATE 10
		;
		((P2 *)_this)->certainty = trpt->bup.oval;
		;
		goto R999;

	case 227: // STATE 13
		;
		_m = unsend(now.results);
		;
		goto R999;
;
		;
		
	case 229: // STATE 19
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Crash */

	case 230: // STATE 4
		;
		crashed_once = trpt->bup.ovals[1];
		now.crash = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 231: // STATE 8
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Authority */
;
		;
		
	case 233: // STATE 11
		;
		authority_changed = trpt->bup.ovals[1];
		now.grant_active = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 234: // STATE 11
		;
		authority_changed = trpt->bup.oval;
		;
		goto R999;

	case 235: // STATE 11
		;
		authority_changed = trpt->bup.ovals[1];
		now.authority_available = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 236: // STATE 11
		;
		authority_changed = trpt->bup.ovals[1];
		now.grant_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 237: // STATE 11
		;
		authority_changed = trpt->bup.ovals[1];
		now.policy_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 238: // STATE 11
		;
		authority_changed = trpt->bup.ovals[1];
		now.key_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 239: // STATE 11
		;
		authority_changed = trpt->bup.ovals[1];
		now.credential_epoch = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 240: // STATE 15
		;
		p_restor(II);
		;
		;
		goto R999;
	}

