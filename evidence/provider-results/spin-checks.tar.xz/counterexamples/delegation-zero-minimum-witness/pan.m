#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM delegation_finishes */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(finished))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][1] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - delegation.pml:66 - [minimum = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)now.minimum);
		now.minimum = 0;
#ifdef VAR_RANGES
		logval("minimum", ((int)now.minimum));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - delegation.pml:66 - [minimum = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		(trpt+1)->bup.oval = ((int)now.minimum);
		now.minimum = 1;
#ifdef VAR_RANGES
		logval("minimum", ((int)now.minimum));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 3 - delegation.pml:66 - [minimum = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		(trpt+1)->bup.oval = ((int)now.minimum);
		now.minimum = 2;
#ifdef VAR_RANGES
		logval("minimum", ((int)now.minimum));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 6 - delegation.pml:67 - [required = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][6] = 1;
		(trpt+1)->bup.oval = ((int)now.required);
		now.required = 0;
#ifdef VAR_RANGES
		logval("required", ((int)now.required));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 7 - delegation.pml:67 - [required = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][7] = 1;
		(trpt+1)->bup.oval = ((int)now.required);
		now.required = 1;
#ifdef VAR_RANGES
		logval("required", ((int)now.required));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 10: // STATE 8 - delegation.pml:67 - [required = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[0][8] = 1;
		(trpt+1)->bup.oval = ((int)now.required);
		now.required = 2;
#ifdef VAR_RANGES
		logval("required", ((int)now.required));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 9 - delegation.pml:67 - [required = 3] (0:0:1 - 1)
		IfNotBlocked
		reached[0][9] = 1;
		(trpt+1)->bup.oval = ((int)now.required);
		now.required = 3;
#ifdef VAR_RANGES
		logval("required", ((int)now.required));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 12 - delegation.pml:69 - [((terminal==Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][12] = 1;
		if (!((now.terminal==8)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 13 - delegation.pml:74 - [((turns==3))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][13] = 1;
		if (!((((int)now.turns)==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 14 - delegation.pml:74 - [terminal = Exhausted] (0:0:1 - 1)
		IfNotBlocked
		reached[0][14] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 15: // STATE 15 - delegation.pml:75 - [((turns<3))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][15] = 1;
		if (!((((int)now.turns)<3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 16 - delegation.pml:76 - [complete_allowed = ((successful>=minimum)&&((covered&required)==required))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][16] = 1;
		(trpt+1)->bup.oval = ((int)now.complete_allowed);
		now.complete_allowed = ((((int)now.successful)>=((int)now.minimum))&&((((int)now.covered)&((int)now.required))==((int)now.required)));
#ifdef VAR_RANGES
		logval("complete_allowed", ((int)now.complete_allowed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 17 - delegation.pml:77 - [request_allowed = ((required==0)||((turns+1)<3))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][17] = 1;
		(trpt+1)->bup.oval = ((int)now.request_allowed);
		now.request_allowed = ((((int)now.required)==0)||((((int)now.turns)+1)<3));
#ifdef VAR_RANGES
		logval("request_allowed", ((int)now.request_allowed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 18 - delegation.pml:79 - [(((covered&required)==required))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][18] = 1;
		if (!(((((int)now.covered)&((int)now.required))==((int)now.required))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 19 - delegation.pml:79 - [permitted_requests = 3] (0:0:1 - 1)
		IfNotBlocked
		reached[0][19] = 1;
		(trpt+1)->bup.oval = ((int)now.permitted_requests);
		now.permitted_requests = 3;
#ifdef VAR_RANGES
		logval("permitted_requests", ((int)now.permitted_requests));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 21 - delegation.pml:80 - [permitted_requests = (required&(3^covered))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][21] = 1;
		(trpt+1)->bup.oval = ((int)now.permitted_requests);
		now.permitted_requests = (((int)now.required)&(3^((int)now.covered)));
#ifdef VAR_RANGES
		logval("permitted_requests", ((int)now.permitted_requests));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 24 - delegation.pml:95 - [assert((complete_allowed==((successful>=minimum)&&((covered&required)==required))))] (0:0:0 - 3)
		IfNotBlocked
		reached[0][24] = 1;
		spin_assert((((int)now.complete_allowed)==((((int)now.successful)>=((int)now.minimum))&&((((int)now.covered)&((int)now.required))==((int)now.required)))), "(complete_allowed==((successful>=minimum)&&((covered&required)==required)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 25 - delegation.pml:96 - [assert((((covered&required)==required)||(permitted_requests==(required&(3^covered)))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][25] = 1;
		spin_assert((((((int)now.covered)&((int)now.required))==((int)now.required))||(((int)now.permitted_requests)==(((int)now.required)&(3^((int)now.covered))))), "(((covered&required)==required)||(permitted_requests==(required&(3^covered))))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 26 - delegation.pml:97 - [assert((request_allowed==((required==0)||((turns+1)<3))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][26] = 1;
		spin_assert((((int)now.request_allowed)==((((int)now.required)==0)||((((int)now.turns)+1)<3))), "(request_allowed==((required==0)||((turns+1)<3)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 27 - delegation.pml:98 - [turns = (turns+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][27] = 1;
		(trpt+1)->bup.oval = ((int)now.turns);
		now.turns = (((int)now.turns)+1);
#ifdef VAR_RANGES
		logval("turns", ((int)now.turns));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 28 - delegation.pml:99 - [provider_dispatches = (provider_dispatches+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][28] = 1;
		(trpt+1)->bup.oval = ((int)now.provider_dispatches);
		now.provider_dispatches = (((int)now.provider_dispatches)+1);
#ifdef VAR_RANGES
		logval("provider_dispatches", ((int)now.provider_dispatches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 26: // STATE 29 - delegation.pml:113 - [(((complete_allowed&&(successful>=minimum))&&((covered&required)==required)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][29] = 1;
		if (!(((((int)now.complete_allowed)&&(((int)now.successful)>=((int)now.minimum)))&&((((int)now.covered)&((int)now.required))==((int)now.required)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 27: // STATE 30 - delegation.pml:113 - [terminal = Completed] (0:0:1 - 1)
		IfNotBlocked
		reached[0][30] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 7;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 28: // STATE 32 - delegation.pml:115 - [((successful<minimum))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][32] = 1;
		if (!((((int)now.successful)<((int)now.minimum))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 29: // STATE 33 - delegation.pml:115 - [early_completion_rejected = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][33] = 1;
		(trpt+1)->bup.oval = ((int)early_completion_rejected);
		early_completion_rejected = 1;
#ifdef VAR_RANGES
		logval("early_completion_rejected", ((int)early_completion_rejected));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 30: // STATE 38 - delegation.pml:118 - [(((successful>=minimum)&&!(((covered&required)==required))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][38] = 1;
		if (!(((((int)now.successful)>=((int)now.minimum))&& !(((((int)now.covered)&((int)now.required))==((int)now.required))))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 39 - delegation.pml:118 - [partial_completion_rejected = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][39] = 1;
		(trpt+1)->bup.oval = ((int)partial_completion_rejected);
		partial_completion_rejected = 1;
#ifdef VAR_RANGES
		logval("partial_completion_rejected", ((int)partial_completion_rejected));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 44 - delegation.pml:121 - [terminal = Invalid] (0:0:1 - 3)
		IfNotBlocked
		reached[0][44] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 6;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 47 - delegation.pml:126 - [selected = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][47] = 1;
		(trpt+1)->bup.oval = ((int)now.selected);
		now.selected = 1;
#ifdef VAR_RANGES
		logval("selected", ((int)now.selected));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 34: // STATE 48 - delegation.pml:126 - [selected = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[0][48] = 1;
		(trpt+1)->bup.oval = ((int)now.selected);
		now.selected = 2;
#ifdef VAR_RANGES
		logval("selected", ((int)now.selected));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 35: // STATE 51 - delegation.pml:128 - [(!(request_allowed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][51] = 1;
		if (!( !(((int)now.request_allowed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 36: // STATE 52 - delegation.pml:128 - [terminal = Invalid] (0:0:1 - 1)
		IfNotBlocked
		reached[0][52] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 6;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 37: // STATE 53 - delegation.pml:129 - [(request_allowed)] (0:0:0 - 1)
		IfNotBlocked
		reached[0][53] = 1;
		if (!(((int)now.request_allowed)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 38: // STATE 54 - delegation.pml:131 - [(((selected&permitted_requests)==0))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][54] = 1;
		if (!(((((int)now.selected)&((int)now.permitted_requests))==0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 39: // STATE 55 - delegation.pml:133 - [(((selected&covered)!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][55] = 1;
		if (!(((((int)now.selected)&((int)now.covered))!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 56 - delegation.pml:133 - [duplicate_rejected = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][56] = 1;
		(trpt+1)->bup.oval = ((int)duplicate_rejected);
		duplicate_rejected = 1;
#ifdef VAR_RANGES
		logval("duplicate_rejected", ((int)duplicate_rejected));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 41: // STATE 61 - delegation.pml:136 - [terminal = Invalid] (0:0:1 - 3)
		IfNotBlocked
		reached[0][61] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 6;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 42: // STATE 62 - delegation.pml:137 - [(((selected&permitted_requests)!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][62] = 1;
		if (!(((((int)now.selected)&((int)now.permitted_requests))!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 43: // STATE 63 - delegation.pml:139 - [((turns==3))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][63] = 1;
		if (!((((int)now.turns)==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 44: // STATE 64 - delegation.pml:139 - [terminal = Exhausted] (0:0:1 - 1)
		IfNotBlocked
		reached[0][64] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 45: // STATE 65 - delegation.pml:140 - [((turns<3))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][65] = 1;
		if (!((((int)now.turns)<3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 46: // STATE 66 - delegation.pml:141 - [peer_dispatches = (peer_dispatches+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][66] = 1;
		(trpt+1)->bup.oval = ((int)now.peer_dispatches);
		now.peer_dispatches = (((int)now.peer_dispatches)+1);
#ifdef VAR_RANGES
		logval("peer_dispatches", ((int)now.peer_dispatches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 47: // STATE 67 - delegation.pml:143 - [successful = (successful+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][67] = 1;
		(trpt+1)->bup.oval = ((int)now.successful);
		now.successful = (((int)now.successful)+1);
#ifdef VAR_RANGES
		logval("successful", ((int)now.successful));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 48: // STATE 68 - delegation.pml:144 - [retained_successful = (retained_successful+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][68] = 1;
		(trpt+1)->bup.oval = ((int)now.retained_successful);
		now.retained_successful = (((int)now.retained_successful)+1);
#ifdef VAR_RANGES
		logval("retained_successful", ((int)now.retained_successful));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 49: // STATE 69 - delegation.pml:145 - [covered = (covered|selected)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][69] = 1;
		(trpt+1)->bup.oval = ((int)now.covered);
		now.covered = (((int)now.covered)|((int)now.selected));
#ifdef VAR_RANGES
		logval("covered", ((int)now.covered));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 50: // STATE 70 - delegation.pml:146 - [retained_covered = (retained_covered|selected)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][70] = 1;
		(trpt+1)->bup.oval = ((int)now.retained_covered);
		now.retained_covered = (((int)now.retained_covered)|((int)now.selected));
#ifdef VAR_RANGES
		logval("retained_covered", ((int)now.retained_covered));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 51: // STATE 71 - delegation.pml:147 - [((first_peer==0))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][71] = 1;
		if (!((((int)now.first_peer)==0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 52: // STATE 72 - delegation.pml:147 - [first_peer = selected] (0:0:1 - 1)
		IfNotBlocked
		reached[0][72] = 1;
		(trpt+1)->bup.oval = ((int)now.first_peer);
		now.first_peer = ((int)now.selected);
#ifdef VAR_RANGES
		logval("first_peer", ((int)now.first_peer));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 53: // STATE 77 - delegation.pml:149 - [(!(replayed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][77] = 1;
		if (!( !(((int)now.replayed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 54: // STATE 78 - delegation.pml:38 - [saved_provider_dispatches = provider_dispatches] (0:0:1 - 1)
		IfNotBlocked
		reached[0][78] = 1;
		(trpt+1)->bup.oval = ((int)now.saved_provider_dispatches);
		now.saved_provider_dispatches = ((int)now.provider_dispatches);
#ifdef VAR_RANGES
		logval("saved_provider_dispatches", ((int)now.saved_provider_dispatches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 55: // STATE 79 - delegation.pml:39 - [saved_peer_dispatches = peer_dispatches] (0:0:1 - 1)
		IfNotBlocked
		reached[0][79] = 1;
		(trpt+1)->bup.oval = ((int)now.saved_peer_dispatches);
		now.saved_peer_dispatches = ((int)now.peer_dispatches);
#ifdef VAR_RANGES
		logval("saved_peer_dispatches", ((int)now.saved_peer_dispatches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 56: // STATE 80 - delegation.pml:40 - [successful = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][80] = 1;
		(trpt+1)->bup.oval = ((int)now.successful);
		now.successful = 0;
#ifdef VAR_RANGES
		logval("successful", ((int)now.successful));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 57: // STATE 81 - delegation.pml:42 - [((successful<retained_successful))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][81] = 1;
		if (!((((int)now.successful)<((int)now.retained_successful))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 58: // STATE 82 - delegation.pml:42 - [successful = (successful+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][82] = 1;
		(trpt+1)->bup.oval = ((int)now.successful);
		now.successful = (((int)now.successful)+1);
#ifdef VAR_RANGES
		logval("successful", ((int)now.successful));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 59: // STATE 88 - delegation.pml:45 - [covered = retained_covered] (0:0:1 - 3)
		IfNotBlocked
		reached[0][88] = 1;
		(trpt+1)->bup.oval = ((int)now.covered);
		now.covered = ((int)now.retained_covered);
#ifdef VAR_RANGES
		logval("covered", ((int)now.covered));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 60: // STATE 89 - delegation.pml:46 - [assert((successful==retained_successful))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][89] = 1;
		spin_assert((((int)now.successful)==((int)now.retained_successful)), "(successful==retained_successful)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 61: // STATE 90 - delegation.pml:47 - [assert((covered==retained_covered))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][90] = 1;
		spin_assert((((int)now.covered)==((int)now.retained_covered)), "(covered==retained_covered)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 62: // STATE 91 - delegation.pml:48 - [assert((provider_dispatches==saved_provider_dispatches))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][91] = 1;
		spin_assert((((int)now.provider_dispatches)==((int)now.saved_provider_dispatches)), "(provider_dispatches==saved_provider_dispatches)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 63: // STATE 92 - delegation.pml:49 - [assert((peer_dispatches==saved_peer_dispatches))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][92] = 1;
		spin_assert((((int)now.peer_dispatches)==((int)now.saved_peer_dispatches)), "(peer_dispatches==saved_peer_dispatches)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 64: // STATE 93 - delegation.pml:50 - [replayed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][93] = 1;
		(trpt+1)->bup.oval = ((int)now.replayed);
		now.replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)now.replayed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 65: // STATE 98 - delegation.pml:152 - [terminal = DelegateFailed] (0:0:1 - 1)
		IfNotBlocked
		reached[0][98] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 3;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 66: // STATE 107 - delegation.pml:157 - [terminal = Invalid] (0:0:1 - 1)
		IfNotBlocked
		reached[0][107] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 6;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 67: // STATE 108 - delegation.pml:158 - [terminal = Unavailable] (0:0:1 - 1)
		IfNotBlocked
		reached[0][108] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 68: // STATE 109 - delegation.pml:159 - [terminal = Unknown] (0:0:1 - 1)
		IfNotBlocked
		reached[0][109] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 69: // STATE 110 - delegation.pml:160 - [terminal = Stopped] (0:0:1 - 1)
		IfNotBlocked
		reached[0][110] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 70: // STATE 115 - delegation.pml:164 - [((terminal!=Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][115] = 1;
		if (!((now.terminal!=8)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 71: // STATE 120 - delegation.pml:166 - [assert(((terminal!=Completed)||(successful>=minimum)))] (0:0:0 - 3)
		IfNotBlocked
		reached[0][120] = 1;
		spin_assert(((now.terminal!=7)||(((int)now.successful)>=((int)now.minimum))), "((terminal!=7)||(successful>=minimum))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 72: // STATE 121 - delegation.pml:167 - [assert(((terminal!=Completed)||((covered&required)==required)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][121] = 1;
		spin_assert(((now.terminal!=7)||((((int)now.covered)&((int)now.required))==((int)now.required))), "((terminal!=7)||((covered&required)==required))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 73: // STATE 122 - delegation.pml:168 - [assert((successful==retained_successful))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][122] = 1;
		spin_assert((((int)now.successful)==((int)now.retained_successful)), "(successful==retained_successful)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 74: // STATE 123 - delegation.pml:169 - [assert((covered==retained_covered))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][123] = 1;
		spin_assert((((int)now.covered)==((int)now.retained_covered)), "(covered==retained_covered)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 75: // STATE 124 - delegation.pml:170 - [assert((provider_dispatches<=3))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][124] = 1;
		spin_assert((((int)now.provider_dispatches)<=3), "(provider_dispatches<=3)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 76: // STATE 125 - delegation.pml:171 - [assert((peer_dispatches<3))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][125] = 1;
		spin_assert((((int)now.peer_dispatches)<3), "(peer_dispatches<3)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 77: // STATE 126 - delegation.pml:172 - [assert((successful<=peer_dispatches))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][126] = 1;
		spin_assert((((int)now.successful)<=((int)now.peer_dispatches)), "(successful<=peer_dispatches)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 78: // STATE 127 - delegation.pml:173 - [finished = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][127] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 79: // STATE 128 - delegation.pml:178 - [assert(!(((((terminal==Completed)&&(minimum==0))&&(required==0))&&(successful==0))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][128] = 1;
		spin_assert( !(((((now.terminal==7)&&(((int)now.minimum)==0))&&(((int)now.required)==0))&&(((int)now.successful)==0))), " !(((((terminal==7)&&(minimum==0))&&(required==0))&&(successful==0)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 80: // STATE 129 - delegation.pml:195 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][129] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

