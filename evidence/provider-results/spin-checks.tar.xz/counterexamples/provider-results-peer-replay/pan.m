#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM provider_results_settle */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(finished))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[4][1] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[4][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - provider-results.pml:410 - [prior_peer_calls = 0] (0:8:2 - 1)
		IfNotBlocked
		reached[3][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.prior_peer_calls);
		now.prior_peer_calls = 0;
#ifdef VAR_RANGES
		logval("prior_peer_calls", ((int)now.prior_peer_calls));
#endif
		;
		/* merge: .(goto)(8, 4, 8) */
		reached[3][4] = 1;
		;
		/* merge: peer_calls = prior_peer_calls(8, 5, 8) */
		reached[3][5] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.peer_calls);
		now.peer_calls = ((int)now.prior_peer_calls);
#ifdef VAR_RANGES
		logval("peer_calls", ((int)now.peer_calls));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 6: // STATE 2 - provider-results.pml:410 - [prior_peer_calls = 1] (0:8:2 - 1)
		IfNotBlocked
		reached[3][2] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.prior_peer_calls);
		now.prior_peer_calls = 1;
#ifdef VAR_RANGES
		logval("prior_peer_calls", ((int)now.prior_peer_calls));
#endif
		;
		/* merge: .(goto)(8, 4, 8) */
		reached[3][4] = 1;
		;
		/* merge: peer_calls = prior_peer_calls(8, 5, 8) */
		reached[3][5] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.peer_calls);
		now.peer_calls = ((int)now.prior_peer_calls);
#ifdef VAR_RANGES
		logval("peer_calls", ((int)now.peer_calls));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 7: // STATE 5 - provider-results.pml:411 - [peer_calls = prior_peer_calls] (0:8:1 - 3)
		IfNotBlocked
		reached[3][5] = 1;
		(trpt+1)->bup.oval = ((int)now.peer_calls);
		now.peer_calls = ((int)now.prior_peer_calls);
#ifdef VAR_RANGES
		logval("peer_calls", ((int)now.peer_calls));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 6 - provider-results.pml:412 - [delegate_returns = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[3][6] = 1;
		(trpt+1)->bup.oval = ((int)now.delegate_returns);
		now.delegate_returns = 0;
#ifdef VAR_RANGES
		logval("delegate_returns", ((int)now.delegate_returns));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 7 - provider-results.pml:412 - [delegate_returns = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][7] = 1;
		(trpt+1)->bup.oval = ((int)now.delegate_returns);
		now.delegate_returns = 1;
#ifdef VAR_RANGES
		logval("delegate_returns", ((int)now.delegate_returns));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 10: // STATE 10 - provider-results.pml:413 - [(run Provider())] (0:0:0 - 3)
		IfNotBlocked
		reached[3][10] = 1;
		if (!(addproc(II, 1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 11 - provider-results.pml:413 - [(run Crash())] (0:0:0 - 1)
		IfNotBlocked
		reached[3][11] = 1;
		if (!(addproc(II, 1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 12 - provider-results.pml:413 - [(run Host())] (0:0:0 - 1)
		IfNotBlocked
		reached[3][12] = 1;
		if (!(addproc(II, 1, 2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 14 - provider-results.pml:415 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[3][14] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Host */
	case 14: // STATE 1 - provider-results.pml:216 - [(finished)] (0:0:0 - 1)
		IfNotBlocked
		reached[2][1] = 1;
		if (!(((int)now.finished)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 15: // STATE 3 - provider-results.pml:217 - [(!(finished))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][3] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 4 - provider-results.pml:224 - [(crash)] (10:0:1 - 1)
		IfNotBlocked
		reached[2][4] = 1;
		if (!(((int)now.crash)))
			continue;
		/* merge: crash = 0(0, 5, 10) */
		reached[2][5] = 1;
		(trpt+1)->bup.oval = ((int)now.crash);
		now.crash = 0;
#ifdef VAR_RANGES
		logval("crash", ((int)now.crash));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 17: // STATE 6 - provider-results.pml:227 - [(((inference_state==Executing)&&inference_observed))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][6] = 1;
		if (!(((now.inference_state==10)&&((int)now.inference_observed))))
			continue;
		/* merge: transient_known_lost = !(((response_kind==TransportUnknown)||(response_kind==Nonterminal)))(194, 7, 194) */
		reached[2][7] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)transient_known_lost);
		transient_known_lost =  !(((now.response_kind==20)||(now.response_kind==19)));
#ifdef VAR_RANGES
		logval("transient_known_lost", ((int)transient_known_lost));
#endif
		;
		/* merge: .(goto)(194, 11, 194) */
		reached[2][11] = 1;
		;
		/* merge: pc = 0(194, 12, 194) */
		reached[2][12] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 18: // STATE 9 - provider-results.pml:229 - [(1)] (194:0:1 - 1)
		IfNotBlocked
		reached[2][9] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(194, 11, 194) */
		reached[2][11] = 1;
		;
		/* merge: pc = 0(194, 12, 194) */
		reached[2][12] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 19: // STATE 12 - provider-results.pml:231 - [pc = 0] (0:194:1 - 3)
		IfNotBlocked
		reached[2][12] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 20: // STATE 13 - provider-results.pml:232 - [((!(crash)&&((pc!=3)||response_ready)))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][13] = 1;
		if (!(( !(((int)now.crash))&&((((int)now.pc)!=3)||((int)now.response_ready)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 14 - provider-results.pml:234 - [((pc==0))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][14] = 1;
		if (!((((int)now.pc)==0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 15 - provider-results.pml:236 - [((terminal!=Running))] (194:0:1 - 1)
		IfNotBlocked
		reached[2][15] = 1;
		if (!((now.terminal!=4)))
			continue;
		/* merge: pc = 13(0, 16, 194) */
		reached[2][16] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 35, 194) */
		reached[2][35] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 23: // STATE 17 - provider-results.pml:237 - [((terminal==Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][17] = 1;
		if (!((now.terminal==4)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 18 - provider-results.pml:239 - [((inference_state==Free))] (194:0:3 - 1)
		IfNotBlocked
		reached[2][18] = 1;
		if (!((now.inference_state==12)))
			continue;
		/* merge: frozen_descriptor = 1(194, 19, 194) */
		reached[2][19] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.frozen_descriptor);
		now.frozen_descriptor = 1;
#ifdef VAR_RANGES
		logval("frozen_descriptor", ((int)now.frozen_descriptor));
#endif
		;
		/* merge: inference_state = Prepared(194, 20, 194) */
		reached[2][20] = 1;
		(trpt+1)->bup.ovals[1] = now.inference_state;
		now.inference_state = 11;
#ifdef VAR_RANGES
		logval("inference_state", now.inference_state);
#endif
		;
		/* merge: pc = 1(194, 21, 194) */
		reached[2][21] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 33, 194) */
		reached[2][33] = 1;
		;
		/* merge: .(goto)(0, 35, 194) */
		reached[2][35] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 25: // STATE 22 - provider-results.pml:241 - [((inference_state==Prepared))] (194:0:1 - 1)
		IfNotBlocked
		reached[2][22] = 1;
		if (!((now.inference_state==11)))
			continue;
		/* merge: pc = 1(0, 23, 194) */
		reached[2][23] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 33, 194) */
		reached[2][33] = 1;
		;
		/* merge: .(goto)(0, 35, 194) */
		reached[2][35] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 26: // STATE 24 - provider-results.pml:242 - [(((inference_state==Executing)||(inference_state==Uncertain)))] (194:0:4 - 1)
		IfNotBlocked
		reached[2][24] = 1;
		if (!(((now.inference_state==10)||(now.inference_state==8))))
			continue;
		/* merge: inference_state = Uncertain(194, 25, 194) */
		reached[2][25] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.inference_state;
		now.inference_state = 8;
#ifdef VAR_RANGES
		logval("inference_state", now.inference_state);
#endif
		;
		/* merge: unknown_seen = 1(194, 26, 194) */
		reached[2][26] = 1;
		(trpt+1)->bup.ovals[1] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: pending_terminal = Blocked(194, 27, 194) */
		reached[2][27] = 1;
		(trpt+1)->bup.ovals[2] = now.pending_terminal;
		now.pending_terminal = 1;
#ifdef VAR_RANGES
		logval("pending_terminal", now.pending_terminal);
#endif
		;
		/* merge: pc = 12(194, 28, 194) */
		reached[2][28] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 12;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 33, 194) */
		reached[2][33] = 1;
		;
		/* merge: .(goto)(0, 35, 194) */
		reached[2][35] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 27: // STATE 29 - provider-results.pml:245 - [((inference_state==Known))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][29] = 1;
		if (!((now.inference_state==9)))
			continue;
		/* merge: cached_inference = 1(194, 30, 194) */
		reached[2][30] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)cached_inference);
		cached_inference = 1;
#ifdef VAR_RANGES
		logval("cached_inference", ((int)cached_inference));
#endif
		;
		/* merge: pc = 7(194, 31, 194) */
		reached[2][31] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 7;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 33, 194) */
		reached[2][33] = 1;
		;
		/* merge: .(goto)(0, 35, 194) */
		reached[2][35] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 28: // STATE 36 - provider-results.pml:248 - [((pc==1))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][36] = 1;
		if (!((((int)now.pc)==1)))
			continue;
		/* merge: inference_state = Executing(194, 37, 194) */
		reached[2][37] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.inference_state;
		now.inference_state = 10;
#ifdef VAR_RANGES
		logval("inference_state", now.inference_state);
#endif
		;
		/* merge: pc = 2(194, 38, 194) */
		reached[2][38] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 2;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 29: // STATE 39 - provider-results.pml:249 - [((pc==2))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][39] = 1;
		if (!((((int)now.pc)==2)))
			continue;
		/* merge: inference_calls = (inference_calls+1)(194, 40, 194) */
		reached[2][40] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.inference_calls);
		now.inference_calls = (((int)now.inference_calls)+1);
#ifdef VAR_RANGES
		logval("inference_calls", ((int)now.inference_calls));
#endif
		;
		/* merge: pc = 3(194, 41, 194) */
		reached[2][41] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 30: // STATE 42 - provider-results.pml:250 - [((pc==3))] (51:0:1 - 1)
		IfNotBlocked
		reached[2][42] = 1;
		if (!((((int)now.pc)==3)))
			continue;
		/* merge: inference_observed = 1(0, 43, 51) */
		reached[2][43] = 1;
		(trpt+1)->bup.oval = ((int)now.inference_observed);
		now.inference_observed = 1;
#ifdef VAR_RANGES
		logval("inference_observed", ((int)now.inference_observed));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 31: // STATE 44 - provider-results.pml:253 - [(((response_kind==TransportUnknown)||(response_kind==Nonterminal)))] (194:0:4 - 1)
		IfNotBlocked
		reached[2][44] = 1;
		if (!(((now.response_kind==20)||(now.response_kind==19))))
			continue;
		/* merge: inference_state = Uncertain(194, 45, 194) */
		reached[2][45] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.inference_state;
		now.inference_state = 8;
#ifdef VAR_RANGES
		logval("inference_state", now.inference_state);
#endif
		;
		/* merge: unknown_seen = 1(194, 46, 194) */
		reached[2][46] = 1;
		(trpt+1)->bup.ovals[1] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: pending_terminal = Blocked(194, 47, 194) */
		reached[2][47] = 1;
		(trpt+1)->bup.ovals[2] = now.pending_terminal;
		now.pending_terminal = 1;
#ifdef VAR_RANGES
		logval("pending_terminal", now.pending_terminal);
#endif
		;
		/* merge: pc = 12(194, 48, 194) */
		reached[2][48] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 12;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 52, 194) */
		reached[2][52] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 32: // STATE 50 - provider-results.pml:256 - [pc = 4] (0:0:1 - 1)
		IfNotBlocked
		reached[2][50] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 53 - provider-results.pml:258 - [((pc==4))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][53] = 1;
		if (!((((int)now.pc)==4)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 34: // STATE 54 - provider-results.pml:158 - [eligible = 0] (0:88:6 - 1)
		IfNotBlocked
		reached[2][54] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((int)now.eligible);
		now.eligible = 0;
#ifdef VAR_RANGES
		logval("eligible", ((int)now.eligible));
#endif
		;
		/* merge: first_value = 0(88, 55, 88) */
		reached[2][55] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.first_value);
		now.first_value = 0;
#ifdef VAR_RANGES
		logval("first_value", ((int)now.first_value));
#endif
		;
		/* merge: conflicting = 0(88, 56, 88) */
		reached[2][56] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.conflicting);
		now.conflicting = 0;
#ifdef VAR_RANGES
		logval("conflicting", ((int)now.conflicting));
#endif
		;
		/* merge: malformed = 0(88, 57, 88) */
		reached[2][57] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.malformed);
		now.malformed = 0;
#ifdef VAR_RANGES
		logval("malformed", ((int)now.malformed));
#endif
		;
		/* merge: bad_shape = 0(88, 58, 88) */
		reached[2][58] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.bad_shape);
		now.bad_shape = 0;
#ifdef VAR_RANGES
		logval("bad_shape", ((int)now.bad_shape));
#endif
		;
		/* merge: i = 0(88, 59, 88) */
		reached[2][59] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.i);
		now.i = 0;
#ifdef VAR_RANGES
		logval("i", ((int)now.i));
#endif
		;
		/* merge: .(goto)(0, 89, 88) */
		reached[2][89] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 35: // STATE 60 - provider-results.pml:162 - [((i<message_count))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][60] = 1;
		if (!((((int)now.i)<((int)now.message_count))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 36: // STATE 61 - provider-results.pml:164 - [((((phase[i]==0)||(phase[i]==1))||(phase[i]==2)))] (79:0:1 - 1)
		IfNotBlocked
		reached[2][61] = 1;
		if (!((((((int)now.phase[ Index(((int)now.i), 3) ])==0)||(((int)now.phase[ Index(((int)now.i), 3) ])==1))||(((int)now.phase[ Index(((int)now.i), 3) ])==2))))
			continue;
		/* merge: eligible = (eligible+1)(0, 62, 79) */
		reached[2][62] = 1;
		(trpt+1)->bup.oval = ((int)now.eligible);
		now.eligible = (((int)now.eligible)+1);
#ifdef VAR_RANGES
		logval("eligible", ((int)now.eligible));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 37: // STATE 63 - provider-results.pml:167 - [(((text_blocks[i]!=1)||!(string_text[i])))] (88:0:2 - 1)
		IfNotBlocked
		reached[2][63] = 1;
		if (!(((((int)now.text_blocks[ Index(((int)now.i), 3) ])!=1)|| !(((int)now.string_text[ Index(((int)now.i), 3) ])))))
			continue;
		/* merge: bad_shape = 1(88, 64, 88) */
		reached[2][64] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.bad_shape);
		now.bad_shape = 1;
#ifdef VAR_RANGES
		logval("bad_shape", ((int)now.bad_shape));
#endif
		;
		/* merge: .(goto)(88, 80, 88) */
		reached[2][80] = 1;
		;
		/* merge: .(goto)(88, 84, 88) */
		reached[2][84] = 1;
		;
		/* merge: i = (i+1)(88, 85, 88) */
		reached[2][85] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.i);
		now.i = (((int)now.i)+1);
#ifdef VAR_RANGES
		logval("i", ((int)now.i));
#endif
		;
		/* merge: .(goto)(0, 89, 88) */
		reached[2][89] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 38: // STATE 66 - provider-results.pml:170 - [((value[i]==3))] (88:0:2 - 1)
		IfNotBlocked
		reached[2][66] = 1;
		if (!((((int)now.value[ Index(((int)now.i), 3) ])==3)))
			continue;
		/* merge: malformed = 1(88, 67, 88) */
		reached[2][67] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.malformed);
		now.malformed = 1;
#ifdef VAR_RANGES
		logval("malformed", ((int)now.malformed));
#endif
		;
		/* merge: .(goto)(88, 78, 88) */
		reached[2][78] = 1;
		;
		/* merge: .(goto)(88, 80, 88) */
		reached[2][80] = 1;
		;
		/* merge: .(goto)(88, 84, 88) */
		reached[2][84] = 1;
		;
		/* merge: i = (i+1)(88, 85, 88) */
		reached[2][85] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.i);
		now.i = (((int)now.i)+1);
#ifdef VAR_RANGES
		logval("i", ((int)now.i));
#endif
		;
		/* merge: .(goto)(0, 89, 88) */
		reached[2][89] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 39: // STATE 68 - provider-results.pml:171 - [((value[i]!=3))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][68] = 1;
		if (!((((int)now.value[ Index(((int)now.i), 3) ])!=3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 69 - provider-results.pml:173 - [((first_value==0))] (88:0:2 - 1)
		IfNotBlocked
		reached[2][69] = 1;
		if (!((((int)now.first_value)==0)))
			continue;
		/* merge: first_value = value[i](88, 70, 88) */
		reached[2][70] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.first_value);
		now.first_value = ((int)now.value[ Index(((int)now.i), 3) ]);
#ifdef VAR_RANGES
		logval("first_value", ((int)now.first_value));
#endif
		;
		/* merge: .(goto)(88, 76, 88) */
		reached[2][76] = 1;
		;
		/* merge: .(goto)(88, 78, 88) */
		reached[2][78] = 1;
		;
		/* merge: .(goto)(88, 80, 88) */
		reached[2][80] = 1;
		;
		/* merge: .(goto)(88, 84, 88) */
		reached[2][84] = 1;
		;
		/* merge: i = (i+1)(88, 85, 88) */
		reached[2][85] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.i);
		now.i = (((int)now.i)+1);
#ifdef VAR_RANGES
		logval("i", ((int)now.i));
#endif
		;
		/* merge: .(goto)(0, 89, 88) */
		reached[2][89] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 41: // STATE 71 - provider-results.pml:174 - [(((first_value!=0)&&(value[i]!=first_value)))] (88:0:2 - 1)
		IfNotBlocked
		reached[2][71] = 1;
		if (!(((((int)now.first_value)!=0)&&(((int)now.value[ Index(((int)now.i), 3) ])!=((int)now.first_value)))))
			continue;
		/* merge: conflicting = 1(88, 72, 88) */
		reached[2][72] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.conflicting);
		now.conflicting = 1;
#ifdef VAR_RANGES
		logval("conflicting", ((int)now.conflicting));
#endif
		;
		/* merge: .(goto)(88, 76, 88) */
		reached[2][76] = 1;
		;
		/* merge: .(goto)(88, 78, 88) */
		reached[2][78] = 1;
		;
		/* merge: .(goto)(88, 80, 88) */
		reached[2][80] = 1;
		;
		/* merge: .(goto)(88, 84, 88) */
		reached[2][84] = 1;
		;
		/* merge: i = (i+1)(88, 85, 88) */
		reached[2][85] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.i);
		now.i = (((int)now.i)+1);
#ifdef VAR_RANGES
		logval("i", ((int)now.i));
#endif
		;
		/* merge: .(goto)(0, 89, 88) */
		reached[2][89] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 42: // STATE 74 - provider-results.pml:175 - [(1)] (88:0:1 - 1)
		IfNotBlocked
		reached[2][74] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(88, 76, 88) */
		reached[2][76] = 1;
		;
		/* merge: .(goto)(88, 78, 88) */
		reached[2][78] = 1;
		;
		/* merge: .(goto)(88, 80, 88) */
		reached[2][80] = 1;
		;
		/* merge: .(goto)(88, 84, 88) */
		reached[2][84] = 1;
		;
		/* merge: i = (i+1)(88, 85, 88) */
		reached[2][85] = 1;
		(trpt+1)->bup.oval = ((int)now.i);
		now.i = (((int)now.i)+1);
#ifdef VAR_RANGES
		logval("i", ((int)now.i));
#endif
		;
		/* merge: .(goto)(0, 89, 88) */
		reached[2][89] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 43: // STATE 82 - provider-results.pml:184 - [(1)] (88:0:1 - 1)
		IfNotBlocked
		reached[2][82] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(88, 84, 88) */
		reached[2][84] = 1;
		;
		/* merge: i = (i+1)(88, 85, 88) */
		reached[2][85] = 1;
		(trpt+1)->bup.oval = ((int)now.i);
		now.i = (((int)now.i)+1);
#ifdef VAR_RANGES
		logval("i", ((int)now.i));
#endif
		;
		/* merge: .(goto)(0, 89, 88) */
		reached[2][89] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 44: // STATE 85 - provider-results.pml:187 - [i = (i+1)] (0:88:1 - 10)
		IfNotBlocked
		reached[2][85] = 1;
		(trpt+1)->bup.oval = ((int)now.i);
		now.i = (((int)now.i)+1);
#ifdef VAR_RANGES
		logval("i", ((int)now.i));
#endif
		;
		/* merge: .(goto)(0, 89, 88) */
		reached[2][89] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 45: // STATE 91 - provider-results.pml:190 - [selected = ((((((eligible>0)&&!(bad_shape))&&!(malformed))&&!(conflicting))&&!(refusal))&&(response_kind!=Incomplete))] (0:194:2 - 3)
		IfNotBlocked
		reached[2][91] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.selected);
		now.selected = ((((((((int)now.eligible)>0)&& !(((int)now.bad_shape)))&& !(((int)now.malformed)))&& !(((int)now.conflicting)))&& !(((int)now.refusal)))&&(now.response_kind!=21));
#ifdef VAR_RANGES
		logval("selected", ((int)now.selected));
#endif
		;
		/* merge: assert((selected==(((((((response_kind==Single)||(response_kind==Repeated))||(response_kind==Triplicated))||(response_kind==CommentaryFinal))||(response_kind==SchemaInvalid))||(response_kind==RepeatedSchemaInvalid))||(response_kind==RequestInvalid))))(194, 92, 194) */
		reached[2][92] = 1;
		spin_assert((((int)now.selected)==(((((((now.response_kind==30)||(now.response_kind==29))||(now.response_kind==28))||(now.response_kind==23))||(now.response_kind==18))||(now.response_kind==17))||(now.response_kind==16))), "(selected==(((((((response_kind==30)||(response_kind==29))||(response_kind==28))||(response_kind==23))||(response_kind==18))||(response_kind==17))||(response_kind==16)))", II, tt, t);
		/* merge: pc = 5(194, 94, 194) */
		reached[2][94] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 5;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 46: // STATE 95 - provider-results.pml:259 - [((pc==5))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][95] = 1;
		if (!((((int)now.pc)==5)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 47: // STATE 96 - provider-results.pml:263 - [((selected&&schema_valid))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][96] = 1;
		if (!((((int)now.selected)&&((int)now.schema_valid))))
			continue;
		/* merge: local_status = Valid(194, 97, 194) */
		reached[2][97] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.local_status;
		now.local_status = 6;
#ifdef VAR_RANGES
		logval("local_status", now.local_status);
#endif
		;
		/* merge: .(goto)(194, 101, 194) */
		reached[2][101] = 1;
		;
		/* merge: pc = 6(194, 102, 194) */
		reached[2][102] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 6;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 48: // STATE 99 - provider-results.pml:264 - [local_status = Invalid] (0:194:2 - 1)
		IfNotBlocked
		reached[2][99] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.local_status;
		now.local_status = 5;
#ifdef VAR_RANGES
		logval("local_status", now.local_status);
#endif
		;
		/* merge: .(goto)(194, 101, 194) */
		reached[2][101] = 1;
		;
		/* merge: pc = 6(194, 102, 194) */
		reached[2][102] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 6;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 49: // STATE 102 - provider-results.pml:266 - [pc = 6] (0:194:1 - 3)
		IfNotBlocked
		reached[2][102] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 6;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 50: // STATE 103 - provider-results.pml:267 - [((pc==6))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][103] = 1;
		if (!((((int)now.pc)==6)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 51: // STATE 104 - provider-results.pml:210 - [retained_status = local_status] (0:194:4 - 1)
		IfNotBlocked
		reached[2][104] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.retained_status;
		now.retained_status = now.local_status;
#ifdef VAR_RANGES
		logval("retained_status", now.retained_status);
#endif
		;
		/* merge: sealed_status = local_status(194, 105, 194) */
		reached[2][105] = 1;
		(trpt+1)->bup.ovals[1] = now.sealed_status;
		now.sealed_status = now.local_status;
#ifdef VAR_RANGES
		logval("sealed_status", now.sealed_status);
#endif
		;
		/* merge: inference_state = Known(194, 106, 194) */
		reached[2][106] = 1;
		(trpt+1)->bup.ovals[2] = now.inference_state;
		now.inference_state = 9;
#ifdef VAR_RANGES
		logval("inference_state", now.inference_state);
#endif
		;
		/* merge: pc = 7(194, 107, 194) */
		reached[2][107] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 7;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 52: // STATE 109 - provider-results.pml:277 - [((pc==7))] (130:0:1 - 1)
		IfNotBlocked
		reached[2][109] = 1;
		if (!((((int)now.pc)==7)))
			continue;
		/* merge: admitted = ((retained_status==Valid)&&request_valid)(0, 110, 130) */
		reached[2][110] = 1;
		(trpt+1)->bup.oval = ((int)now.admitted);
		now.admitted = ((now.retained_status==6)&&((int)now.request_valid));
#ifdef VAR_RANGES
		logval("admitted", ((int)now.admitted));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 53: // STATE 111 - provider-results.pml:283 - [(!(admitted))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][111] = 1;
		if (!( !(((int)now.admitted))))
			continue;
		/* merge: pending_terminal = Failed(194, 112, 194) */
		reached[2][112] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.pending_terminal;
		now.pending_terminal = 2;
#ifdef VAR_RANGES
		logval("pending_terminal", now.pending_terminal);
#endif
		;
		/* merge: pc = 12(194, 113, 194) */
		reached[2][113] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 12;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 131, 194) */
		reached[2][131] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 54: // STATE 114 - provider-results.pml:285 - [(admitted)] (0:0:0 - 1)
		IfNotBlocked
		reached[2][114] = 1;
		if (!(((int)now.admitted)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 55: // STATE 115 - provider-results.pml:287 - [((delegate_state==Free))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][115] = 1;
		if (!((now.delegate_state==12)))
			continue;
		/* merge: delegate_state = Prepared(194, 116, 194) */
		reached[2][116] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.delegate_state;
		now.delegate_state = 11;
#ifdef VAR_RANGES
		logval("delegate_state", now.delegate_state);
#endif
		;
		/* merge: pc = 8(194, 117, 194) */
		reached[2][117] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 8;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 129, 194) */
		reached[2][129] = 1;
		;
		/* merge: .(goto)(0, 131, 194) */
		reached[2][131] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 56: // STATE 118 - provider-results.pml:288 - [((delegate_state==Prepared))] (194:0:1 - 1)
		IfNotBlocked
		reached[2][118] = 1;
		if (!((now.delegate_state==11)))
			continue;
		/* merge: pc = 8(0, 119, 194) */
		reached[2][119] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 8;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 129, 194) */
		reached[2][129] = 1;
		;
		/* merge: .(goto)(0, 131, 194) */
		reached[2][131] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 57: // STATE 120 - provider-results.pml:289 - [(((delegate_state==Executing)||(delegate_state==Uncertain)))] (194:0:4 - 1)
		IfNotBlocked
		reached[2][120] = 1;
		if (!(((now.delegate_state==10)||(now.delegate_state==8))))
			continue;
		/* merge: delegate_state = Uncertain(194, 121, 194) */
		reached[2][121] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.delegate_state;
		now.delegate_state = 8;
#ifdef VAR_RANGES
		logval("delegate_state", now.delegate_state);
#endif
		;
		/* merge: unknown_seen = 1(194, 122, 194) */
		reached[2][122] = 1;
		(trpt+1)->bup.ovals[1] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: pending_terminal = Blocked(194, 123, 194) */
		reached[2][123] = 1;
		(trpt+1)->bup.ovals[2] = now.pending_terminal;
		now.pending_terminal = 1;
#ifdef VAR_RANGES
		logval("pending_terminal", now.pending_terminal);
#endif
		;
		/* merge: pc = 12(194, 124, 194) */
		reached[2][124] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 12;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 129, 194) */
		reached[2][129] = 1;
		;
		/* merge: .(goto)(0, 131, 194) */
		reached[2][131] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 58: // STATE 125 - provider-results.pml:292 - [((delegate_state==Known))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][125] = 1;
		if (!((now.delegate_state==9)))
			continue;
		/* merge: pending_terminal = Completed(194, 126, 194) */
		reached[2][126] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.pending_terminal;
		now.pending_terminal = 3;
#ifdef VAR_RANGES
		logval("pending_terminal", now.pending_terminal);
#endif
		;
		/* merge: pc = 12(194, 127, 194) */
		reached[2][127] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 12;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 129, 194) */
		reached[2][129] = 1;
		;
		/* merge: .(goto)(0, 131, 194) */
		reached[2][131] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 59: // STATE 132 - provider-results.pml:295 - [((pc==8))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][132] = 1;
		if (!((((int)now.pc)==8)))
			continue;
		/* merge: delegate_state = Executing(194, 133, 194) */
		reached[2][133] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.delegate_state;
		now.delegate_state = 10;
#ifdef VAR_RANGES
		logval("delegate_state", now.delegate_state);
#endif
		;
		/* merge: pc = 9(194, 134, 194) */
		reached[2][134] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 9;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 60: // STATE 135 - provider-results.pml:296 - [((pc==9))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][135] = 1;
		if (!((((int)now.pc)==9)))
			continue;
		/* merge: peer_calls = (peer_calls+1)(194, 136, 194) */
		reached[2][136] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.peer_calls);
		now.peer_calls = (((int)now.peer_calls)+1);
#ifdef VAR_RANGES
		logval("peer_calls", ((int)now.peer_calls));
#endif
		;
		/* merge: pc = 10(194, 137, 194) */
		reached[2][137] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 10;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 61: // STATE 138 - provider-results.pml:297 - [((pc==10))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][138] = 1;
		if (!((((int)now.pc)==10)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 62: // STATE 139 - provider-results.pml:299 - [(delegate_returns)] (194:0:1 - 1)
		IfNotBlocked
		reached[2][139] = 1;
		if (!(((int)now.delegate_returns)))
			continue;
		/* merge: pc = 11(0, 140, 194) */
		reached[2][140] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 11;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 147, 194) */
		reached[2][147] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 63: // STATE 141 - provider-results.pml:300 - [(!(delegate_returns))] (194:0:4 - 1)
		IfNotBlocked
		reached[2][141] = 1;
		if (!( !(((int)now.delegate_returns))))
			continue;
		/* merge: delegate_state = Uncertain(194, 142, 194) */
		reached[2][142] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.delegate_state;
		now.delegate_state = 8;
#ifdef VAR_RANGES
		logval("delegate_state", now.delegate_state);
#endif
		;
		/* merge: unknown_seen = 1(194, 143, 194) */
		reached[2][143] = 1;
		(trpt+1)->bup.ovals[1] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: pending_terminal = Blocked(194, 144, 194) */
		reached[2][144] = 1;
		(trpt+1)->bup.ovals[2] = now.pending_terminal;
		now.pending_terminal = 1;
#ifdef VAR_RANGES
		logval("pending_terminal", now.pending_terminal);
#endif
		;
		/* merge: pc = 12(194, 145, 194) */
		reached[2][145] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 12;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 147, 194) */
		reached[2][147] = 1;
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 64: // STATE 148 - provider-results.pml:304 - [((pc==11))] (194:0:3 - 1)
		IfNotBlocked
		reached[2][148] = 1;
		if (!((((int)now.pc)==11)))
			continue;
		/* merge: delegate_state = Known(194, 149, 194) */
		reached[2][149] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.delegate_state;
		now.delegate_state = 9;
#ifdef VAR_RANGES
		logval("delegate_state", now.delegate_state);
#endif
		;
		/* merge: pending_terminal = Completed(194, 150, 194) */
		reached[2][150] = 1;
		(trpt+1)->bup.ovals[1] = now.pending_terminal;
		now.pending_terminal = 3;
#ifdef VAR_RANGES
		logval("pending_terminal", now.pending_terminal);
#endif
		;
		/* merge: pc = 12(194, 151, 194) */
		reached[2][151] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 12;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 65: // STATE 152 - provider-results.pml:306 - [((pc==12))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][152] = 1;
		if (!((((int)now.pc)==12)))
			continue;
		/* merge: terminal = pending_terminal(194, 153, 194) */
		reached[2][153] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.terminal;
		now.terminal = now.pending_terminal;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: pc = 13(194, 154, 194) */
		reached[2][154] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 13;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 66: // STATE 155 - provider-results.pml:307 - [((pc==13))] (162:0:4 - 1)
		IfNotBlocked
		reached[2][155] = 1;
		if (!((((int)now.pc)==13)))
			continue;
		/* merge: saved_inference_calls = inference_calls(162, 156, 162) */
		reached[2][156] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.saved_inference_calls);
		now.saved_inference_calls = ((int)now.inference_calls);
#ifdef VAR_RANGES
		logval("saved_inference_calls", ((int)now.saved_inference_calls));
#endif
		;
		/* merge: saved_peer_calls = peer_calls(162, 157, 162) */
		reached[2][157] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.saved_peer_calls);
		now.saved_peer_calls = ((int)now.peer_calls);
#ifdef VAR_RANGES
		logval("saved_peer_calls", ((int)now.saved_peer_calls));
#endif
		;
		/* merge: saved_terminal = terminal(162, 158, 162) */
		reached[2][158] = 1;
		(trpt+1)->bup.ovals[2] = now.saved_terminal;
		now.saved_terminal = now.terminal;
#ifdef VAR_RANGES
		logval("saved_terminal", now.saved_terminal);
#endif
		;
		/* merge: replay_requested = 1(162, 159, 162) */
		reached[2][159] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.replay_requested);
		now.replay_requested = 1;
#ifdef VAR_RANGES
		logval("replay_requested", ((int)now.replay_requested));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 67: // STATE 160 - provider-results.pml:311 - [requested_descriptor = 1] (0:194:2 - 1)
		IfNotBlocked
		reached[2][160] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.requested_descriptor);
		now.requested_descriptor = 1;
#ifdef VAR_RANGES
		logval("requested_descriptor", ((int)now.requested_descriptor));
#endif
		;
		/* merge: .(goto)(194, 163, 194) */
		reached[2][163] = 1;
		;
		/* merge: pc = 14(194, 164, 194) */
		reached[2][164] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 14;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 68: // STATE 161 - provider-results.pml:311 - [requested_descriptor = 2] (0:194:2 - 1)
		IfNotBlocked
		reached[2][161] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.requested_descriptor);
		now.requested_descriptor = 2;
#ifdef VAR_RANGES
		logval("requested_descriptor", ((int)now.requested_descriptor));
#endif
		;
		/* merge: .(goto)(194, 163, 194) */
		reached[2][163] = 1;
		;
		/* merge: pc = 14(194, 164, 194) */
		reached[2][164] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 14;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 69: // STATE 164 - provider-results.pml:312 - [pc = 14] (0:194:1 - 3)
		IfNotBlocked
		reached[2][164] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 14;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 70: // STATE 165 - provider-results.pml:313 - [((pc==14))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][165] = 1;
		if (!((((int)now.pc)==14)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 71: // STATE 166 - provider-results.pml:315 - [((requested_descriptor!=frozen_descriptor))] (194:0:2 - 1)
		IfNotBlocked
		reached[2][166] = 1;
		if (!((((int)now.requested_descriptor)!=((int)now.frozen_descriptor))))
			continue;
		/* merge: rebind_rejected = 1(194, 167, 194) */
		reached[2][167] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.rebind_rejected);
		now.rebind_rejected = 1;
#ifdef VAR_RANGES
		logval("rebind_rejected", ((int)now.rebind_rejected));
#endif
		;
		/* merge: .(goto)(194, 177, 194) */
		reached[2][177] = 1;
		;
		/* merge: assert(((requested_descriptor==frozen_descriptor)||rebind_rejected))(194, 178, 194) */
		reached[2][178] = 1;
		spin_assert(((((int)now.requested_descriptor)==((int)now.frozen_descriptor))||((int)now.rebind_rejected)), "((requested_descriptor==frozen_descriptor)||rebind_rejected)", II, tt, t);
		/* merge: assert((terminal==saved_terminal))(194, 179, 194) */
		reached[2][179] = 1;
		spin_assert((now.terminal==now.saved_terminal), "(terminal==saved_terminal)", II, tt, t);
		/* merge: finished = 1(194, 180, 194) */
		reached[2][180] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 72: // STATE 168 - provider-results.pml:321 - [((requested_descriptor==frozen_descriptor))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][168] = 1;
		if (!((((int)now.requested_descriptor)==((int)now.frozen_descriptor))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 73: // STATE 169 - provider-results.pml:326 - [((delegate_state==Known))] (194:0:3 - 1)
		IfNotBlocked
		reached[2][169] = 1;
		if (!((now.delegate_state==9)))
			continue;
		/* merge: peer_calls = (peer_calls+1)(194, 170, 194) */
		reached[2][170] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.peer_calls);
		now.peer_calls = (((int)now.peer_calls)+1);
#ifdef VAR_RANGES
		logval("peer_calls", ((int)now.peer_calls));
#endif
		;
		/* merge: .(goto)(194, 174, 194) */
		reached[2][174] = 1;
		;
		/* merge: replayed = 1(194, 175, 194) */
		reached[2][175] = 1;
		(trpt+1)->bup.ovals[1] = ((int)replayed);
		replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)replayed));
#endif
		;
		/* merge: .(goto)(194, 177, 194) */
		reached[2][177] = 1;
		;
		/* merge: assert(((requested_descriptor==frozen_descriptor)||rebind_rejected))(194, 178, 194) */
		reached[2][178] = 1;
		spin_assert(((((int)now.requested_descriptor)==((int)now.frozen_descriptor))||((int)now.rebind_rejected)), "((requested_descriptor==frozen_descriptor)||rebind_rejected)", II, tt, t);
		/* merge: assert((terminal==saved_terminal))(194, 179, 194) */
		reached[2][179] = 1;
		spin_assert((now.terminal==now.saved_terminal), "(terminal==saved_terminal)", II, tt, t);
		/* merge: finished = 1(194, 180, 194) */
		reached[2][180] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 74: // STATE 172 - provider-results.pml:326 - [(1)] (194:0:2 - 1)
		IfNotBlocked
		reached[2][172] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(194, 174, 194) */
		reached[2][174] = 1;
		;
		/* merge: replayed = 1(194, 175, 194) */
		reached[2][175] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)replayed);
		replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)replayed));
#endif
		;
		/* merge: .(goto)(194, 177, 194) */
		reached[2][177] = 1;
		;
		/* merge: assert(((requested_descriptor==frozen_descriptor)||rebind_rejected))(194, 178, 194) */
		reached[2][178] = 1;
		spin_assert(((((int)now.requested_descriptor)==((int)now.frozen_descriptor))||((int)now.rebind_rejected)), "((requested_descriptor==frozen_descriptor)||rebind_rejected)", II, tt, t);
		/* merge: assert((terminal==saved_terminal))(194, 179, 194) */
		reached[2][179] = 1;
		spin_assert((now.terminal==now.saved_terminal), "(terminal==saved_terminal)", II, tt, t);
		/* merge: finished = 1(194, 180, 194) */
		reached[2][180] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 75: // STATE 175 - provider-results.pml:340 - [replayed = 1] (0:194:2 - 3)
		IfNotBlocked
		reached[2][175] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)replayed);
		replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)replayed));
#endif
		;
		/* merge: .(goto)(194, 177, 194) */
		reached[2][177] = 1;
		;
		/* merge: assert(((requested_descriptor==frozen_descriptor)||rebind_rejected))(194, 178, 194) */
		reached[2][178] = 1;
		spin_assert(((((int)now.requested_descriptor)==((int)now.frozen_descriptor))||((int)now.rebind_rejected)), "((requested_descriptor==frozen_descriptor)||rebind_rejected)", II, tt, t);
		/* merge: assert((terminal==saved_terminal))(194, 179, 194) */
		reached[2][179] = 1;
		spin_assert((now.terminal==now.saved_terminal), "(terminal==saved_terminal)", II, tt, t);
		/* merge: finished = 1(194, 180, 194) */
		reached[2][180] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 76: // STATE 178 - provider-results.pml:342 - [assert(((requested_descriptor==frozen_descriptor)||rebind_rejected))] (0:194:1 - 3)
		IfNotBlocked
		reached[2][178] = 1;
		spin_assert(((((int)now.requested_descriptor)==((int)now.frozen_descriptor))||((int)now.rebind_rejected)), "((requested_descriptor==frozen_descriptor)||rebind_rejected)", II, tt, t);
		/* merge: assert((terminal==saved_terminal))(194, 179, 194) */
		reached[2][179] = 1;
		spin_assert((now.terminal==now.saved_terminal), "(terminal==saved_terminal)", II, tt, t);
		/* merge: finished = 1(194, 180, 194) */
		reached[2][180] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		/* merge: .(goto)(0, 182, 194) */
		reached[2][182] = 1;
		;
		/* merge: .(goto)(0, 184, 194) */
		reached[2][184] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 77: // STATE 185 - provider-results.pml:75 - [assert((inference_calls<=1))] (0:196:0 - 1)
		IfNotBlocked
		reached[2][185] = 1;
		spin_assert((((int)now.inference_calls)<=1), "(inference_calls<=1)", II, tt, t);
		/* merge: assert((peer_calls<=(prior_peer_calls+1)))(196, 186, 196) */
		reached[2][186] = 1;
		spin_assert((((int)now.peer_calls)<=(((int)now.prior_peer_calls)+1)), "(peer_calls<=(prior_peer_calls+1))", II, tt, t);
		/* merge: assert(((frozen_descriptor==0)||(frozen_descriptor==1)))(196, 187, 196) */
		reached[2][187] = 1;
		spin_assert(((((int)now.frozen_descriptor)==0)||(((int)now.frozen_descriptor)==1)), "((frozen_descriptor==0)||(frozen_descriptor==1))", II, tt, t);
		/* merge: assert(((inference_state!=Known)||(retained_status==sealed_status)))(196, 188, 196) */
		reached[2][188] = 1;
		spin_assert(((now.inference_state!=9)||(now.retained_status==now.sealed_status)), "((inference_state!=9)||(retained_status==sealed_status))", II, tt, t);
		/* merge: assert(((peer_calls==prior_peer_calls)||(((inference_state==Known)&&(retained_status==Valid))&&(((((((((response_kind==Single)||(response_kind==Repeated))||(response_kind==Triplicated))||(response_kind==CommentaryFinal))||(response_kind==SchemaInvalid))||(response_kind==RepeatedSchemaInvalid))||(response_kind==RequestInvalid))&&schema_valid)&&request_valid))))(196, 189, 196) */
		reached[2][189] = 1;
		spin_assert(((((int)now.peer_calls)==((int)now.prior_peer_calls))||(((now.inference_state==9)&&(now.retained_status==6))&&(((((((((now.response_kind==30)||(now.response_kind==29))||(now.response_kind==28))||(now.response_kind==23))||(now.response_kind==18))||(now.response_kind==17))||(now.response_kind==16))&&((int)now.schema_valid))&&((int)now.request_valid)))), "((peer_calls==prior_peer_calls)||(((inference_state==9)&&(retained_status==6))&&(((((((((response_kind==30)||(response_kind==29))||(response_kind==28))||(response_kind==23))||(response_kind==18))||(response_kind==17))||(response_kind==16))&&schema_valid)&&request_valid)))", II, tt, t);
		/* merge: assert((((inference_state!=Known)||(retained_status!=Invalid))||(peer_calls==prior_peer_calls)))(196, 190, 196) */
		reached[2][190] = 1;
		spin_assert((((now.inference_state!=9)||(now.retained_status!=5))||(((int)now.peer_calls)==((int)now.prior_peer_calls))), "(((inference_state!=9)||(retained_status!=5))||(peer_calls==prior_peer_calls))", II, tt, t);
		/* merge: assert(((terminal!=Completed)||((((inference_state==Known)&&(retained_status==Valid))&&(delegate_state==Known))&&(((((((((response_kind==Single)||(response_kind==Repeated))||(response_kind==Triplicated))||(response_kind==CommentaryFinal))||(response_kind==SchemaInvalid))||(response_kind==RepeatedSchemaInvalid))||(response_kind==RequestInvalid))&&schema_valid)&&request_valid))))(196, 191, 196) */
		reached[2][191] = 1;
		spin_assert(((now.terminal!=3)||((((now.inference_state==9)&&(now.retained_status==6))&&(now.delegate_state==9))&&(((((((((now.response_kind==30)||(now.response_kind==29))||(now.response_kind==28))||(now.response_kind==23))||(now.response_kind==18))||(now.response_kind==17))||(now.response_kind==16))&&((int)now.schema_valid))&&((int)now.request_valid)))), "((terminal!=3)||((((inference_state==9)&&(retained_status==6))&&(delegate_state==9))&&(((((((((response_kind==30)||(response_kind==29))||(response_kind==28))||(response_kind==23))||(response_kind==18))||(response_kind==17))||(response_kind==16))&&schema_valid)&&request_valid)))", II, tt, t);
		/* merge: assert((!(replay_requested)||(inference_calls==saved_inference_calls)))(196, 192, 196) */
		reached[2][192] = 1;
		spin_assert(( !(((int)now.replay_requested))||(((int)now.inference_calls)==((int)now.saved_inference_calls))), "( !(replay_requested)||(inference_calls==saved_inference_calls))", II, tt, t);
		/* merge: assert((!(replay_requested)||(peer_calls==saved_peer_calls)))(196, 193, 196) */
		reached[2][193] = 1;
		spin_assert(( !(((int)now.replay_requested))||(((int)now.peer_calls)==((int)now.saved_peer_calls))), "( !(replay_requested)||(peer_calls==saved_peer_calls))", II, tt, t);
		/* merge: .(goto)(0, 197, 196) */
		reached[2][197] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 78: // STATE 199 - provider-results.pml:358 - [assert((((crashed_once||!((((((((((response_kind==Single)||(response_kind==Repeated))||(response_kind==Triplicated))||(response_kind==CommentaryFinal))||(response_kind==SchemaInvalid))||(response_kind==RepeatedSchemaInvalid))||(response_kind==RequestInvalid))&&schema_valid)&&request_valid)))||!(delegate_returns))||(terminal==Completed)))] (0:0:0 - 3)
		IfNotBlocked
		reached[2][199] = 1;
		spin_assert((((((int)now.crashed_once)|| !((((((((((now.response_kind==30)||(now.response_kind==29))||(now.response_kind==28))||(now.response_kind==23))||(now.response_kind==18))||(now.response_kind==17))||(now.response_kind==16))&&((int)now.schema_valid))&&((int)now.request_valid))))|| !(((int)now.delegate_returns)))||(now.terminal==3)), "(((crashed_once|| !((((((((((response_kind==30)||(response_kind==29))||(response_kind==28))||(response_kind==23))||(response_kind==18))||(response_kind==17))||(response_kind==16))&&schema_valid)&&request_valid)))|| !(delegate_returns))||(terminal==3))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 79: // STATE 200 - provider-results.pml:359 - [assert(((crashed_once||((response_kind==TransportUnknown)||(response_kind==Nonterminal)))||(inference_state==Known)))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][200] = 1;
		spin_assert(((((int)now.crashed_once)||((now.response_kind==20)||(now.response_kind==19)))||(now.inference_state==9)), "((crashed_once||((response_kind==20)||(response_kind==19)))||(inference_state==9))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 80: // STATE 201 - provider-results.pml:360 - [assert((((crashed_once||((response_kind==TransportUnknown)||(response_kind==Nonterminal)))||(((((((((response_kind==Single)||(response_kind==Repeated))||(response_kind==Triplicated))||(response_kind==CommentaryFinal))||(response_kind==SchemaInvalid))||(response_kind==RepeatedSchemaInvalid))||(response_kind==RequestInvalid))&&schema_valid)&&request_valid))||(terminal==Failed)))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][201] = 1;
		spin_assert((((((int)now.crashed_once)||((now.response_kind==20)||(now.response_kind==19)))||(((((((((now.response_kind==30)||(now.response_kind==29))||(now.response_kind==28))||(now.response_kind==23))||(now.response_kind==18))||(now.response_kind==17))||(now.response_kind==16))&&((int)now.schema_valid))&&((int)now.request_valid)))||(now.terminal==2)), "(((crashed_once||((response_kind==20)||(response_kind==19)))||(((((((((response_kind==30)||(response_kind==29))||(response_kind==28))||(response_kind==23))||(response_kind==18))||(response_kind==17))||(response_kind==16))&&schema_valid)&&request_valid))||(terminal==2))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 81: // STATE 202 - provider-results.pml:406 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[2][202] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Crash */
	case 82: // STATE 2 - provider-results.pml:153 - [(!(finished))] (8:0:2 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!( !(((int)now.finished))))
			continue;
		/* merge: crash = 1(8, 3, 8) */
		reached[1][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.crash);
		now.crash = 1;
#ifdef VAR_RANGES
		logval("crash", ((int)now.crash));
#endif
		;
		/* merge: crashed_once = 1(8, 4, 8) */
		reached[1][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.crashed_once);
		now.crashed_once = 1;
#ifdef VAR_RANGES
		logval("crashed_once", ((int)now.crashed_once));
#endif
		;
		/* merge: .(goto)(0, 7, 8) */
		reached[1][7] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 83: // STATE 8 - provider-results.pml:155 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[1][8] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Provider */
	case 84: // STATE 1 - provider-results.pml:100 - [((inference_calls==1))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		if (!((((int)now.inference_calls)==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 85: // STATE 2 - provider-results.pml:102 - [message_count = 1] (0:56:13 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		(trpt+1)->bup.ovals = grab_ints(13);
		(trpt+1)->bup.ovals[0] = ((int)now.message_count);
		now.message_count = 1;
#ifdef VAR_RANGES
		logval("message_count", ((int)now.message_count));
#endif
		;
		/* merge: phase[0] = 2(56, 3, 56) */
		reached[0][3] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.phase[0]);
		now.phase[0] = 2;
#ifdef VAR_RANGES
		logval("phase[0]", ((int)now.phase[0]));
#endif
		;
		/* merge: text_blocks[0] = 1(56, 4, 56) */
		reached[0][4] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.text_blocks[0]);
		now.text_blocks[0] = 1;
#ifdef VAR_RANGES
		logval("text_blocks[0]", ((int)now.text_blocks[0]));
#endif
		;
		/* merge: value[0] = 1(56, 5, 56) */
		reached[0][5] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.value[0]);
		now.value[0] = 1;
#ifdef VAR_RANGES
		logval("value[0]", ((int)now.value[0]));
#endif
		;
		/* merge: string_text[0] = 1(56, 6, 56) */
		reached[0][6] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.string_text[0]);
		now.string_text[0] = 1;
#ifdef VAR_RANGES
		logval("string_text[0]", ((int)now.string_text[0]));
#endif
		;
		/* merge: phase[1] = 1(56, 7, 56) */
		reached[0][7] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.phase[1]);
		now.phase[1] = 1;
#ifdef VAR_RANGES
		logval("phase[1]", ((int)now.phase[1]));
#endif
		;
		/* merge: text_blocks[1] = 1(56, 8, 56) */
		reached[0][8] = 1;
		(trpt+1)->bup.ovals[6] = ((int)now.text_blocks[1]);
		now.text_blocks[1] = 1;
#ifdef VAR_RANGES
		logval("text_blocks[1]", ((int)now.text_blocks[1]));
#endif
		;
		/* merge: value[1] = 1(56, 9, 56) */
		reached[0][9] = 1;
		(trpt+1)->bup.ovals[7] = ((int)now.value[1]);
		now.value[1] = 1;
#ifdef VAR_RANGES
		logval("value[1]", ((int)now.value[1]));
#endif
		;
		/* merge: string_text[1] = 1(56, 10, 56) */
		reached[0][10] = 1;
		(trpt+1)->bup.ovals[8] = ((int)now.string_text[1]);
		now.string_text[1] = 1;
#ifdef VAR_RANGES
		logval("string_text[1]", ((int)now.string_text[1]));
#endif
		;
		/* merge: phase[2] = 0(56, 11, 56) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[9] = ((int)now.phase[2]);
		now.phase[2] = 0;
#ifdef VAR_RANGES
		logval("phase[2]", ((int)now.phase[2]));
#endif
		;
		/* merge: text_blocks[2] = 1(56, 12, 56) */
		reached[0][12] = 1;
		(trpt+1)->bup.ovals[10] = ((int)now.text_blocks[2]);
		now.text_blocks[2] = 1;
#ifdef VAR_RANGES
		logval("text_blocks[2]", ((int)now.text_blocks[2]));
#endif
		;
		/* merge: value[2] = 1(56, 13, 56) */
		reached[0][13] = 1;
		(trpt+1)->bup.ovals[11] = ((int)now.value[2]);
		now.value[2] = 1;
#ifdef VAR_RANGES
		logval("value[2]", ((int)now.value[2]));
#endif
		;
		/* merge: string_text[2] = 1(56, 14, 56) */
		reached[0][14] = 1;
		(trpt+1)->bup.ovals[12] = ((int)now.string_text[2]);
		now.string_text[2] = 1;
#ifdef VAR_RANGES
		logval("string_text[2]", ((int)now.string_text[2]));
#endif
		;
		_m = 3; goto P999; /* 12 */
	case 86: // STATE 15 - provider-results.pml:110 - [response_kind = Single] (0:0:1 - 1)
		IfNotBlocked
		reached[0][15] = 1;
		(trpt+1)->bup.oval = now.response_kind;
		now.response_kind = 30;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 87: // STATE 16 - provider-results.pml:111 - [response_kind = Repeated] (0:73:2 - 1)
		IfNotBlocked
		reached[0][16] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 29;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: message_count = 2(73, 17, 73) */
		reached[0][17] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.message_count);
		now.message_count = 2;
#ifdef VAR_RANGES
		logval("message_count", ((int)now.message_count));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 88: // STATE 18 - provider-results.pml:112 - [response_kind = Triplicated] (0:73:2 - 1)
		IfNotBlocked
		reached[0][18] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 28;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: message_count = 3(73, 19, 73) */
		reached[0][19] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.message_count);
		now.message_count = 3;
#ifdef VAR_RANGES
		logval("message_count", ((int)now.message_count));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 89: // STATE 20 - provider-results.pml:113 - [response_kind = Conflicting] (0:73:3 - 1)
		IfNotBlocked
		reached[0][20] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 27;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: message_count = 2(73, 21, 73) */
		reached[0][21] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.message_count);
		now.message_count = 2;
#ifdef VAR_RANGES
		logval("message_count", ((int)now.message_count));
#endif
		;
		/* merge: value[1] = 2(73, 22, 73) */
		reached[0][22] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.value[1]);
		now.value[1] = 2;
#ifdef VAR_RANGES
		logval("value[1]", ((int)now.value[1]));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 90: // STATE 23 - provider-results.pml:114 - [response_kind = OpaqueStringConflict] (0:73:3 - 1)
		IfNotBlocked
		reached[0][23] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 26;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: message_count = 2(73, 24, 73) */
		reached[0][24] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.message_count);
		now.message_count = 2;
#ifdef VAR_RANGES
		logval("message_count", ((int)now.message_count));
#endif
		;
		/* merge: value[1] = 2(73, 25, 73) */
		reached[0][25] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.value[1]);
		now.value[1] = 2;
#ifdef VAR_RANGES
		logval("value[1]", ((int)now.value[1]));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 91: // STATE 26 - provider-results.pml:115 - [response_kind = MalformedSibling] (0:73:3 - 1)
		IfNotBlocked
		reached[0][26] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 25;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: message_count = 2(73, 27, 73) */
		reached[0][27] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.message_count);
		now.message_count = 2;
#ifdef VAR_RANGES
		logval("message_count", ((int)now.message_count));
#endif
		;
		/* merge: value[1] = 3(73, 28, 73) */
		reached[0][28] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.value[1]);
		now.value[1] = 3;
#ifdef VAR_RANGES
		logval("value[1]", ((int)now.value[1]));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 92: // STATE 29 - provider-results.pml:116 - [response_kind = CommentaryOnly] (0:73:2 - 1)
		IfNotBlocked
		reached[0][29] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 24;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: phase[0] = 3(73, 30, 73) */
		reached[0][30] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.phase[0]);
		now.phase[0] = 3;
#ifdef VAR_RANGES
		logval("phase[0]", ((int)now.phase[0]));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 93: // STATE 31 - provider-results.pml:117 - [response_kind = CommentaryFinal] (0:73:5 - 1)
		IfNotBlocked
		reached[0][31] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 23;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: message_count = 2(73, 32, 73) */
		reached[0][32] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.message_count);
		now.message_count = 2;
#ifdef VAR_RANGES
		logval("message_count", ((int)now.message_count));
#endif
		;
		/* merge: phase[0] = 3(73, 33, 73) */
		reached[0][33] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.phase[0]);
		now.phase[0] = 3;
#ifdef VAR_RANGES
		logval("phase[0]", ((int)now.phase[0]));
#endif
		;
		/* merge: value[0] = 3(73, 34, 73) */
		reached[0][34] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.value[0]);
		now.value[0] = 3;
#ifdef VAR_RANGES
		logval("value[0]", ((int)now.value[0]));
#endif
		;
		/* merge: phase[1] = 2(73, 35, 73) */
		reached[0][35] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.phase[1]);
		now.phase[1] = 2;
#ifdef VAR_RANGES
		logval("phase[1]", ((int)now.phase[1]));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 94: // STATE 36 - provider-results.pml:119 - [response_kind = Refused] (0:73:4 - 1)
		IfNotBlocked
		reached[0][36] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 22;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: message_count = 2(73, 37, 73) */
		reached[0][37] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.message_count);
		now.message_count = 2;
#ifdef VAR_RANGES
		logval("message_count", ((int)now.message_count));
#endif
		;
		/* merge: phase[1] = 3(73, 38, 73) */
		reached[0][38] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.phase[1]);
		now.phase[1] = 3;
#ifdef VAR_RANGES
		logval("phase[1]", ((int)now.phase[1]));
#endif
		;
		/* merge: refusal = 1(73, 39, 73) */
		reached[0][39] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.refusal);
		now.refusal = 1;
#ifdef VAR_RANGES
		logval("refusal", ((int)now.refusal));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 95: // STATE 40 - provider-results.pml:121 - [response_kind = Incomplete] (0:0:1 - 1)
		IfNotBlocked
		reached[0][40] = 1;
		(trpt+1)->bup.oval = now.response_kind;
		now.response_kind = 21;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 96: // STATE 41 - provider-results.pml:122 - [response_kind = TransportUnknown] (0:0:1 - 1)
		IfNotBlocked
		reached[0][41] = 1;
		(trpt+1)->bup.oval = now.response_kind;
		now.response_kind = 20;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 97: // STATE 42 - provider-results.pml:123 - [response_kind = Nonterminal] (0:0:1 - 1)
		IfNotBlocked
		reached[0][42] = 1;
		(trpt+1)->bup.oval = now.response_kind;
		now.response_kind = 19;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 98: // STATE 43 - provider-results.pml:124 - [response_kind = SchemaInvalid] (0:73:2 - 1)
		IfNotBlocked
		reached[0][43] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 18;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: schema_valid = 0(73, 44, 73) */
		reached[0][44] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.schema_valid);
		now.schema_valid = 0;
#ifdef VAR_RANGES
		logval("schema_valid", ((int)now.schema_valid));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 99: // STATE 45 - provider-results.pml:125 - [response_kind = RepeatedSchemaInvalid] (0:73:3 - 1)
		IfNotBlocked
		reached[0][45] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 17;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: message_count = 2(73, 46, 73) */
		reached[0][46] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.message_count);
		now.message_count = 2;
#ifdef VAR_RANGES
		logval("message_count", ((int)now.message_count));
#endif
		;
		/* merge: schema_valid = 0(73, 47, 73) */
		reached[0][47] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.schema_valid);
		now.schema_valid = 0;
#ifdef VAR_RANGES
		logval("schema_valid", ((int)now.schema_valid));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 100: // STATE 48 - provider-results.pml:126 - [response_kind = RequestInvalid] (0:73:2 - 1)
		IfNotBlocked
		reached[0][48] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 16;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: request_valid = 0(73, 49, 73) */
		reached[0][49] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.request_valid);
		now.request_valid = 0;
#ifdef VAR_RANGES
		logval("request_valid", ((int)now.request_valid));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 101: // STATE 50 - provider-results.pml:127 - [response_kind = SplitText] (0:73:2 - 1)
		IfNotBlocked
		reached[0][50] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 15;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: text_blocks[0] = 2(73, 51, 73) */
		reached[0][51] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.text_blocks[0]);
		now.text_blocks[0] = 2;
#ifdef VAR_RANGES
		logval("text_blocks[0]", ((int)now.text_blocks[0]));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 102: // STATE 52 - provider-results.pml:128 - [response_kind = EmptyMessage] (0:73:2 - 1)
		IfNotBlocked
		reached[0][52] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 14;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: text_blocks[0] = 0(73, 53, 73) */
		reached[0][53] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.text_blocks[0]);
		now.text_blocks[0] = 0;
#ifdef VAR_RANGES
		logval("text_blocks[0]", ((int)now.text_blocks[0]));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 103: // STATE 54 - provider-results.pml:129 - [response_kind = NonstringText] (0:73:2 - 1)
		IfNotBlocked
		reached[0][54] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.response_kind;
		now.response_kind = 13;
#ifdef VAR_RANGES
		logval("response_kind", now.response_kind);
#endif
		;
		/* merge: string_text[0] = 0(73, 55, 73) */
		reached[0][55] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.string_text[0]);
		now.string_text[0] = 0;
#ifdef VAR_RANGES
		logval("string_text[0]", ((int)now.string_text[0]));
#endif
		;
		/* merge: .(goto)(0, 57, 73) */
		reached[0][57] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 104: // STATE 58 - provider-results.pml:134 - [(1)] (81:0:1 - 1)
		IfNotBlocked
		reached[0][58] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(81, 74, 81) */
		reached[0][74] = 1;
		;
		/* merge: response_ready = 1(81, 75, 81) */
		reached[0][75] = 1;
		(trpt+1)->bup.oval = ((int)now.response_ready);
		now.response_ready = 1;
#ifdef VAR_RANGES
		logval("response_ready", ((int)now.response_ready));
#endif
		;
		/* merge: .(goto)(0, 80, 81) */
		reached[0][80] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 105: // STATE 74 - provider-results.pml:144 - [.(goto)] (0:81:1 - 2)
		IfNotBlocked
		reached[0][74] = 1;
		;
		/* merge: response_ready = 1(81, 75, 81) */
		reached[0][75] = 1;
		(trpt+1)->bup.oval = ((int)now.response_ready);
		now.response_ready = 1;
#ifdef VAR_RANGES
		logval("response_ready", ((int)now.response_ready));
#endif
		;
		/* merge: .(goto)(0, 80, 81) */
		reached[0][80] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 106: // STATE 59 - provider-results.pml:135 - [((message_count>1))] (81:0:14 - 1)
		IfNotBlocked
		reached[0][59] = 1;
		if (!((((int)now.message_count)>1)))
			continue;
		/* merge: last = (message_count-1)(81, 60, 81) */
		reached[0][60] = 1;
		(trpt+1)->bup.ovals = grab_ints(14);
		(trpt+1)->bup.ovals[0] = ((int)((P0 *)_this)->last);
		((P0 *)_this)->last = (((int)now.message_count)-1);
#ifdef VAR_RANGES
		logval("Provider:last", ((int)((P0 *)_this)->last));
#endif
		;
		/* merge: saved_phase = phase[0](81, 61, 81) */
		reached[0][61] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->saved_phase);
		((P0 *)_this)->saved_phase = ((int)now.phase[0]);
#ifdef VAR_RANGES
		logval("Provider:saved_phase", ((int)((P0 *)_this)->saved_phase));
#endif
		;
		/* merge: saved_blocks = text_blocks[0](81, 62, 81) */
		reached[0][62] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P0 *)_this)->saved_blocks);
		((P0 *)_this)->saved_blocks = ((int)now.text_blocks[0]);
#ifdef VAR_RANGES
		logval("Provider:saved_blocks", ((int)((P0 *)_this)->saved_blocks));
#endif
		;
		/* merge: saved_value = value[0](81, 63, 81) */
		reached[0][63] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P0 *)_this)->saved_value);
		((P0 *)_this)->saved_value = ((int)now.value[0]);
#ifdef VAR_RANGES
		logval("Provider:saved_value", ((int)((P0 *)_this)->saved_value));
#endif
		;
		/* merge: saved_string = string_text[0](81, 64, 81) */
		reached[0][64] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P0 *)_this)->saved_string);
		((P0 *)_this)->saved_string = ((int)now.string_text[0]);
#ifdef VAR_RANGES
		logval("Provider:saved_string", ((int)((P0 *)_this)->saved_string));
#endif
		;
		/* merge: phase[0] = phase[last](81, 65, 81) */
		reached[0][65] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.phase[0]);
		now.phase[0] = ((int)now.phase[ Index(((int)((P0 *)_this)->last), 3) ]);
#ifdef VAR_RANGES
		logval("phase[0]", ((int)now.phase[0]));
#endif
		;
		/* merge: text_blocks[0] = text_blocks[last](81, 66, 81) */
		reached[0][66] = 1;
		(trpt+1)->bup.ovals[6] = ((int)now.text_blocks[0]);
		now.text_blocks[0] = ((int)now.text_blocks[ Index(((int)((P0 *)_this)->last), 3) ]);
#ifdef VAR_RANGES
		logval("text_blocks[0]", ((int)now.text_blocks[0]));
#endif
		;
		/* merge: value[0] = value[last](81, 67, 81) */
		reached[0][67] = 1;
		(trpt+1)->bup.ovals[7] = ((int)now.value[0]);
		now.value[0] = ((int)now.value[ Index(((int)((P0 *)_this)->last), 3) ]);
#ifdef VAR_RANGES
		logval("value[0]", ((int)now.value[0]));
#endif
		;
		/* merge: string_text[0] = string_text[last](81, 68, 81) */
		reached[0][68] = 1;
		(trpt+1)->bup.ovals[8] = ((int)now.string_text[0]);
		now.string_text[0] = ((int)now.string_text[ Index(((int)((P0 *)_this)->last), 3) ]);
#ifdef VAR_RANGES
		logval("string_text[0]", ((int)now.string_text[0]));
#endif
		;
		/* merge: phase[last] = saved_phase(81, 69, 81) */
		reached[0][69] = 1;
		(trpt+1)->bup.ovals[9] = ((int)now.phase[ Index(((int)((P0 *)_this)->last), 3) ]);
		now.phase[ Index(((P0 *)_this)->last, 3) ] = ((int)((P0 *)_this)->saved_phase);
#ifdef VAR_RANGES
		logval("phase[Provider:last]", ((int)now.phase[ Index(((int)((P0 *)_this)->last), 3) ]));
#endif
		;
		/* merge: text_blocks[last] = saved_blocks(81, 70, 81) */
		reached[0][70] = 1;
		(trpt+1)->bup.ovals[10] = ((int)now.text_blocks[ Index(((int)((P0 *)_this)->last), 3) ]);
		now.text_blocks[ Index(((P0 *)_this)->last, 3) ] = ((int)((P0 *)_this)->saved_blocks);
#ifdef VAR_RANGES
		logval("text_blocks[Provider:last]", ((int)now.text_blocks[ Index(((int)((P0 *)_this)->last), 3) ]));
#endif
		;
		/* merge: value[last] = saved_value(81, 71, 81) */
		reached[0][71] = 1;
		(trpt+1)->bup.ovals[11] = ((int)now.value[ Index(((int)((P0 *)_this)->last), 3) ]);
		now.value[ Index(((P0 *)_this)->last, 3) ] = ((int)((P0 *)_this)->saved_value);
#ifdef VAR_RANGES
		logval("value[Provider:last]", ((int)now.value[ Index(((int)((P0 *)_this)->last), 3) ]));
#endif
		;
		/* merge: string_text[last] = saved_string(81, 72, 81) */
		reached[0][72] = 1;
		(trpt+1)->bup.ovals[12] = ((int)now.string_text[ Index(((int)((P0 *)_this)->last), 3) ]);
		now.string_text[ Index(((P0 *)_this)->last, 3) ] = ((int)((P0 *)_this)->saved_string);
#ifdef VAR_RANGES
		logval("string_text[Provider:last]", ((int)now.string_text[ Index(((int)((P0 *)_this)->last), 3) ]));
#endif
		;
		/* merge: .(goto)(81, 74, 81) */
		reached[0][74] = 1;
		;
		/* merge: response_ready = 1(81, 75, 81) */
		reached[0][75] = 1;
		(trpt+1)->bup.ovals[13] = ((int)now.response_ready);
		now.response_ready = 1;
#ifdef VAR_RANGES
		logval("response_ready", ((int)now.response_ready));
#endif
		;
		/* merge: .(goto)(0, 80, 81) */
		reached[0][80] = 1;
		;
		_m = 3; goto P999; /* 16 */
	case 107: // STATE 77 - provider-results.pml:146 - [((terminal!=Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][77] = 1;
		if (!((now.terminal!=4)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 108: // STATE 81 - provider-results.pml:148 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[0][81] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

