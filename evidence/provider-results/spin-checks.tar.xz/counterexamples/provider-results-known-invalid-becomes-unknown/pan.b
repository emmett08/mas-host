	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM provider_results_settle */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 5: // STATE 5
		;
		now.peer_calls = trpt->bup.ovals[1];
		now.prior_peer_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 6: // STATE 5
		;
		now.peer_calls = trpt->bup.ovals[1];
		now.prior_peer_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 7: // STATE 5
		;
		now.peer_calls = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 6
		;
		now.delegate_returns = trpt->bup.oval;
		;
		goto R999;

	case 9: // STATE 7
		;
		now.delegate_returns = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 10
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 11: // STATE 11
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 12: // STATE 12
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 13: // STATE 14
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Host */
;
		;
		;
		;
		
	case 16: // STATE 5
		;
		now.crash = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 12
		;
		now.pc = trpt->bup.ovals[1];
		transient_known_lost = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 18: // STATE 12
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 12
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 22: // STATE 16
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 24: // STATE 21
		;
		now.pc = trpt->bup.ovals[2];
		now.inference_state = trpt->bup.ovals[1];
		now.frozen_descriptor = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 25: // STATE 23
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 26: // STATE 28
		;
		now.pc = trpt->bup.ovals[3];
		now.pending_terminal = trpt->bup.ovals[2];
		unknown_seen = trpt->bup.ovals[1];
		now.inference_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 27: // STATE 31
		;
		now.pc = trpt->bup.ovals[1];
		cached_inference = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 28: // STATE 38
		;
		now.pc = trpt->bup.ovals[1];
		now.inference_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 29: // STATE 41
		;
		now.pc = trpt->bup.ovals[1];
		now.inference_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 30: // STATE 43
		;
		now.inference_observed = trpt->bup.oval;
		;
		goto R999;

	case 31: // STATE 48
		;
		now.pc = trpt->bup.ovals[3];
		now.pending_terminal = trpt->bup.ovals[2];
		unknown_seen = trpt->bup.ovals[1];
		now.inference_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 32: // STATE 50
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 34: // STATE 59
		;
		now.i = trpt->bup.ovals[5];
		now.bad_shape = trpt->bup.ovals[4];
		now.malformed = trpt->bup.ovals[3];
		now.conflicting = trpt->bup.ovals[2];
		now.first_value = trpt->bup.ovals[1];
		now.eligible = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;
;
		;
		
	case 36: // STATE 62
		;
		now.eligible = trpt->bup.oval;
		;
		goto R999;

	case 37: // STATE 85
		;
		now.i = trpt->bup.ovals[1];
		now.bad_shape = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 38: // STATE 85
		;
		now.i = trpt->bup.ovals[1];
		now.malformed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 40: // STATE 85
		;
		now.i = trpt->bup.ovals[1];
		now.first_value = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 41: // STATE 85
		;
		now.i = trpt->bup.ovals[1];
		now.conflicting = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 42: // STATE 85
		;
		now.i = trpt->bup.oval;
		;
		goto R999;

	case 43: // STATE 85
		;
		now.i = trpt->bup.oval;
		;
		goto R999;

	case 44: // STATE 85
		;
		now.i = trpt->bup.oval;
		;
		goto R999;

	case 45: // STATE 94
		;
		now.pc = trpt->bup.ovals[1];
		now.selected = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 47: // STATE 102
		;
		now.pc = trpt->bup.ovals[1];
		now.local_status = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 48: // STATE 102
		;
		now.pc = trpt->bup.ovals[1];
		now.local_status = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 49: // STATE 102
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 51: // STATE 107
		;
		now.pc = trpt->bup.ovals[2];
		now.pending_terminal = trpt->bup.ovals[1];
		now.inference_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 52: // STATE 112
		;
		now.pc = trpt->bup.ovals[3];
		now.inference_state = trpt->bup.ovals[2];
		now.sealed_status = trpt->bup.ovals[1];
		now.retained_status = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 53: // STATE 117
		;
		now.admitted = trpt->bup.oval;
		;
		goto R999;

	case 54: // STATE 120
		;
		now.pc = trpt->bup.ovals[1];
		now.pending_terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 56: // STATE 124
		;
		now.pc = trpt->bup.ovals[1];
		now.delegate_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 57: // STATE 126
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 58: // STATE 131
		;
		now.pc = trpt->bup.ovals[3];
		now.pending_terminal = trpt->bup.ovals[2];
		unknown_seen = trpt->bup.ovals[1];
		now.delegate_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 59: // STATE 134
		;
		now.pc = trpt->bup.ovals[1];
		now.pending_terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 60: // STATE 141
		;
		now.pc = trpt->bup.ovals[1];
		now.delegate_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 61: // STATE 144
		;
		now.pc = trpt->bup.ovals[1];
		now.peer_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 63: // STATE 147
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 64: // STATE 152
		;
		now.pc = trpt->bup.ovals[3];
		now.pending_terminal = trpt->bup.ovals[2];
		unknown_seen = trpt->bup.ovals[1];
		now.delegate_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 65: // STATE 158
		;
		now.pc = trpt->bup.ovals[2];
		now.pending_terminal = trpt->bup.ovals[1];
		now.delegate_state = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 66: // STATE 161
		;
		now.pc = trpt->bup.ovals[1];
		now.terminal = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 67: // STATE 166
		;
		now.replay_requested = trpt->bup.ovals[3];
		now.saved_terminal = trpt->bup.ovals[2];
		now.saved_peer_calls = trpt->bup.ovals[1];
		now.saved_inference_calls = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 68: // STATE 171
		;
		now.pc = trpt->bup.ovals[1];
		now.requested_descriptor = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 69: // STATE 171
		;
		now.pc = trpt->bup.ovals[1];
		now.requested_descriptor = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 70: // STATE 171
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 72: // STATE 181
		;
		now.finished = trpt->bup.ovals[1];
		now.rebind_rejected = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 73: // STATE 181
		;
		now.finished = trpt->bup.ovals[1];
		replayed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 74: // STATE 181
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;
;
		
	case 75: // STATE 186
		goto R999;
;
		;
		;
		;
		;
		;
		
	case 79: // STATE 203
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Crash */

	case 80: // STATE 4
		;
		now.crashed_once = trpt->bup.ovals[1];
		now.crash = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 81: // STATE 8
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Provider */
;
		;
		
	case 83: // STATE 14
		;
		now.string_text[2] = trpt->bup.ovals[12];
		now.value[2] = trpt->bup.ovals[11];
		now.text_blocks[2] = trpt->bup.ovals[10];
		now.phase[2] = trpt->bup.ovals[9];
		now.string_text[1] = trpt->bup.ovals[8];
		now.value[1] = trpt->bup.ovals[7];
		now.text_blocks[1] = trpt->bup.ovals[6];
		now.phase[1] = trpt->bup.ovals[5];
		now.string_text[0] = trpt->bup.ovals[4];
		now.value[0] = trpt->bup.ovals[3];
		now.text_blocks[0] = trpt->bup.ovals[2];
		now.phase[0] = trpt->bup.ovals[1];
		now.message_count = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 13);
		goto R999;

	case 84: // STATE 15
		;
		now.response_kind = trpt->bup.oval;
		;
		goto R999;

	case 85: // STATE 17
		;
		now.message_count = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 86: // STATE 19
		;
		now.message_count = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 87: // STATE 22
		;
		now.value[1] = trpt->bup.ovals[2];
		now.message_count = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 88: // STATE 25
		;
		now.value[1] = trpt->bup.ovals[2];
		now.message_count = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 89: // STATE 28
		;
		now.value[1] = trpt->bup.ovals[2];
		now.message_count = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 90: // STATE 30
		;
		now.phase[0] = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 91: // STATE 35
		;
		now.phase[1] = trpt->bup.ovals[4];
		now.value[0] = trpt->bup.ovals[3];
		now.phase[0] = trpt->bup.ovals[2];
		now.message_count = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 5);
		goto R999;

	case 92: // STATE 39
		;
		now.refusal = trpt->bup.ovals[3];
		now.phase[1] = trpt->bup.ovals[2];
		now.message_count = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 93: // STATE 40
		;
		now.response_kind = trpt->bup.oval;
		;
		goto R999;

	case 94: // STATE 41
		;
		now.response_kind = trpt->bup.oval;
		;
		goto R999;

	case 95: // STATE 42
		;
		now.response_kind = trpt->bup.oval;
		;
		goto R999;

	case 96: // STATE 44
		;
		now.schema_valid = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 97: // STATE 47
		;
		now.schema_valid = trpt->bup.ovals[2];
		now.message_count = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 98: // STATE 49
		;
		now.request_valid = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 99: // STATE 51
		;
		now.text_blocks[0] = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 100: // STATE 53
		;
		now.text_blocks[0] = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 101: // STATE 55
		;
		now.string_text[0] = trpt->bup.ovals[1];
		now.response_kind = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 102: // STATE 75
		;
		now.response_ready = trpt->bup.oval;
		;
		goto R999;

	case 103: // STATE 75
		;
		now.response_ready = trpt->bup.oval;
		;
		goto R999;

	case 104: // STATE 75
		;
		now.response_ready = trpt->bup.ovals[13];
		now.string_text[ Index(((P0 *)_this)->last, 3) ] = trpt->bup.ovals[12];
		now.value[ Index(((P0 *)_this)->last, 3) ] = trpt->bup.ovals[11];
		now.text_blocks[ Index(((P0 *)_this)->last, 3) ] = trpt->bup.ovals[10];
		now.phase[ Index(((P0 *)_this)->last, 3) ] = trpt->bup.ovals[9];
		now.string_text[0] = trpt->bup.ovals[8];
		now.value[0] = trpt->bup.ovals[7];
		now.text_blocks[0] = trpt->bup.ovals[6];
		now.phase[0] = trpt->bup.ovals[5];
		((P0 *)_this)->saved_string = trpt->bup.ovals[4];
		((P0 *)_this)->saved_value = trpt->bup.ovals[3];
		((P0 *)_this)->saved_blocks = trpt->bup.ovals[2];
		((P0 *)_this)->saved_phase = trpt->bup.ovals[1];
		((P0 *)_this)->last = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 14);
		goto R999;
;
		;
		
	case 106: // STATE 81
		;
		p_restor(II);
		;
		;
		goto R999;
	}

