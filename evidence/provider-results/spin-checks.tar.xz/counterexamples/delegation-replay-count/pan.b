	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM delegation_finishes */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 5: // STATE 1
		;
		now.minimum = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 2
		;
		now.minimum = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 3
		;
		now.minimum = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 6
		;
		now.required = trpt->bup.oval;
		;
		goto R999;

	case 9: // STATE 7
		;
		now.required = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 8
		;
		now.required = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 9
		;
		now.required = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 14: // STATE 14
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 16: // STATE 16
		;
		now.complete_allowed = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 17
		;
		now.request_allowed = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 19: // STATE 19
		;
		now.permitted_requests = trpt->bup.oval;
		;
		goto R999;

	case 20: // STATE 21
		;
		now.permitted_requests = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		
	case 24: // STATE 27
		;
		now.turns = trpt->bup.oval;
		;
		goto R999;

	case 25: // STATE 28
		;
		now.provider_dispatches = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 27: // STATE 30
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 29: // STATE 33
		;
		early_completion_rejected = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 31: // STATE 39
		;
		partial_completion_rejected = trpt->bup.oval;
		;
		goto R999;

	case 32: // STATE 44
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 33: // STATE 47
		;
		now.selected = trpt->bup.oval;
		;
		goto R999;

	case 34: // STATE 48
		;
		now.selected = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 36: // STATE 52
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		
	case 40: // STATE 56
		;
		duplicate_rejected = trpt->bup.oval;
		;
		goto R999;

	case 41: // STATE 61
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 44: // STATE 64
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 46: // STATE 66
		;
		now.peer_dispatches = trpt->bup.oval;
		;
		goto R999;

	case 47: // STATE 67
		;
		now.successful = trpt->bup.oval;
		;
		goto R999;

	case 48: // STATE 68
		;
		now.retained_successful = trpt->bup.oval;
		;
		goto R999;

	case 49: // STATE 69
		;
		now.covered = trpt->bup.oval;
		;
		goto R999;

	case 50: // STATE 70
		;
		now.retained_covered = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 52: // STATE 72
		;
		now.first_peer = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 54: // STATE 78
		;
		now.saved_provider_dispatches = trpt->bup.oval;
		;
		goto R999;

	case 55: // STATE 79
		;
		now.saved_peer_dispatches = trpt->bup.oval;
		;
		goto R999;

	case 56: // STATE 80
		;
		now.successful = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 58: // STATE 82
		;
		now.successful = trpt->bup.oval;
		;
		goto R999;

	case 59: // STATE 88
		;
		now.covered = trpt->bup.oval;
		;
		goto R999;

	case 60: // STATE 89
		;
		now.successful = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		
	case 65: // STATE 94
		;
		now.replayed = trpt->bup.oval;
		;
		goto R999;

	case 66: // STATE 99
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 67: // STATE 108
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 68: // STATE 109
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 69: // STATE 110
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 70: // STATE 111
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		
	case 79: // STATE 128
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;

	case 80: // STATE 129
		;
		p_restor(II);
		;
		;
		goto R999;
	}

