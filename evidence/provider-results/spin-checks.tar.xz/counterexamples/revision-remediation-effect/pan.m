#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!((terminal!=Running)))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[3][1] = 1;
		if (!( !((now.terminal!=6))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[3][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - revision.pml:225 - [frozen_limit = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[2][1] = 1;
		(trpt+1)->bup.oval = ((int)now.frozen_limit);
		now.frozen_limit = 1;
#ifdef VAR_RANGES
		logval("frozen_limit", ((int)now.frozen_limit));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - revision.pml:225 - [frozen_limit = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[2][2] = 1;
		(trpt+1)->bup.oval = ((int)now.frozen_limit);
		now.frozen_limit = 2;
#ifdef VAR_RANGES
		logval("frozen_limit", ((int)now.frozen_limit));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 3 - revision.pml:226 - [frozen_limit = 3] (0:0:1 - 1)
		IfNotBlocked
		reached[2][3] = 1;
		(trpt+1)->bup.oval = ((int)now.frozen_limit);
		now.frozen_limit = 3;
#ifdef VAR_RANGES
		logval("frozen_limit", ((int)now.frozen_limit));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 4 - revision.pml:226 - [frozen_limit = 4] (0:0:1 - 1)
		IfNotBlocked
		reached[2][4] = 1;
		(trpt+1)->bup.oval = ((int)now.frozen_limit);
		now.frozen_limit = 4;
#ifdef VAR_RANGES
		logval("frozen_limit", ((int)now.frozen_limit));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 7 - revision.pml:227 - [(run Disruption())] (0:0:0 - 5)
		IfNotBlocked
		reached[2][7] = 1;
		if (!(addproc(II, 1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 10: // STATE 8 - revision.pml:227 - [(run Controller())] (0:0:0 - 1)
		IfNotBlocked
		reached[2][8] = 1;
		if (!(addproc(II, 1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 10 - revision.pml:229 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[2][10] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Controller */
	case 12: // STATE 1 - revision.pml:69 - [((terminal!=Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][1] = 1;
		if (!((now.terminal!=6)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 3 - revision.pml:70 - [((terminal==Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][3] = 1;
		if (!((now.terminal==6)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 4 - revision.pml:73 - [(cancelled)] (123:0:1 - 1)
		IfNotBlocked
		reached[1][4] = 1;
		if (!(((int)now.cancelled)))
			continue;
		/* merge: terminal = Cancelled(0, 5, 123) */
		reached[1][5] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 3;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 15: // STATE 6 - revision.pml:74 - [((!(cancelled)&&expired))] (123:0:1 - 1)
		IfNotBlocked
		reached[1][6] = 1;
		if (!(( !(((int)now.cancelled))&&((int)now.expired))))
			continue;
		/* merge: terminal = Expired(0, 7, 123) */
		reached[1][7] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 16: // STATE 8 - revision.pml:75 - [(((!(cancelled)&&!(expired))&&crashed))] (16:0:2 - 1)
		IfNotBlocked
		reached[1][8] = 1;
		if (!((( !(((int)now.cancelled))&& !(((int)now.expired)))&&((int)now.crashed))))
			continue;
		/* merge: restarted = 1(16, 9, 16) */
		reached[1][9] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)restarted);
		restarted = 1;
#ifdef VAR_RANGES
		logval("restarted", ((int)restarted));
#endif
		;
		/* merge: crashed = 0(16, 10, 16) */
		reached[1][10] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.crashed);
		now.crashed = 0;
#ifdef VAR_RANGES
		logval("crashed", ((int)now.crashed));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 17: // STATE 11 - revision.pml:79 - [((inflight[stage]&&!(effect_complete[stage])))] (123:0:2 - 1)
		IfNotBlocked
		reached[1][11] = 1;
		if (!((((int)now.inflight[ Index(((int)now.stage), 4) ])&& !(((int)now.effect_complete[ Index(((int)now.stage), 4) ])))))
			continue;
		/* merge: unknown_seen = 1(123, 12, 123) */
		reached[1][12] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: terminal = Blocked(123, 13, 123) */
		reached[1][13] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 17, 123) */
		reached[1][17] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 18: // STATE 15 - revision.pml:86 - [pc = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[1][15] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 18 - revision.pml:88 - [(((!(cancelled)&&!(expired))&&!(crashed)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][18] = 1;
		if (!((( !(((int)now.cancelled))&& !(((int)now.expired)))&& !(((int)now.crashed)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 19 - revision.pml:90 - [((pc==0))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][19] = 1;
		if (!((((int)now.pc)==0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 20 - revision.pml:92 - [(complete[stage])] (123:0:2 - 1)
		IfNotBlocked
		reached[1][20] = 1;
		if (!(((int)now.complete[ Index(((int)now.stage), 4) ])))
			continue;
		/* merge: replayed = 1(123, 21, 123) */
		reached[1][21] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)replayed);
		replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)replayed));
#endif
		;
		/* merge: pc = 4(123, 22, 123) */
		reached[1][22] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 123) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 22: // STATE 23 - revision.pml:99 - [(!(complete[stage]))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][23] = 1;
		if (!( !(((int)now.complete[ Index(((int)now.stage), 4) ]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 24 - revision.pml:101 - [(!(reserved[stage]))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][24] = 1;
		if (!( !(((int)now.reserved[ Index(((int)now.stage), 4) ]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 25 - revision.pml:103 - [((spent<frozen_limit))] (123:0:3 - 1)
		IfNotBlocked
		reached[1][25] = 1;
		if (!((((int)now.spent)<((int)now.frozen_limit))))
			continue;
		/* merge: reserved[stage] = 1(123, 26, 123) */
		reached[1][26] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.reserved[ Index(((int)now.stage), 4) ]);
		now.reserved[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("reserved[stage]", ((int)now.reserved[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: spent = (spent+1)(123, 27, 123) */
		reached[1][27] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.spent);
		now.spent = (((int)now.spent)+1);
#ifdef VAR_RANGES
		logval("spent", ((int)now.spent));
#endif
		;
		/* merge: .(goto)(123, 32, 123) */
		reached[1][32] = 1;
		;
		/* merge: .(goto)(123, 36, 123) */
		reached[1][36] = 1;
		;
		/* merge: pc = 1(123, 37, 123) */
		reached[1][37] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 123) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 25: // STATE 29 - revision.pml:104 - [budget_exhausted = 1] (0:123:3 - 1)
		IfNotBlocked
		reached[1][29] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)budget_exhausted);
		budget_exhausted = 1;
#ifdef VAR_RANGES
		logval("budget_exhausted", ((int)budget_exhausted));
#endif
		;
		/* merge: terminal = Exhausted(123, 30, 123) */
		reached[1][30] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(123, 32, 123) */
		reached[1][32] = 1;
		;
		/* merge: .(goto)(123, 36, 123) */
		reached[1][36] = 1;
		;
		/* merge: pc = 1(123, 37, 123) */
		reached[1][37] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 123) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 26: // STATE 34 - revision.pml:106 - [(1)] (123:0:1 - 1)
		IfNotBlocked
		reached[1][34] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(123, 36, 123) */
		reached[1][36] = 1;
		;
		/* merge: pc = 1(123, 37, 123) */
		reached[1][37] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 123) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 27: // STATE 37 - revision.pml:108 - [pc = 1] (0:123:1 - 5)
		IfNotBlocked
		reached[1][37] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 123) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 28: // STATE 40 - revision.pml:110 - [((pc==1))] (50:0:0 - 1)
		IfNotBlocked
		reached[1][40] = 1;
		if (!((((int)now.pc)==1)))
			continue;
		/* merge: assert(reserved[stage])(0, 41, 50) */
		reached[1][41] = 1;
		spin_assert(((int)now.reserved[ Index(((int)now.stage), 4) ]), "reserved[stage]", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 29: // STATE 42 - revision.pml:113 - [(effect_complete[stage])] (123:0:2 - 1)
		IfNotBlocked
		reached[1][42] = 1;
		if (!(((int)now.effect_complete[ Index(((int)now.stage), 4) ])))
			continue;
		/* merge: replayed = 1(123, 43, 123) */
		reached[1][43] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)replayed);
		replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)replayed));
#endif
		;
		/* merge: pc = 3(123, 44, 123) */
		reached[1][44] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 51, 123) */
		reached[1][51] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 30: // STATE 46 - revision.pml:114 - [effect_dispatches[stage] = (effect_dispatches[stage]+1)] (0:123:4 - 1)
		IfNotBlocked
		reached[1][46] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.effect_dispatches[ Index(((int)now.stage), 4) ]);
		now.effect_dispatches[ Index(now.stage, 4) ] = (((int)now.effect_dispatches[ Index(((int)now.stage), 4) ])+1);
#ifdef VAR_RANGES
		logval("effect_dispatches[stage]", ((int)now.effect_dispatches[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 1(123, 47, 123) */
		reached[1][47] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: ever_started = 1(123, 48, 123) */
		reached[1][48] = 1;
		(trpt+1)->bup.ovals[2] = ((int)ever_started);
		ever_started = 1;
#ifdef VAR_RANGES
		logval("ever_started", ((int)ever_started));
#endif
		;
		/* merge: pc = 2(123, 49, 123) */
		reached[1][49] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 2;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 51, 123) */
		reached[1][51] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 31: // STATE 52 - revision.pml:119 - [((pc==2))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][52] = 1;
		if (!((((int)now.pc)==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 53 - revision.pml:121 - [(((stage==0)||(stage==2)))] (123:0:4 - 1)
		IfNotBlocked
		reached[1][53] = 1;
		if (!(((((int)now.stage)==0)||(((int)now.stage)==2))))
			continue;
		/* merge: candidate = ((stage/2)+1)(123, 54, 123) */
		reached[1][54] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.candidate);
		now.candidate = ((((int)now.stage)/2)+1);
#ifdef VAR_RANGES
		logval("candidate", ((int)now.candidate));
#endif
		;
		/* merge: .(goto)(123, 63, 123) */
		reached[1][63] = 1;
		;
		/* merge: effect_complete[stage] = 1(123, 64, 123) */
		reached[1][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(123, 65, 123) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(123, 66, 123) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 33: // STATE 56 - revision.pml:125 - [verdict[stage] = 1] (0:123:4 - 1)
		IfNotBlocked
		reached[1][56] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.verdict[ Index(((int)now.stage), 4) ]);
		now.verdict[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("verdict[stage]", ((int)now.verdict[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: .(goto)(123, 61, 123) */
		reached[1][61] = 1;
		;
		/* merge: .(goto)(123, 63, 123) */
		reached[1][63] = 1;
		;
		/* merge: effect_complete[stage] = 1(123, 64, 123) */
		reached[1][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(123, 65, 123) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(123, 66, 123) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 34: // STATE 57 - revision.pml:126 - [verdict[stage] = 2] (0:123:4 - 1)
		IfNotBlocked
		reached[1][57] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.verdict[ Index(((int)now.stage), 4) ]);
		now.verdict[ Index(now.stage, 4) ] = 2;
#ifdef VAR_RANGES
		logval("verdict[stage]", ((int)now.verdict[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: .(goto)(123, 61, 123) */
		reached[1][61] = 1;
		;
		/* merge: .(goto)(123, 63, 123) */
		reached[1][63] = 1;
		;
		/* merge: effect_complete[stage] = 1(123, 64, 123) */
		reached[1][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(123, 65, 123) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(123, 66, 123) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 35: // STATE 58 - revision.pml:127 - [verdict[stage] = 3] (0:123:5 - 1)
		IfNotBlocked
		reached[1][58] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)now.verdict[ Index(((int)now.stage), 4) ]);
		now.verdict[ Index(now.stage, 4) ] = 3;
#ifdef VAR_RANGES
		logval("verdict[stage]", ((int)now.verdict[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: retained_error = 1(123, 59, 123) */
		reached[1][59] = 1;
		(trpt+1)->bup.ovals[1] = ((int)retained_error);
		retained_error = 1;
#ifdef VAR_RANGES
		logval("retained_error", ((int)retained_error));
#endif
		;
		/* merge: .(goto)(123, 61, 123) */
		reached[1][61] = 1;
		;
		/* merge: .(goto)(123, 63, 123) */
		reached[1][63] = 1;
		;
		/* merge: effect_complete[stage] = 1(123, 64, 123) */
		reached[1][64] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(123, 65, 123) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(123, 66, 123) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 36: // STATE 64 - revision.pml:130 - [effect_complete[stage] = 1] (0:123:3 - 6)
		IfNotBlocked
		reached[1][64] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(123, 65, 123) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(123, 66, 123) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 37: // STATE 67 - revision.pml:133 - [((pc==3))] (123:0:2 - 1)
		IfNotBlocked
		reached[1][67] = 1;
		if (!((((int)now.pc)==3)))
			continue;
		/* merge: complete[stage] = 1(123, 68, 123) */
		reached[1][68] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.complete[ Index(((int)now.stage), 4) ]);
		now.complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("complete[stage]", ((int)now.complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 4(123, 69, 123) */
		reached[1][69] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 38: // STATE 70 - revision.pml:134 - [((pc==4))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][70] = 1;
		if (!((((int)now.pc)==4)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 39: // STATE 71 - revision.pml:136 - [(((stage==0)||(stage==2)))] (123:0:2 - 1)
		IfNotBlocked
		reached[1][71] = 1;
		if (!(((((int)now.stage)==0)||(((int)now.stage)==2))))
			continue;
		/* merge: stage = (stage+1)(123, 72, 123) */
		reached[1][72] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.stage);
		now.stage = (((int)now.stage)+1);
#ifdef VAR_RANGES
		logval("stage", ((int)now.stage));
#endif
		;
		/* merge: pc = 0(123, 73, 123) */
		reached[1][73] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 90, 123) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 40: // STATE 74 - revision.pml:137 - [(((stage==1)||(stage==3)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][74] = 1;
		if (!(((((int)now.stage)==1)||(((int)now.stage)==3))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 41: // STATE 75 - revision.pml:139 - [(assessment_retained[stage])] (123:0:3 - 1)
		IfNotBlocked
		reached[1][75] = 1;
		if (!(((int)now.assessment_retained[ Index(((int)now.stage), 4) ])))
			continue;
		/* merge: assessment_replayed = 1(123, 76, 123) */
		reached[1][76] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)assessment_replayed);
		assessment_replayed = 1;
#ifdef VAR_RANGES
		logval("assessment_replayed", ((int)assessment_replayed));
#endif
		;
		/* merge: decision[stage] = assessment_verdict[stage](123, 77, 123) */
		reached[1][77] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.decision[ Index(((int)now.stage), 4) ]);
		now.decision[ Index(now.stage, 4) ] = ((int)now.assessment_verdict[ Index(((int)now.stage), 4) ]);
#ifdef VAR_RANGES
		logval("decision[stage]", ((int)now.decision[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: .(goto)(123, 87, 123) */
		reached[1][87] = 1;
		;
		/* merge: pc = 5(123, 88, 123) */
		reached[1][88] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 5;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 90, 123) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 42: // STATE 79 - revision.pml:148 - [decision[stage] = verdict[stage]] (0:123:4 - 1)
		IfNotBlocked
		reached[1][79] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.decision[ Index(((int)now.stage), 4) ]);
		now.decision[ Index(now.stage, 4) ] = ((int)now.verdict[ Index(((int)now.stage), 4) ]);
#ifdef VAR_RANGES
		logval("decision[stage]", ((int)now.decision[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: .(goto)(123, 83, 123) */
		reached[1][83] = 1;
		;
		/* merge: assessment_verdict[stage] = decision[stage](123, 84, 123) */
		reached[1][84] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.assessment_verdict[ Index(((int)now.stage), 4) ]);
		now.assessment_verdict[ Index(now.stage, 4) ] = ((int)now.decision[ Index(((int)now.stage), 4) ]);
#ifdef VAR_RANGES
		logval("assessment_verdict[stage]", ((int)now.assessment_verdict[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: assessment_retained[stage] = 1(123, 85, 123) */
		reached[1][85] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.assessment_retained[ Index(((int)now.stage), 4) ]);
		now.assessment_retained[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("assessment_retained[stage]", ((int)now.assessment_retained[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: .(goto)(123, 87, 123) */
		reached[1][87] = 1;
		;
		/* merge: pc = 5(123, 88, 123) */
		reached[1][88] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 5;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 90, 123) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 43: // STATE 80 - revision.pml:151 - [decision[stage] = 3] (0:123:5 - 1)
		IfNotBlocked
		reached[1][80] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)now.decision[ Index(((int)now.stage), 4) ]);
		now.decision[ Index(now.stage, 4) ] = 3;
#ifdef VAR_RANGES
		logval("decision[stage]", ((int)now.decision[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: retained_error = 1(123, 81, 123) */
		reached[1][81] = 1;
		(trpt+1)->bup.ovals[1] = ((int)retained_error);
		retained_error = 1;
#ifdef VAR_RANGES
		logval("retained_error", ((int)retained_error));
#endif
		;
		/* merge: .(goto)(123, 83, 123) */
		reached[1][83] = 1;
		;
		/* merge: assessment_verdict[stage] = decision[stage](123, 84, 123) */
		reached[1][84] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.assessment_verdict[ Index(((int)now.stage), 4) ]);
		now.assessment_verdict[ Index(now.stage, 4) ] = ((int)now.decision[ Index(((int)now.stage), 4) ]);
#ifdef VAR_RANGES
		logval("assessment_verdict[stage]", ((int)now.assessment_verdict[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: assessment_retained[stage] = 1(123, 85, 123) */
		reached[1][85] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.assessment_retained[ Index(((int)now.stage), 4) ]);
		now.assessment_retained[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("assessment_retained[stage]", ((int)now.assessment_retained[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: .(goto)(123, 87, 123) */
		reached[1][87] = 1;
		;
		/* merge: pc = 5(123, 88, 123) */
		reached[1][88] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.pc);
		now.pc = 5;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 90, 123) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 44: // STATE 84 - revision.pml:153 - [assessment_verdict[stage] = decision[stage]] (0:123:3 - 3)
		IfNotBlocked
		reached[1][84] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.assessment_verdict[ Index(((int)now.stage), 4) ]);
		now.assessment_verdict[ Index(now.stage, 4) ] = ((int)now.decision[ Index(((int)now.stage), 4) ]);
#ifdef VAR_RANGES
		logval("assessment_verdict[stage]", ((int)now.assessment_verdict[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: assessment_retained[stage] = 1(123, 85, 123) */
		reached[1][85] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.assessment_retained[ Index(((int)now.stage), 4) ]);
		now.assessment_retained[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("assessment_retained[stage]", ((int)now.assessment_retained[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: .(goto)(123, 87, 123) */
		reached[1][87] = 1;
		;
		/* merge: pc = 5(123, 88, 123) */
		reached[1][88] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 5;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 90, 123) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 45: // STATE 88 - revision.pml:156 - [pc = 5] (0:123:1 - 3)
		IfNotBlocked
		reached[1][88] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 5;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 90, 123) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 46: // STATE 91 - revision.pml:158 - [((pc==5))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][91] = 1;
		if (!((((int)now.pc)==5)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 47: // STATE 92 - revision.pml:160 - [((decision[stage]==1))] (123:0:2 - 1)
		IfNotBlocked
		reached[1][92] = 1;
		if (!((((int)now.decision[ Index(((int)now.stage), 4) ])==1)))
			continue;
		/* merge: selected = candidate(123, 93, 123) */
		reached[1][93] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.selected);
		now.selected = ((int)now.candidate);
#ifdef VAR_RANGES
		logval("selected", ((int)now.selected));
#endif
		;
		/* merge: terminal = Completed(123, 94, 123) */
		reached[1][94] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 109, 123) */
		reached[1][109] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 48: // STATE 95 - revision.pml:161 - [((decision[stage]!=1))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][95] = 1;
		if (!((((int)now.decision[ Index(((int)now.stage), 4) ])!=1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 49: // STATE 96 - revision.pml:169 - [(((stage==1)&&(terminal==Running)))] (123:0:4 - 1)
		IfNotBlocked
		reached[1][96] = 1;
		if (!(((((int)now.stage)==1)&&(now.terminal==6))))
			continue;
		/* merge: revisions = (revisions+1)(123, 97, 123) */
		reached[1][97] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.revisions);
		now.revisions = (((int)now.revisions)+1);
#ifdef VAR_RANGES
		logval("revisions", ((int)now.revisions));
#endif
		;
		/* merge: remediation_effects = (remediation_effects+1)(123, 98, 123) */
		reached[1][98] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.remediation_effects);
		now.remediation_effects = (((int)now.remediation_effects)+1);
#ifdef VAR_RANGES
		logval("remediation_effects", ((int)now.remediation_effects));
#endif
		;
		/* merge: stage = 2(123, 99, 123) */
		reached[1][99] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.stage);
		now.stage = 2;
#ifdef VAR_RANGES
		logval("stage", ((int)now.stage));
#endif
		;
		/* merge: pc = 0(123, 100, 123) */
		reached[1][100] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 107, 123) */
		reached[1][107] = 1;
		;
		/* merge: .(goto)(0, 109, 123) */
		reached[1][109] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 50: // STATE 101 - revision.pml:184 - [(((stage==3)&&(terminal==Running)))] (123:0:2 - 1)
		IfNotBlocked
		reached[1][101] = 1;
		if (!(((((int)now.stage)==3)&&(now.terminal==6))))
			continue;
		/* merge: selected = candidate(123, 102, 123) */
		reached[1][102] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.selected);
		now.selected = ((int)now.candidate);
#ifdef VAR_RANGES
		logval("selected", ((int)now.selected));
#endif
		;
		/* merge: terminal = Exhausted(123, 103, 123) */
		reached[1][103] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 107, 123) */
		reached[1][107] = 1;
		;
		/* merge: .(goto)(0, 109, 123) */
		reached[1][109] = 1;
		;
		/* merge: .(goto)(0, 111, 123) */
		reached[1][111] = 1;
		;
		/* merge: .(goto)(0, 113, 123) */
		reached[1][113] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 51: // STATE 114 - revision.pml:44 - [assert(((spent<=frozen_limit)&&(frozen_limit<=4)))] (0:125:0 - 1)
		IfNotBlocked
		reached[1][114] = 1;
		spin_assert(((((int)now.spent)<=((int)now.frozen_limit))&&(((int)now.frozen_limit)<=4)), "((spent<=frozen_limit)&&(frozen_limit<=4))", II, tt, t);
		/* merge: assert((revisions<=1))(125, 115, 125) */
		reached[1][115] = 1;
		spin_assert((((int)now.revisions)<=1), "(revisions<=1)", II, tt, t);
		/* merge: assert((permitted_effects==1))(125, 116, 125) */
		reached[1][116] = 1;
		spin_assert((((int)now.permitted_effects)==1), "(permitted_effects==1)", II, tt, t);
		/* merge: assert((active_deadline==frozen_deadline))(125, 117, 125) */
		reached[1][117] = 1;
		spin_assert((((int)now.active_deadline)==((int)now.frozen_deadline)), "(active_deadline==frozen_deadline)", II, tt, t);
		/* merge: assert((remediation_effects==0))(125, 118, 125) */
		reached[1][118] = 1;
		spin_assert((((int)now.remediation_effects)==0), "(remediation_effects==0)", II, tt, t);
		/* merge: assert(((((effect_dispatches[0]<=1)&&(effect_dispatches[1]<=1))&&(effect_dispatches[2]<=1))&&(effect_dispatches[3]<=1)))(125, 119, 125) */
		reached[1][119] = 1;
		spin_assert(((((((int)now.effect_dispatches[0])<=1)&&(((int)now.effect_dispatches[1])<=1))&&(((int)now.effect_dispatches[2])<=1))&&(((int)now.effect_dispatches[3])<=1)), "((((effect_dispatches[0]<=1)&&(effect_dispatches[1]<=1))&&(effect_dispatches[2]<=1))&&(effect_dispatches[3]<=1))", II, tt, t);
		/* merge: assert((!(assessment_retained[1])||(decision[1]==assessment_verdict[1])))(125, 120, 125) */
		reached[1][120] = 1;
		spin_assert(( !(((int)now.assessment_retained[1]))||(((int)now.decision[1])==((int)now.assessment_verdict[1]))), "( !(assessment_retained[1])||(decision[1]==assessment_verdict[1]))", II, tt, t);
		/* merge: assert((!(assessment_retained[3])||(decision[3]==assessment_verdict[3])))(125, 121, 125) */
		reached[1][121] = 1;
		spin_assert(( !(((int)now.assessment_retained[3]))||(((int)now.decision[3])==((int)now.assessment_verdict[3]))), "( !(assessment_retained[3])||(decision[3]==assessment_verdict[3]))", II, tt, t);
		/* merge: assert(((terminal!=Completed)||((((selected==1)&&complete[1])&&(decision[1]==1))||(((selected==2)&&complete[3])&&(decision[3]==1)))))(125, 122, 125) */
		reached[1][122] = 1;
		spin_assert(((now.terminal!=5)||((((((int)now.selected)==1)&&((int)now.complete[1]))&&(((int)now.decision[1])==1))||(((((int)now.selected)==2)&&((int)now.complete[3]))&&(((int)now.decision[3])==1)))), "((terminal!=5)||((((selected==1)&&complete[1])&&(decision[1]==1))||(((selected==2)&&complete[3])&&(decision[3]==1))))", II, tt, t);
		/* merge: .(goto)(0, 126, 125) */
		reached[1][126] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 52: // STATE 128 - revision.pml:221 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[1][128] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Disruption */
	case 53: // STATE 2 - revision.pml:61 - [cancelled = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		(trpt+1)->bup.oval = ((int)now.cancelled);
		now.cancelled = 1;
#ifdef VAR_RANGES
		logval("cancelled", ((int)now.cancelled));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 54: // STATE 3 - revision.pml:62 - [expired = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		(trpt+1)->bup.oval = ((int)now.expired);
		now.expired = 1;
#ifdef VAR_RANGES
		logval("expired", ((int)now.expired));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 55: // STATE 4 - revision.pml:63 - [crashed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][4] = 1;
		(trpt+1)->bup.oval = ((int)now.crashed);
		now.crashed = 1;
#ifdef VAR_RANGES
		logval("crashed", ((int)now.crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 56: // STATE 7 - revision.pml:65 - [-end-] (0:0:0 - 5)
		IfNotBlocked
		reached[0][7] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

