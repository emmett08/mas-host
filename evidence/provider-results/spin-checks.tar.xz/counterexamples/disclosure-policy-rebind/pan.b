	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM context_finishes */
;
		;
		;
		;
		
	case 5: // STATE 13
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 6: // STATE 1
		;
		now.feedback_reader = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 2
		;
		now.feedback_reader = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 11
		;
		now.assembled = trpt->bup.ovals[5];
		now.snapshot_b = trpt->bup.ovals[4];
		now.snapshot_a = trpt->bup.ovals[3];
		now.reviewer_input_b = trpt->bup.ovals[2];
		now.reviewer_input_a = trpt->bup.ovals[1];
		now.frozen_policy = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 6);
		goto R999;

	case 9: // STATE 13
		;
		now.peer_a = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 14
		;
		peer_b = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 15
		;
		now.public_evidence = trpt->bup.oval;
		;
		goto R999;

	case 12: // STATE 16
		;
		now.reviewer_input_a = trpt->bup.oval;
		;
		goto R999;

	case 13: // STATE 17
		;
		now.reviewer_input_b = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 15: // STATE 19
		;
		now.active_policy = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 20
		;
		now.rejected_rebind = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 18: // STATE 22
		;
		supplied_feedback = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 23
		;
		author_input = trpt->bup.oval;
		;
		goto R999;

	case 20: // STATE 24
		;
		now.output_reader = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 22: // STATE 26
		;
		now.delegate_permitted = trpt->bup.oval;
		;
		goto R999;

	case 23: // STATE 27
		;
		now.delegate_permitted = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 25: // STATE 31
		;
		now.delegated = trpt->bup.oval;
		;
		goto R999;

	case 26: // STATE 33
		;
		now.delegated = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 28: // STATE 37
		;
		now.parent_viewer = trpt->bup.oval;
		;
		goto R999;

	case 29: // STATE 38
		;
		now.parent_viewer = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 31: // STATE 42
		;
		now.inherited_reader = trpt->bup.oval;
		;
		goto R999;

	case 32: // STATE 44
		;
		now.inherited_reader = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 34: // STATE 48
		;
		now.source_collision = trpt->bup.oval;
		;
		goto R999;

	case 35: // STATE 49
		;
		now.source_collision = trpt->bup.oval;
		;
		goto R999;

	case 36: // STATE 52
		;
		now.draft_dispatched = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 38: // STATE 54
		;
		now.candidate_evidence_reader = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 40: // STATE 56
		;
		now.completed = trpt->bup.oval;
		;
		goto R999;

	case 41: // STATE 57
		;
		p_restor(II);
		;
		;
		goto R999;
	}

