	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM delegation_finishes */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 5: // STATE 1
		;
		now.minimum = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 2
		;
		now.minimum = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 3
		;
		now.minimum = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 6
		;
		now.required = trpt->bup.oval;
		;
		goto R999;

	case 9: // STATE 7
		;
		now.required = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 8
		;
		now.required = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 9
		;
		now.required = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 14: // STATE 14
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 16: // STATE 16
		;
		now.complete_allowed = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 17
		;
		now.request_allowed = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 19: // STATE 19
		;
		now.permitted_requests = trpt->bup.oval;
		;
		goto R999;

	case 20: // STATE 21
		;
		now.permitted_requests = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 22: // STATE 25
		;
		now.permitted_requests = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		
	case 26: // STATE 33
		;
		now.turns = trpt->bup.oval;
		;
		goto R999;

	case 27: // STATE 34
		;
		now.provider_dispatches = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 29: // STATE 36
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 31: // STATE 39
		;
		early_completion_rejected = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 33: // STATE 45
		;
		partial_completion_rejected = trpt->bup.oval;
		;
		goto R999;

	case 34: // STATE 50
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 35: // STATE 53
		;
		now.selected = trpt->bup.oval;
		;
		goto R999;

	case 36: // STATE 54
		;
		now.selected = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 38: // STATE 58
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		
	case 42: // STATE 62
		;
		duplicate_rejected = trpt->bup.oval;
		;
		goto R999;

	case 43: // STATE 67
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 46: // STATE 70
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 48: // STATE 72
		;
		now.peer_dispatches = trpt->bup.oval;
		;
		goto R999;

	case 49: // STATE 73
		;
		now.successful = trpt->bup.oval;
		;
		goto R999;

	case 50: // STATE 74
		;
		now.retained_successful = trpt->bup.oval;
		;
		goto R999;

	case 51: // STATE 75
		;
		now.covered = trpt->bup.oval;
		;
		goto R999;

	case 52: // STATE 76
		;
		now.retained_covered = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 54: // STATE 78
		;
		now.first_peer = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 56: // STATE 84
		;
		now.saved_provider_dispatches = trpt->bup.oval;
		;
		goto R999;

	case 57: // STATE 85
		;
		now.saved_peer_dispatches = trpt->bup.oval;
		;
		goto R999;

	case 58: // STATE 86
		;
		now.successful = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 60: // STATE 88
		;
		now.successful = trpt->bup.oval;
		;
		goto R999;

	case 61: // STATE 94
		;
		now.covered = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		
	case 66: // STATE 99
		;
		now.replayed = trpt->bup.oval;
		;
		goto R999;

	case 67: // STATE 104
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 68: // STATE 113
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 69: // STATE 114
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 70: // STATE 115
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 71: // STATE 116
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		
	case 80: // STATE 133
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;

	case 81: // STATE 134
		;
		p_restor(II);
		;
		;
		goto R999;
	}

