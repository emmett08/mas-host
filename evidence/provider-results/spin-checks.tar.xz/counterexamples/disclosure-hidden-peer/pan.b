	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM context_finishes */
;
		;
		;
		;
		
	case 5: // STATE 13
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 6: // STATE 1
		;
		now.feedback_reader = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 2
		;
		now.feedback_reader = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 13
		;
		now.assembled = trpt->bup.ovals[7];
		now.snapshot_b = trpt->bup.ovals[6];
		now.snapshot_a = trpt->bup.ovals[5];
		now.reviewer_input_b = trpt->bup.ovals[4];
		now.reviewer_input_a = trpt->bup.ovals[3];
		now.reviewer_input_b = trpt->bup.ovals[2];
		now.reviewer_input_a = trpt->bup.ovals[1];
		now.frozen_policy = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 8);
		goto R999;

	case 9: // STATE 15
		;
		now.peer_a = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 16
		;
		now.peer_b = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 17
		;
		now.public_evidence = trpt->bup.oval;
		;
		goto R999;

	case 12: // STATE 18
		;
		now.reviewer_input_a = trpt->bup.oval;
		;
		goto R999;

	case 13: // STATE 19
		;
		now.reviewer_input_b = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 15: // STATE 21
		;
		now.rejected_rebind = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 17: // STATE 23
		;
		supplied_feedback = trpt->bup.oval;
		;
		goto R999;

	case 18: // STATE 24
		;
		author_input = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 25
		;
		now.output_reader = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 21: // STATE 27
		;
		now.delegate_permitted = trpt->bup.oval;
		;
		goto R999;

	case 22: // STATE 28
		;
		now.delegate_permitted = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 24: // STATE 32
		;
		now.delegated = trpt->bup.oval;
		;
		goto R999;

	case 25: // STATE 34
		;
		now.delegated = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 27: // STATE 38
		;
		now.parent_viewer = trpt->bup.oval;
		;
		goto R999;

	case 28: // STATE 39
		;
		now.parent_viewer = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 30: // STATE 43
		;
		now.inherited_reader = trpt->bup.oval;
		;
		goto R999;

	case 31: // STATE 45
		;
		now.inherited_reader = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 33: // STATE 49
		;
		now.source_collision = trpt->bup.oval;
		;
		goto R999;

	case 34: // STATE 50
		;
		now.source_collision = trpt->bup.oval;
		;
		goto R999;

	case 35: // STATE 53
		;
		now.draft_dispatched = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 37: // STATE 55
		;
		now.candidate_evidence_reader = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 39: // STATE 57
		;
		now.completed = trpt->bup.oval;
		;
		goto R999;

	case 40: // STATE 58
		;
		p_restor(II);
		;
		;
		goto R999;
	}

