	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM delegation_finishes */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 5: // STATE 1
		;
		now.minimum = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 2
		;
		now.minimum = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 3
		;
		now.minimum = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 6
		;
		now.required = trpt->bup.oval;
		;
		goto R999;

	case 9: // STATE 7
		;
		now.required = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 8
		;
		now.required = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 9
		;
		now.required = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		
	case 21: // STATE 29
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;

	case 22: // STATE 30
		;
		p_restor(II);
		;
		;
		goto R999;
	}

