#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM delegation_finishes */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(finished))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][1] = 1;
		if (!( !(((int)now.finished))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - delegation.pml:66 - [minimum = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)now.minimum);
		now.minimum = 0;
#ifdef VAR_RANGES
		logval("minimum", ((int)now.minimum));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - delegation.pml:66 - [minimum = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		(trpt+1)->bup.oval = ((int)now.minimum);
		now.minimum = 1;
#ifdef VAR_RANGES
		logval("minimum", ((int)now.minimum));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 3 - delegation.pml:66 - [minimum = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		(trpt+1)->bup.oval = ((int)now.minimum);
		now.minimum = 2;
#ifdef VAR_RANGES
		logval("minimum", ((int)now.minimum));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 6 - delegation.pml:67 - [required = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][6] = 1;
		(trpt+1)->bup.oval = ((int)now.required);
		now.required = 0;
#ifdef VAR_RANGES
		logval("required", ((int)now.required));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 7 - delegation.pml:67 - [required = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][7] = 1;
		(trpt+1)->bup.oval = ((int)now.required);
		now.required = 1;
#ifdef VAR_RANGES
		logval("required", ((int)now.required));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 10: // STATE 8 - delegation.pml:67 - [required = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[0][8] = 1;
		(trpt+1)->bup.oval = ((int)now.required);
		now.required = 2;
#ifdef VAR_RANGES
		logval("required", ((int)now.required));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 9 - delegation.pml:67 - [required = 3] (0:0:1 - 1)
		IfNotBlocked
		reached[0][9] = 1;
		(trpt+1)->bup.oval = ((int)now.required);
		now.required = 3;
#ifdef VAR_RANGES
		logval("required", ((int)now.required));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 12 - delegation.pml:69 - [((terminal==Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][12] = 1;
		if (!((now.terminal==8)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 17 - delegation.pml:164 - [((terminal!=Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][17] = 1;
		if (!((now.terminal!=8)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 22 - delegation.pml:166 - [assert(((terminal!=Completed)||(successful>=minimum)))] (0:0:0 - 4)
		IfNotBlocked
		reached[0][22] = 1;
		spin_assert(((now.terminal!=7)||(((int)now.successful)>=((int)now.minimum))), "((terminal!=7)||(successful>=minimum))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 15: // STATE 23 - delegation.pml:167 - [assert(((terminal!=Completed)||((covered&required)==required)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][23] = 1;
		spin_assert(((now.terminal!=7)||((((int)now.covered)&((int)now.required))==((int)now.required))), "((terminal!=7)||((covered&required)==required))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 24 - delegation.pml:168 - [assert((successful==retained_successful))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][24] = 1;
		spin_assert((((int)now.successful)==((int)now.retained_successful)), "(successful==retained_successful)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 25 - delegation.pml:169 - [assert((covered==retained_covered))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][25] = 1;
		spin_assert((((int)now.covered)==((int)now.retained_covered)), "(covered==retained_covered)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 26 - delegation.pml:170 - [assert((provider_dispatches<=3))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][26] = 1;
		spin_assert((((int)now.provider_dispatches)<=3), "(provider_dispatches<=3)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 27 - delegation.pml:171 - [assert((peer_dispatches<3))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][27] = 1;
		spin_assert((((int)now.peer_dispatches)<3), "(peer_dispatches<3)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 28 - delegation.pml:172 - [assert((successful<=peer_dispatches))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][28] = 1;
		spin_assert((((int)now.successful)<=((int)now.peer_dispatches)), "(successful<=peer_dispatches)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 29 - delegation.pml:173 - [finished = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][29] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = 1;
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 30 - delegation.pml:195 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][30] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

