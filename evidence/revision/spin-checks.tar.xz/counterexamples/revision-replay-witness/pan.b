	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 5: // STATE 1
		;
		now.frozen_limit = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 2
		;
		now.frozen_limit = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 3
		;
		now.frozen_limit = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 4
		;
		now.frozen_limit = trpt->bup.oval;
		;
		goto R999;

	case 9: // STATE 7
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 10: // STATE 8
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 11: // STATE 10
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Controller */
;
		;
		;
		;
		
	case 14: // STATE 5
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 15: // STATE 7
		;
		now.terminal = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 10
		;
		now.crashed = trpt->bup.ovals[1];
		restarted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 17: // STATE 13
		;
		now.terminal = trpt->bup.ovals[1];
		unknown_seen = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 18: // STATE 15
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 21: // STATE 22
		;
		now.pc = trpt->bup.ovals[1];
		now.replayed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 24: // STATE 37
		;
		now.pc = trpt->bup.ovals[2];
		now.spent = trpt->bup.ovals[1];
		now.reserved[ Index(now.stage, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 25: // STATE 37
		;
		now.pc = trpt->bup.ovals[2];
		now.terminal = trpt->bup.ovals[1];
		budget_exhausted = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 26: // STATE 37
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;

	case 27: // STATE 37
		;
		now.pc = trpt->bup.oval;
		;
		goto R999;
;
		
	case 28: // STATE 40
		goto R999;

	case 29: // STATE 44
		;
		now.pc = trpt->bup.ovals[1];
		now.replayed = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 30: // STATE 49
		;
		now.pc = trpt->bup.ovals[3];
		ever_started = trpt->bup.ovals[2];
		now.inflight[ Index(now.stage, 4) ] = trpt->bup.ovals[1];
		now.effect_dispatches[ Index(now.stage, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;
;
		;
		
	case 32: // STATE 66
		;
		now.pc = trpt->bup.ovals[3];
		now.inflight[ Index(now.stage, 4) ] = trpt->bup.ovals[2];
		now.effect_complete[ Index(now.stage, 4) ] = trpt->bup.ovals[1];
		now.candidate = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 33: // STATE 66
		;
		now.pc = trpt->bup.ovals[3];
		now.inflight[ Index(now.stage, 4) ] = trpt->bup.ovals[2];
		now.effect_complete[ Index(now.stage, 4) ] = trpt->bup.ovals[1];
		now.verdict[ Index(now.stage, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 34: // STATE 66
		;
		now.pc = trpt->bup.ovals[3];
		now.inflight[ Index(now.stage, 4) ] = trpt->bup.ovals[2];
		now.effect_complete[ Index(now.stage, 4) ] = trpt->bup.ovals[1];
		now.verdict[ Index(now.stage, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 35: // STATE 66
		;
		now.pc = trpt->bup.ovals[4];
		now.inflight[ Index(now.stage, 4) ] = trpt->bup.ovals[3];
		now.effect_complete[ Index(now.stage, 4) ] = trpt->bup.ovals[2];
		retained_error = trpt->bup.ovals[1];
		now.verdict[ Index(now.stage, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 5);
		goto R999;

	case 36: // STATE 66
		;
		now.pc = trpt->bup.ovals[2];
		now.inflight[ Index(now.stage, 4) ] = trpt->bup.ovals[1];
		now.effect_complete[ Index(now.stage, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 37: // STATE 69
		;
		now.pc = trpt->bup.ovals[1];
		now.complete[ Index(now.stage, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 39: // STATE 73
		;
		now.pc = trpt->bup.ovals[1];
		now.stage = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 41: // STATE 77
		;
		now.terminal = trpt->bup.ovals[1];
		now.selected = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 43: // STATE 82
		;
		now.pc = trpt->bup.ovals[2];
		now.stage = trpt->bup.ovals[1];
		now.revisions = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 44: // STATE 85
		;
		now.terminal = trpt->bup.ovals[1];
		now.selected = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 45: // STATE 98
		goto R999;
;
		;
		
	case 47: // STATE 111
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Disruption */

	case 48: // STATE 2
		;
		now.cancelled = trpt->bup.oval;
		;
		goto R999;

	case 49: // STATE 3
		;
		now.expired = trpt->bup.oval;
		;
		goto R999;

	case 50: // STATE 4
		;
		now.crashed = trpt->bup.oval;
		;
		goto R999;

	case 51: // STATE 7
		;
		p_restor(II);
		;
		;
		goto R999;
	}

