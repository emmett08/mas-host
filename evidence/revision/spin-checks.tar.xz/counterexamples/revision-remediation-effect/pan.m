#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!((terminal!=Running)))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[3][1] = 1;
		if (!( !((now.terminal!=6))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[3][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - revision.pml:196 - [frozen_limit = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[2][1] = 1;
		(trpt+1)->bup.oval = ((int)now.frozen_limit);
		now.frozen_limit = 1;
#ifdef VAR_RANGES
		logval("frozen_limit", ((int)now.frozen_limit));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - revision.pml:196 - [frozen_limit = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[2][2] = 1;
		(trpt+1)->bup.oval = ((int)now.frozen_limit);
		now.frozen_limit = 2;
#ifdef VAR_RANGES
		logval("frozen_limit", ((int)now.frozen_limit));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 3 - revision.pml:197 - [frozen_limit = 3] (0:0:1 - 1)
		IfNotBlocked
		reached[2][3] = 1;
		(trpt+1)->bup.oval = ((int)now.frozen_limit);
		now.frozen_limit = 3;
#ifdef VAR_RANGES
		logval("frozen_limit", ((int)now.frozen_limit));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 4 - revision.pml:197 - [frozen_limit = 4] (0:0:1 - 1)
		IfNotBlocked
		reached[2][4] = 1;
		(trpt+1)->bup.oval = ((int)now.frozen_limit);
		now.frozen_limit = 4;
#ifdef VAR_RANGES
		logval("frozen_limit", ((int)now.frozen_limit));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 7 - revision.pml:198 - [(run Disruption())] (0:0:0 - 5)
		IfNotBlocked
		reached[2][7] = 1;
		if (!(addproc(II, 1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 10: // STATE 8 - revision.pml:198 - [(run Controller())] (0:0:0 - 1)
		IfNotBlocked
		reached[2][8] = 1;
		if (!(addproc(II, 1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 10 - revision.pml:200 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[2][10] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Controller */
	case 12: // STATE 1 - revision.pml:63 - [((terminal!=Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][1] = 1;
		if (!((now.terminal!=6)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 3 - revision.pml:64 - [((terminal==Running))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][3] = 1;
		if (!((now.terminal==6)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 4 - revision.pml:67 - [(cancelled)] (106:0:1 - 1)
		IfNotBlocked
		reached[1][4] = 1;
		if (!(((int)now.cancelled)))
			continue;
		/* merge: terminal = Cancelled(0, 5, 106) */
		reached[1][5] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 3;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 15: // STATE 6 - revision.pml:68 - [((!(cancelled)&&expired))] (106:0:1 - 1)
		IfNotBlocked
		reached[1][6] = 1;
		if (!(( !(((int)now.cancelled))&&((int)now.expired))))
			continue;
		/* merge: terminal = Expired(0, 7, 106) */
		reached[1][7] = 1;
		(trpt+1)->bup.oval = now.terminal;
		now.terminal = 2;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 16: // STATE 8 - revision.pml:69 - [(((!(cancelled)&&!(expired))&&crashed))] (16:0:2 - 1)
		IfNotBlocked
		reached[1][8] = 1;
		if (!((( !(((int)now.cancelled))&& !(((int)now.expired)))&&((int)now.crashed))))
			continue;
		/* merge: restarted = 1(16, 9, 16) */
		reached[1][9] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)restarted);
		restarted = 1;
#ifdef VAR_RANGES
		logval("restarted", ((int)restarted));
#endif
		;
		/* merge: crashed = 0(16, 10, 16) */
		reached[1][10] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.crashed);
		now.crashed = 0;
#ifdef VAR_RANGES
		logval("crashed", ((int)now.crashed));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 17: // STATE 11 - revision.pml:73 - [((inflight[stage]&&!(effect_complete[stage])))] (106:0:2 - 1)
		IfNotBlocked
		reached[1][11] = 1;
		if (!((((int)now.inflight[ Index(((int)now.stage), 4) ])&& !(((int)now.effect_complete[ Index(((int)now.stage), 4) ])))))
			continue;
		/* merge: unknown_seen = 1(106, 12, 106) */
		reached[1][12] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)unknown_seen);
		unknown_seen = 1;
#ifdef VAR_RANGES
		logval("unknown_seen", ((int)unknown_seen));
#endif
		;
		/* merge: terminal = Blocked(106, 13, 106) */
		reached[1][13] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 1;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 17, 106) */
		reached[1][17] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 18: // STATE 15 - revision.pml:80 - [pc = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[1][15] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 18 - revision.pml:82 - [(((!(cancelled)&&!(expired))&&!(crashed)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][18] = 1;
		if (!((( !(((int)now.cancelled))&& !(((int)now.expired)))&& !(((int)now.crashed)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 19 - revision.pml:84 - [((pc==0))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][19] = 1;
		if (!((((int)now.pc)==0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 20 - revision.pml:86 - [(complete[stage])] (106:0:2 - 1)
		IfNotBlocked
		reached[1][20] = 1;
		if (!(((int)now.complete[ Index(((int)now.stage), 4) ])))
			continue;
		/* merge: replayed = 1(106, 21, 106) */
		reached[1][21] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)replayed);
		replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)replayed));
#endif
		;
		/* merge: pc = 4(106, 22, 106) */
		reached[1][22] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 106) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 22: // STATE 23 - revision.pml:93 - [(!(complete[stage]))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][23] = 1;
		if (!( !(((int)now.complete[ Index(((int)now.stage), 4) ]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 24 - revision.pml:95 - [(!(reserved[stage]))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][24] = 1;
		if (!( !(((int)now.reserved[ Index(((int)now.stage), 4) ]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 25 - revision.pml:97 - [((spent<frozen_limit))] (106:0:3 - 1)
		IfNotBlocked
		reached[1][25] = 1;
		if (!((((int)now.spent)<((int)now.frozen_limit))))
			continue;
		/* merge: reserved[stage] = 1(106, 26, 106) */
		reached[1][26] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.reserved[ Index(((int)now.stage), 4) ]);
		now.reserved[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("reserved[stage]", ((int)now.reserved[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: spent = (spent+1)(106, 27, 106) */
		reached[1][27] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.spent);
		now.spent = (((int)now.spent)+1);
#ifdef VAR_RANGES
		logval("spent", ((int)now.spent));
#endif
		;
		/* merge: .(goto)(106, 32, 106) */
		reached[1][32] = 1;
		;
		/* merge: .(goto)(106, 36, 106) */
		reached[1][36] = 1;
		;
		/* merge: pc = 1(106, 37, 106) */
		reached[1][37] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 106) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 25: // STATE 29 - revision.pml:98 - [budget_exhausted = 1] (0:106:3 - 1)
		IfNotBlocked
		reached[1][29] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)budget_exhausted);
		budget_exhausted = 1;
#ifdef VAR_RANGES
		logval("budget_exhausted", ((int)budget_exhausted));
#endif
		;
		/* merge: terminal = Exhausted(106, 30, 106) */
		reached[1][30] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(106, 32, 106) */
		reached[1][32] = 1;
		;
		/* merge: .(goto)(106, 36, 106) */
		reached[1][36] = 1;
		;
		/* merge: pc = 1(106, 37, 106) */
		reached[1][37] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 106) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 26: // STATE 34 - revision.pml:100 - [(1)] (106:0:1 - 1)
		IfNotBlocked
		reached[1][34] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(106, 36, 106) */
		reached[1][36] = 1;
		;
		/* merge: pc = 1(106, 37, 106) */
		reached[1][37] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 106) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 27: // STATE 37 - revision.pml:102 - [pc = 1] (0:106:1 - 5)
		IfNotBlocked
		reached[1][37] = 1;
		(trpt+1)->bup.oval = ((int)now.pc);
		now.pc = 1;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 39, 106) */
		reached[1][39] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 28: // STATE 40 - revision.pml:104 - [((pc==1))] (50:0:0 - 1)
		IfNotBlocked
		reached[1][40] = 1;
		if (!((((int)now.pc)==1)))
			continue;
		/* merge: assert(reserved[stage])(0, 41, 50) */
		reached[1][41] = 1;
		spin_assert(((int)now.reserved[ Index(((int)now.stage), 4) ]), "reserved[stage]", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 29: // STATE 42 - revision.pml:107 - [(effect_complete[stage])] (106:0:2 - 1)
		IfNotBlocked
		reached[1][42] = 1;
		if (!(((int)now.effect_complete[ Index(((int)now.stage), 4) ])))
			continue;
		/* merge: replayed = 1(106, 43, 106) */
		reached[1][43] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)replayed);
		replayed = 1;
#ifdef VAR_RANGES
		logval("replayed", ((int)replayed));
#endif
		;
		/* merge: pc = 3(106, 44, 106) */
		reached[1][44] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 51, 106) */
		reached[1][51] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 30: // STATE 46 - revision.pml:108 - [effect_dispatches[stage] = (effect_dispatches[stage]+1)] (0:106:4 - 1)
		IfNotBlocked
		reached[1][46] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.effect_dispatches[ Index(((int)now.stage), 4) ]);
		now.effect_dispatches[ Index(now.stage, 4) ] = (((int)now.effect_dispatches[ Index(((int)now.stage), 4) ])+1);
#ifdef VAR_RANGES
		logval("effect_dispatches[stage]", ((int)now.effect_dispatches[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 1(106, 47, 106) */
		reached[1][47] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: ever_started = 1(106, 48, 106) */
		reached[1][48] = 1;
		(trpt+1)->bup.ovals[2] = ((int)ever_started);
		ever_started = 1;
#ifdef VAR_RANGES
		logval("ever_started", ((int)ever_started));
#endif
		;
		/* merge: pc = 2(106, 49, 106) */
		reached[1][49] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 2;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 51, 106) */
		reached[1][51] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 31: // STATE 52 - revision.pml:113 - [((pc==2))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][52] = 1;
		if (!((((int)now.pc)==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 53 - revision.pml:115 - [(((stage==0)||(stage==2)))] (106:0:4 - 1)
		IfNotBlocked
		reached[1][53] = 1;
		if (!(((((int)now.stage)==0)||(((int)now.stage)==2))))
			continue;
		/* merge: candidate = ((stage/2)+1)(106, 54, 106) */
		reached[1][54] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.candidate);
		now.candidate = ((((int)now.stage)/2)+1);
#ifdef VAR_RANGES
		logval("candidate", ((int)now.candidate));
#endif
		;
		/* merge: .(goto)(106, 63, 106) */
		reached[1][63] = 1;
		;
		/* merge: effect_complete[stage] = 1(106, 64, 106) */
		reached[1][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(106, 65, 106) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(106, 66, 106) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 33: // STATE 56 - revision.pml:119 - [verdict[stage] = 1] (0:106:4 - 1)
		IfNotBlocked
		reached[1][56] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.verdict[ Index(((int)now.stage), 4) ]);
		now.verdict[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("verdict[stage]", ((int)now.verdict[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: .(goto)(106, 61, 106) */
		reached[1][61] = 1;
		;
		/* merge: .(goto)(106, 63, 106) */
		reached[1][63] = 1;
		;
		/* merge: effect_complete[stage] = 1(106, 64, 106) */
		reached[1][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(106, 65, 106) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(106, 66, 106) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 34: // STATE 57 - revision.pml:120 - [verdict[stage] = 2] (0:106:4 - 1)
		IfNotBlocked
		reached[1][57] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.verdict[ Index(((int)now.stage), 4) ]);
		now.verdict[ Index(now.stage, 4) ] = 2;
#ifdef VAR_RANGES
		logval("verdict[stage]", ((int)now.verdict[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: .(goto)(106, 61, 106) */
		reached[1][61] = 1;
		;
		/* merge: .(goto)(106, 63, 106) */
		reached[1][63] = 1;
		;
		/* merge: effect_complete[stage] = 1(106, 64, 106) */
		reached[1][64] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(106, 65, 106) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(106, 66, 106) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 35: // STATE 58 - revision.pml:121 - [verdict[stage] = 3] (0:106:5 - 1)
		IfNotBlocked
		reached[1][58] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)now.verdict[ Index(((int)now.stage), 4) ]);
		now.verdict[ Index(now.stage, 4) ] = 3;
#ifdef VAR_RANGES
		logval("verdict[stage]", ((int)now.verdict[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: retained_error = 1(106, 59, 106) */
		reached[1][59] = 1;
		(trpt+1)->bup.ovals[1] = ((int)retained_error);
		retained_error = 1;
#ifdef VAR_RANGES
		logval("retained_error", ((int)retained_error));
#endif
		;
		/* merge: .(goto)(106, 61, 106) */
		reached[1][61] = 1;
		;
		/* merge: .(goto)(106, 63, 106) */
		reached[1][63] = 1;
		;
		/* merge: effect_complete[stage] = 1(106, 64, 106) */
		reached[1][64] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(106, 65, 106) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(106, 66, 106) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 36: // STATE 64 - revision.pml:124 - [effect_complete[stage] = 1] (0:106:3 - 6)
		IfNotBlocked
		reached[1][64] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.effect_complete[ Index(((int)now.stage), 4) ]);
		now.effect_complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("effect_complete[stage]", ((int)now.effect_complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: inflight[stage] = 0(106, 65, 106) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.inflight[ Index(((int)now.stage), 4) ]);
		now.inflight[ Index(now.stage, 4) ] = 0;
#ifdef VAR_RANGES
		logval("inflight[stage]", ((int)now.inflight[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 3(106, 66, 106) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.pc);
		now.pc = 3;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 37: // STATE 67 - revision.pml:127 - [((pc==3))] (106:0:2 - 1)
		IfNotBlocked
		reached[1][67] = 1;
		if (!((((int)now.pc)==3)))
			continue;
		/* merge: complete[stage] = 1(106, 68, 106) */
		reached[1][68] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.complete[ Index(((int)now.stage), 4) ]);
		now.complete[ Index(now.stage, 4) ] = 1;
#ifdef VAR_RANGES
		logval("complete[stage]", ((int)now.complete[ Index(((int)now.stage), 4) ]));
#endif
		;
		/* merge: pc = 4(106, 69, 106) */
		reached[1][69] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 4;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 38: // STATE 70 - revision.pml:128 - [((pc==4))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][70] = 1;
		if (!((((int)now.pc)==4)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 39: // STATE 71 - revision.pml:130 - [(((stage==0)||(stage==2)))] (106:0:2 - 1)
		IfNotBlocked
		reached[1][71] = 1;
		if (!(((((int)now.stage)==0)||(((int)now.stage)==2))))
			continue;
		/* merge: stage = (stage+1)(106, 72, 106) */
		reached[1][72] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.stage);
		now.stage = (((int)now.stage)+1);
#ifdef VAR_RANGES
		logval("stage", ((int)now.stage));
#endif
		;
		/* merge: pc = 0(106, 73, 106) */
		reached[1][73] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 94, 106) */
		reached[1][94] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 40: // STATE 74 - revision.pml:131 - [(((stage==1)||(stage==3)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][74] = 1;
		if (!(((((int)now.stage)==1)||(((int)now.stage)==3))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 41: // STATE 75 - revision.pml:133 - [((verdict[stage]==1))] (106:0:2 - 1)
		IfNotBlocked
		reached[1][75] = 1;
		if (!((((int)now.verdict[ Index(((int)now.stage), 4) ])==1)))
			continue;
		/* merge: selected = candidate(106, 76, 106) */
		reached[1][76] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.selected);
		now.selected = ((int)now.candidate);
#ifdef VAR_RANGES
		logval("selected", ((int)now.selected));
#endif
		;
		/* merge: terminal = Completed(106, 77, 106) */
		reached[1][77] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 5;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 92, 106) */
		reached[1][92] = 1;
		;
		/* merge: .(goto)(0, 94, 106) */
		reached[1][94] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 42: // STATE 78 - revision.pml:134 - [((verdict[stage]!=1))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][78] = 1;
		if (!((((int)now.verdict[ Index(((int)now.stage), 4) ])!=1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 43: // STATE 79 - revision.pml:142 - [(((stage==1)&&(terminal==Running)))] (106:0:4 - 1)
		IfNotBlocked
		reached[1][79] = 1;
		if (!(((((int)now.stage)==1)&&(now.terminal==6))))
			continue;
		/* merge: revisions = (revisions+1)(106, 80, 106) */
		reached[1][80] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)now.revisions);
		now.revisions = (((int)now.revisions)+1);
#ifdef VAR_RANGES
		logval("revisions", ((int)now.revisions));
#endif
		;
		/* merge: remediation_effects = (remediation_effects+1)(106, 81, 106) */
		reached[1][81] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.remediation_effects);
		now.remediation_effects = (((int)now.remediation_effects)+1);
#ifdef VAR_RANGES
		logval("remediation_effects", ((int)now.remediation_effects));
#endif
		;
		/* merge: stage = 2(106, 82, 106) */
		reached[1][82] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.stage);
		now.stage = 2;
#ifdef VAR_RANGES
		logval("stage", ((int)now.stage));
#endif
		;
		/* merge: pc = 0(106, 83, 106) */
		reached[1][83] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.pc);
		now.pc = 0;
#ifdef VAR_RANGES
		logval("pc", ((int)now.pc));
#endif
		;
		/* merge: .(goto)(0, 90, 106) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 92, 106) */
		reached[1][92] = 1;
		;
		/* merge: .(goto)(0, 94, 106) */
		reached[1][94] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 9 */
	case 44: // STATE 84 - revision.pml:157 - [(((stage==3)&&(terminal==Running)))] (106:0:2 - 1)
		IfNotBlocked
		reached[1][84] = 1;
		if (!(((((int)now.stage)==3)&&(now.terminal==6))))
			continue;
		/* merge: selected = candidate(106, 85, 106) */
		reached[1][85] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.selected);
		now.selected = ((int)now.candidate);
#ifdef VAR_RANGES
		logval("selected", ((int)now.selected));
#endif
		;
		/* merge: terminal = Exhausted(106, 86, 106) */
		reached[1][86] = 1;
		(trpt+1)->bup.ovals[1] = now.terminal;
		now.terminal = 4;
#ifdef VAR_RANGES
		logval("terminal", now.terminal);
#endif
		;
		/* merge: .(goto)(0, 90, 106) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 92, 106) */
		reached[1][92] = 1;
		;
		/* merge: .(goto)(0, 94, 106) */
		reached[1][94] = 1;
		;
		/* merge: .(goto)(0, 96, 106) */
		reached[1][96] = 1;
		;
		/* merge: .(goto)(0, 98, 106) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 45: // STATE 99 - revision.pml:40 - [assert(((spent<=frozen_limit)&&(frozen_limit<=4)))] (0:108:0 - 1)
		IfNotBlocked
		reached[1][99] = 1;
		spin_assert(((((int)now.spent)<=((int)now.frozen_limit))&&(((int)now.frozen_limit)<=4)), "((spent<=frozen_limit)&&(frozen_limit<=4))", II, tt, t);
		/* merge: assert((revisions<=1))(108, 100, 108) */
		reached[1][100] = 1;
		spin_assert((((int)now.revisions)<=1), "(revisions<=1)", II, tt, t);
		/* merge: assert((permitted_effects==1))(108, 101, 108) */
		reached[1][101] = 1;
		spin_assert((((int)now.permitted_effects)==1), "(permitted_effects==1)", II, tt, t);
		/* merge: assert((active_deadline==frozen_deadline))(108, 102, 108) */
		reached[1][102] = 1;
		spin_assert((((int)now.active_deadline)==((int)now.frozen_deadline)), "(active_deadline==frozen_deadline)", II, tt, t);
		/* merge: assert((remediation_effects==0))(108, 103, 108) */
		reached[1][103] = 1;
		spin_assert((((int)now.remediation_effects)==0), "(remediation_effects==0)", II, tt, t);
		/* merge: assert(((((effect_dispatches[0]<=1)&&(effect_dispatches[1]<=1))&&(effect_dispatches[2]<=1))&&(effect_dispatches[3]<=1)))(108, 104, 108) */
		reached[1][104] = 1;
		spin_assert(((((((int)now.effect_dispatches[0])<=1)&&(((int)now.effect_dispatches[1])<=1))&&(((int)now.effect_dispatches[2])<=1))&&(((int)now.effect_dispatches[3])<=1)), "((((effect_dispatches[0]<=1)&&(effect_dispatches[1]<=1))&&(effect_dispatches[2]<=1))&&(effect_dispatches[3]<=1))", II, tt, t);
		/* merge: assert(((terminal!=Completed)||((((selected==1)&&complete[1])&&(verdict[1]==1))||(((selected==2)&&complete[3])&&(verdict[3]==1)))))(108, 105, 108) */
		reached[1][105] = 1;
		spin_assert(((now.terminal!=5)||((((((int)now.selected)==1)&&((int)now.complete[1]))&&(((int)now.verdict[1])==1))||(((((int)now.selected)==2)&&((int)now.complete[3]))&&(((int)now.verdict[3])==1)))), "((terminal!=5)||((((selected==1)&&complete[1])&&(verdict[1]==1))||(((selected==2)&&complete[3])&&(verdict[3]==1))))", II, tt, t);
		/* merge: .(goto)(0, 109, 108) */
		reached[1][109] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 46: // STATE 111 - revision.pml:192 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[1][111] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Disruption */
	case 47: // STATE 2 - revision.pml:55 - [cancelled = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		(trpt+1)->bup.oval = ((int)now.cancelled);
		now.cancelled = 1;
#ifdef VAR_RANGES
		logval("cancelled", ((int)now.cancelled));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 48: // STATE 3 - revision.pml:56 - [expired = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		(trpt+1)->bup.oval = ((int)now.expired);
		now.expired = 1;
#ifdef VAR_RANGES
		logval("expired", ((int)now.expired));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 49: // STATE 4 - revision.pml:57 - [crashed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][4] = 1;
		(trpt+1)->bup.oval = ((int)now.crashed);
		now.crashed = 1;
#ifdef VAR_RANGES
		logval("crashed", ((int)now.crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 50: // STATE 7 - revision.pml:59 - [-end-] (0:0:0 - 5)
		IfNotBlocked
		reached[0][7] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

