#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM context_finishes */
	case 3: // STATE 1 - _spin_nvr.tmp:3 - [((!(!(assembled))&&!(completed)))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][1] = 1;
		if (!(( !( !(((int)now.assembled)))&& !(((int)now.completed)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 8 - _spin_nvr.tmp:8 - [(!(completed))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported8 = 0;
			if (verbose && !reported8)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported8 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported8 = 0;
			if (verbose && !reported8)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported8 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][8] = 1;
		if (!( !(((int)now.completed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 5: // STATE 13 - _spin_nvr.tmp:10 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported13 = 0;
			if (verbose && !reported13)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported13 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported13 = 0;
			if (verbose && !reported13)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported13 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][13] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 6: // STATE 1 - disclosure.pml:30 - [feedback_reader = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)now.feedback_reader);
		now.feedback_reader = 0;
#ifdef VAR_RANGES
		logval("feedback_reader", ((int)now.feedback_reader));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 2 - disclosure.pml:30 - [feedback_reader = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		(trpt+1)->bup.oval = ((int)now.feedback_reader);
		now.feedback_reader = 1;
#ifdef VAR_RANGES
		logval("feedback_reader", ((int)now.feedback_reader));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 5 - disclosure.pml:32 - [frozen_policy = active_policy] (0:15:8 - 1)
		IfNotBlocked
		reached[0][5] = 1;
		(trpt+1)->bup.ovals = grab_ints(8);
		(trpt+1)->bup.ovals[0] = ((int)now.frozen_policy);
		now.frozen_policy = ((int)now.active_policy);
#ifdef VAR_RANGES
		logval("frozen_policy", ((int)now.frozen_policy));
#endif
		;
		/* merge: reviewer_input_a = public_evidence(15, 6, 15) */
		reached[0][6] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.reviewer_input_a);
		now.reviewer_input_a = ((int)now.public_evidence);
#ifdef VAR_RANGES
		logval("reviewer_input_a", ((int)now.reviewer_input_a));
#endif
		;
		/* merge: reviewer_input_b = public_evidence(15, 7, 15) */
		reached[0][7] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.reviewer_input_b);
		now.reviewer_input_b = ((int)now.public_evidence);
#ifdef VAR_RANGES
		logval("reviewer_input_b", ((int)now.reviewer_input_b));
#endif
		;
		/* merge: reviewer_input_a = (reviewer_input_a+peer_a)(15, 8, 15) */
		reached[0][8] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.reviewer_input_a);
		now.reviewer_input_a = (((int)now.reviewer_input_a)+((int)now.peer_a));
#ifdef VAR_RANGES
		logval("reviewer_input_a", ((int)now.reviewer_input_a));
#endif
		;
		/* merge: reviewer_input_b = (reviewer_input_b+peer_b)(15, 9, 15) */
		reached[0][9] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.reviewer_input_b);
		now.reviewer_input_b = (((int)now.reviewer_input_b)+((int)now.peer_b));
#ifdef VAR_RANGES
		logval("reviewer_input_b", ((int)now.reviewer_input_b));
#endif
		;
		/* merge: assert((reviewer_input_a==reviewer_input_b))(15, 10, 15) */
		reached[0][10] = 1;
		spin_assert((((int)now.reviewer_input_a)==((int)now.reviewer_input_b)), "(reviewer_input_a==reviewer_input_b)", II, tt, t);
		/* merge: snapshot_a = reviewer_input_a(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.snapshot_a);
		now.snapshot_a = ((int)now.reviewer_input_a);
#ifdef VAR_RANGES
		logval("snapshot_a", ((int)now.snapshot_a));
#endif
		;
		/* merge: snapshot_b = reviewer_input_b(15, 12, 15) */
		reached[0][12] = 1;
		(trpt+1)->bup.ovals[6] = ((int)now.snapshot_b);
		now.snapshot_b = ((int)now.reviewer_input_b);
#ifdef VAR_RANGES
		logval("snapshot_b", ((int)now.snapshot_b));
#endif
		;
		/* merge: assembled = 1(15, 13, 15) */
		reached[0][13] = 1;
		(trpt+1)->bup.ovals[7] = ((int)now.assembled);
		now.assembled = 1;
#ifdef VAR_RANGES
		logval("assembled", ((int)now.assembled));
#endif
		;
		_m = 3; goto P999; /* 8 */
	case 9: // STATE 15 - disclosure.pml:46 - [peer_a = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[0][15] = 1;
		(trpt+1)->bup.oval = ((int)now.peer_a);
		now.peer_a = 2;
#ifdef VAR_RANGES
		logval("peer_a", ((int)now.peer_a));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 10: // STATE 16 - disclosure.pml:46 - [peer_b = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][16] = 1;
		(trpt+1)->bup.oval = ((int)now.peer_b);
		now.peer_b = 1;
#ifdef VAR_RANGES
		logval("peer_b", ((int)now.peer_b));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 17 - disclosure.pml:47 - [public_evidence = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[0][17] = 1;
		(trpt+1)->bup.oval = ((int)now.public_evidence);
		now.public_evidence = 2;
#ifdef VAR_RANGES
		logval("public_evidence", ((int)now.public_evidence));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 18 - disclosure.pml:51 - [reviewer_input_a = snapshot_a] (0:0:1 - 1)
		IfNotBlocked
		reached[0][18] = 1;
		(trpt+1)->bup.oval = ((int)now.reviewer_input_a);
		now.reviewer_input_a = ((int)now.snapshot_a);
#ifdef VAR_RANGES
		logval("reviewer_input_a", ((int)now.reviewer_input_a));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 19 - disclosure.pml:53 - [reviewer_input_b = snapshot_b] (0:0:1 - 1)
		IfNotBlocked
		reached[0][19] = 1;
		(trpt+1)->bup.oval = ((int)now.reviewer_input_b);
		now.reviewer_input_b = ((int)now.snapshot_b);
#ifdef VAR_RANGES
		logval("reviewer_input_b", ((int)now.reviewer_input_b));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 20 - disclosure.pml:54 - [assert(((reviewer_input_a==snapshot_a)&&(reviewer_input_b==snapshot_b)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][20] = 1;
		spin_assert(((((int)now.reviewer_input_a)==((int)now.snapshot_a))&&(((int)now.reviewer_input_b)==((int)now.snapshot_b))), "((reviewer_input_a==snapshot_a)&&(reviewer_input_b==snapshot_b))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 15: // STATE 21 - disclosure.pml:59 - [rejected_rebind = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][21] = 1;
		(trpt+1)->bup.oval = ((int)now.rejected_rebind);
		now.rejected_rebind = 1;
#ifdef VAR_RANGES
		logval("rejected_rebind", ((int)now.rejected_rebind));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 22 - disclosure.pml:61 - [assert((rejected_rebind&&(active_policy==frozen_policy)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][22] = 1;
		spin_assert((((int)now.rejected_rebind)&&(((int)now.active_policy)==((int)now.frozen_policy))), "(rejected_rebind&&(active_policy==frozen_policy))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 23 - disclosure.pml:64 - [supplied_feedback = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][23] = 1;
		(trpt+1)->bup.oval = ((int)supplied_feedback);
		supplied_feedback = 1;
#ifdef VAR_RANGES
		logval("supplied_feedback", ((int)supplied_feedback));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 24 - disclosure.pml:65 - [author_input = peer_a] (0:0:1 - 1)
		IfNotBlocked
		reached[0][24] = 1;
		(trpt+1)->bup.oval = ((int)author_input);
		author_input = ((int)now.peer_a);
#ifdef VAR_RANGES
		logval("author_input", ((int)author_input));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 25 - disclosure.pml:69 - [output_reader = (evidence_reader&&feedback_reader)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][25] = 1;
		(trpt+1)->bup.oval = ((int)now.output_reader);
		now.output_reader = (((int)now.evidence_reader)&&((int)now.feedback_reader));
#ifdef VAR_RANGES
		logval("output_reader", ((int)now.output_reader));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 26 - disclosure.pml:71 - [assert((!(output_reader)||(evidence_reader&&feedback_reader)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][26] = 1;
		spin_assert(( !(((int)now.output_reader))||(((int)now.evidence_reader)&&((int)now.feedback_reader))), "( !(output_reader)||(evidence_reader&&feedback_reader))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 27 - disclosure.pml:73 - [delegate_permitted = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][27] = 1;
		(trpt+1)->bup.oval = ((int)now.delegate_permitted);
		now.delegate_permitted = 0;
#ifdef VAR_RANGES
		logval("delegate_permitted", ((int)now.delegate_permitted));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 28 - disclosure.pml:73 - [delegate_permitted = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][28] = 1;
		(trpt+1)->bup.oval = ((int)now.delegate_permitted);
		now.delegate_permitted = 1;
#ifdef VAR_RANGES
		logval("delegate_permitted", ((int)now.delegate_permitted));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 31 - disclosure.pml:78 - [((delegate_permitted&&output_reader))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][31] = 1;
		if (!((((int)now.delegate_permitted)&&((int)now.output_reader))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 32 - disclosure.pml:78 - [delegated = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][32] = 1;
		(trpt+1)->bup.oval = ((int)now.delegated);
		now.delegated = 1;
#ifdef VAR_RANGES
		logval("delegated", ((int)now.delegated));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 34 - disclosure.pml:80 - [delegated = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][34] = 1;
		(trpt+1)->bup.oval = ((int)now.delegated);
		now.delegated = 0;
#ifdef VAR_RANGES
		logval("delegated", ((int)now.delegated));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 26: // STATE 37 - disclosure.pml:82 - [assert((!(delegated)||(delegate_permitted&&output_reader)))] (0:0:0 - 3)
		IfNotBlocked
		reached[0][37] = 1;
		spin_assert(( !(((int)now.delegated))||(((int)now.delegate_permitted)&&((int)now.output_reader))), "( !(delegated)||(delegate_permitted&&output_reader))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 27: // STATE 38 - disclosure.pml:83 - [parent_viewer = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][38] = 1;
		(trpt+1)->bup.oval = ((int)now.parent_viewer);
		now.parent_viewer = 0;
#ifdef VAR_RANGES
		logval("parent_viewer", ((int)now.parent_viewer));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 28: // STATE 39 - disclosure.pml:83 - [parent_viewer = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][39] = 1;
		(trpt+1)->bup.oval = ((int)now.parent_viewer);
		now.parent_viewer = 1;
#ifdef VAR_RANGES
		logval("parent_viewer", ((int)now.parent_viewer));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 29: // STATE 42 - disclosure.pml:85 - [(delegated)] (0:0:0 - 1)
		IfNotBlocked
		reached[0][42] = 1;
		if (!(((int)now.delegated)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 30: // STATE 43 - disclosure.pml:89 - [inherited_reader = parent_viewer] (0:0:1 - 1)
		IfNotBlocked
		reached[0][43] = 1;
		(trpt+1)->bup.oval = ((int)now.inherited_reader);
		now.inherited_reader = ((int)now.parent_viewer);
#ifdef VAR_RANGES
		logval("inherited_reader", ((int)now.inherited_reader));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 45 - disclosure.pml:91 - [inherited_reader = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][45] = 1;
		(trpt+1)->bup.oval = ((int)now.inherited_reader);
		now.inherited_reader = 0;
#ifdef VAR_RANGES
		logval("inherited_reader", ((int)now.inherited_reader));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 48 - disclosure.pml:93 - [assert((!(inherited_reader)||parent_viewer))] (0:0:0 - 3)
		IfNotBlocked
		reached[0][48] = 1;
		spin_assert(( !(((int)now.inherited_reader))||((int)now.parent_viewer)), "( !(inherited_reader)||parent_viewer)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 49 - disclosure.pml:94 - [completed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][49] = 1;
		(trpt+1)->bup.oval = ((int)now.completed);
		now.completed = 1;
#ifdef VAR_RANGES
		logval("completed", ((int)now.completed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 34: // STATE 50 - disclosure.pml:98 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][50] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

